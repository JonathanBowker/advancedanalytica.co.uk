---
# =============================================================================
# BRANDO® MESSAGING FRAMEWORK STANDARD TEMPLATE
# brando-schema-1.0 | document_type: policy_standard
# =============================================================================
#
# PLACEHOLDER CONVENTION — READ BEFORE EDITING
# -----------------------------------------------------------------------------
# {curly_brace} placeholders must be replaced with brand-specific content
# before this template is promoted to a brand policy and policy-validated.
#
# <angle_bracket> values are runtime variables resolved at validation time.
# Do NOT replace these. They are consumed by the validation engine.
#
# Quote every YAML value that contains a {curly_brace} placeholder.
# Unquoted curly braces are interpreted as flow mapping syntax and will
# cause a parse error. Quote all placeholder-containing values, including
# list items, map keys, and scalar string values.
# =============================================================================
# -----------------------------------------------------------------------------
# DOCUMENT IDENTITY
# -----------------------------------------------------------------------------
# Required. Stable, globally unique identifier for this policy.
# Recommended pattern: {brand_id}.standards.verbal-identity.messaging-framework

id: "{brand_id}.standards.verbal-identity.messaging-framework"
# Required. Usually mirrors id. Use as the stable lookup key in policy
# repositories, MCP servers, APIs, and audit logs.

key: "{brand_id}.standards.verbal-identity.messaging-framework"
# Required. Human-readable title.

title: "{Brand Name} Messaging Framework"
# Required. Short description used in repositories, UIs, search, and audit logs.

description: "Core messaging framework standard governing message architecture, claims, proof points, audience messaging, and narrative hierarchy across {Brand Name} communications."
# Required. Defines what kind of policy artefact this is.
# Allowed values:
# - standard | application | campaign | exception
# - exemplar_set | lexicon | telemetry_schema

policy_kind: standard
# Required. Top-level governance pillar.
# Allowed values controlled by Brando schema:
# - standards | applications | campaigns | legal | market | safety

pillar: standards
# Required. Category within the pillar. Use snake_case for controlled terms.

category: verbal_identity
# Required. Subcategory within the category. Use snake_case for controlled terms.

subcategory: messaging_framework
# Required. Used by Brando to distinguish policy standards from related artefacts.
# Allowed values:
# - policy_standard | application_policy | campaign_policy | exemplar
# - exemplar_set | lexicon | classifier_spec | telemetry_schema | validation_report

document_type: policy_standard
# -----------------------------------------------------------------------------
# TEMPLATE METADATA
# -----------------------------------------------------------------------------
# Identifies this file as a reusable template rather than an instantiated policy.
# Remove this block when promoting to a brand-specific policy.

template:
is_template: true
placeholder_status: contains_placeholders
instantiate_before_validation: true
# -----------------------------------------------------------------------------
# VERSIONING AND LIFECYCLE
# -----------------------------------------------------------------------------
# Required. Semantic version. Use MAJOR.MINOR.PATCH.
# MAJOR: breaking schema or rule changes
# MINOR: new rules, sections, scope, or behaviours
# PATCH: typo, copy, clarification, non-breaking fixes

version: "1.0.0"
# Required. Publication status.
# Allowed values: draft | active | deprecated | archived

status: draft
# Required. Governance lifecycle state.
# Allowed values: proposed | in_review | approved | published | superseded | retired

lifecycle_state: proposed
# Required once active/published. ISO date. Quote to prevent YAML date parsing.

effective_date: "YYYY-MM-DD"
# Required. ISO date.

created: "YYYY-MM-DD"
# Required. ISO date.

last_modified: "YYYY-MM-DD"
# Recommended. ISO date for next scheduled governance review.

next_review: "YYYY-MM-DD"
# -----------------------------------------------------------------------------
# OWNERSHIP AND APPROVAL
# -----------------------------------------------------------------------------

owner:
# Required. Owning team or function.

team: "{Brand Team Name}"
# Recommended. Steward responsible for governance upkeep.

steward: "{Steward Role or Name}"

approved_by:

* "{Approving Team or Role}"
# -----------------------------------------------------------------------------
# SCHEMA METADATA
# -----------------------------------------------------------------------------

schema:
# Required. Schema class used by Brando.

type: BrandMessagingFrameworkStandard
# Required. Schema version this document conforms to.

version: brando-schema-1.0
# Required. Validation state of this file.
# Allowed values:
# - ready_for_validation: authored but not yet parsed or reviewed
# - human_reviewed: reviewed by a human but not formally schema-validated
# - schema_validated: parsed and validated against the declared schema

#
# Set to ready_for_validation on first authoring.
# Update only after a parse or review cycle is complete.

validation_status: ready_for_validation
# -----------------------------------------------------------------------------
# CLIENT NAMING MAP
# -----------------------------------------------------------------------------
# Optional but recommended. Maps client-facing terminology to Brando terms.
# This field supports terminology mapping only. It does not affect enforcement logic.

naming:
# How the client refers to this document.

client_term: Messaging Framework
# The Brando category this standard sits within.

canonical_term: Verbal Identity
# The specific standard label within that category.

policy_label: Messaging Framework

rationale: >
{Explain how the client names this artefact and how Brando should map it
into the canonical governance model. canonical_term maps to category;
policy_label maps to subcategory. This field does not affect enforcement logic.}
# -----------------------------------------------------------------------------
# SCOPE
# -----------------------------------------------------------------------------
# Required. Defines when this policy applies.

scope:
applies_to:
# Required. Distribution or publishing environments.
# Do not mix channels with content types in this list.
channels:
- website
- linkedin
- email
- newsletter
- event_platform
- sales_enablement
- pitch_deck
- proposal

```
# Required. Types of content, message assets, or copy components governed by this policy.
# In brando-schema-1.0, content_types may include both full content formats
# and message component fields. Field-level thresholds for copy components
# are declared separately in field_applicability.
#
# Composite outputs such as pitch decks, proposals, blog posts, and campaign
# messages should be decomposed into governed message fields before rule execution.
# For example, a pitch deck may contain positioning_statement, value_proposition,
# proof_point, and call_to_action fields. Passing a composite output as a single
# blob will cause field-level rules to be skipped silently.
content_types:
  - positioning_statement
  - core_promise
  - value_proposition
  - message_pillar
  - proof_point
  - differentiator
  - reason_to_believe
  - audience_message
  - campaign_message
  - sales_message
  - boilerplate
  - elevator_pitch
  - headline
  - subhead
  - body_copy
  - email_copy
  - call_to_action
  - blog_post
  - case_study
  - thought_leadership
  - event_announcement
  - economic_buyer_message
# Recommended. Audience or persona types for message adaptation.
audiences:
  - marketing_manager
  - content_creator
  - social_media
  - executive_communications
  - sales
  - partner_marketing
  - new_hire
  - ai_agent
  - "{audience_1_id}"
  - "{audience_2_id}"
# Recommended. Zones within content.
# Useful for excluding quotations, citations, metadata, legal text, or source notes.
content_zones:
  - rendered_copy
  - quotation
  - citation
  - metadata
  - source_note
  - legal_disclaimer
```
# Recommended. Explicitly excluded contexts.

excludes:
content_types:
- legal_disclaimer
- regulated_disclosure
- invoice
- procurement_template
# Recommended. Human-readable scope clarifications.

notes:
- Applies to generated and edited messaging, marketing, editorial, sales, and campaign copy.
- Applies to the message architecture behind copy, not only to final rendered copy.
- Does not apply to quoted source material unless explicitly rewritten.
- Does not apply to legal or compliance text unless downstream policy explicitly says so.
# -----------------------------------------------------------------------------
# POLICY PRECEDENCE
# -----------------------------------------------------------------------------
# Recommended. Defines how this policy behaves when other policies also apply.

policy_precedence:
priority_order_highest_first:
- global.safety
- global.regulatory
- market.legal
- enterprise.brand-core
- "{brand_id}.applications.*"
- "{brand_id}.standards.verbal-identity.messaging-framework"
- "{brand_id}.standards.verbal-identity.tone-of-voice"
- campaign.local

conflict_resolution:
# Allowed values:
# - higher_priority_wins | most_restrictive_wins | explicit_exception_required
mode: higher_priority_wins
notes:
- Application-specific policy may narrow this standard only within its declared scope.
- Application-specific policy may not weaken higher-priority legal, regulatory, or safety constraints.
- Campaign policy may adapt messages for context but must not contradict the approved message architecture unless an exception is declared.
- Tone of Voice governs expression. Messaging Framework governs meaning, claims, structure, proof, and audience relevance.
- Exceptions must be explicit and machine-readable to override defaults.
# -----------------------------------------------------------------------------
# INHERITANCE
# -----------------------------------------------------------------------------
# Optional but recommended for enterprise or multi-brand systems.

inheritance:
inherits_from:
- "{brand_id}.brand.core"
may_be_overridden_by:
- "{brand_id}.applications.case-study"
- "{brand_id}.applications.linkedin"
- "{brand_id}.applications.thought-leadership"
- "{brand_id}.applications.website"
- "{brand_id}.campaigns.*"
- "{brand_id}.legal.*"
- "{brand_id}.market.*"
# -----------------------------------------------------------------------------
# RESOLUTION BEHAVIOUR
# -----------------------------------------------------------------------------
# Recommended for executable policy systems.

resolution:
resolve_inheritance_before_validation: true
resolve_exceptions_before_rule_execution: true
materialize_effective_policy: true
effective_policy_output:
include_resolved_rules: true
include_applied_exceptions: true
include_precedence_path: true
include_resolved_message_architecture: true
include_resolved_claim_rules: true
# -----------------------------------------------------------------------------
# MESSAGING PRINCIPLES
# -----------------------------------------------------------------------------
# Required. Three to five principles is usually enough.
# Keep descriptions to one clear sentence each.

principles:
required:
- "{messaging_principle_1}"
- "{messaging_principle_2}"
- "{messaging_principle_3}"
definitions:
# Map keys containing placeholders must be quoted to remain valid YAML.
"{messaging_principle_1}":
description: "{Describe messaging principle 1 in one clear sentence.}"
"{messaging_principle_2}":
description: "{Describe messaging principle 2 in one clear sentence.}"
"{messaging_principle_3}":
description: "{Describe messaging principle 3 in one clear sentence.}"
# -----------------------------------------------------------------------------
# MESSAGING POLICY
# -----------------------------------------------------------------------------
# Required. Defines what messaging must do.
# This is not the same as Tone of Voice. Tone governs expression.
# Messaging governs meaning, hierarchy, claims, proof, and audience relevance.

messaging_policy:
objectives:
required:
- communicate_customer_value
- establish_clear_point_of_view
- connect_claims_to_proof
- differentiate_from_competitors
- support_channel_and_audience_adaptation

message_characteristics:
required:
- audience_relevant
- benefit_led
- specific
- provable
- differentiated
- consistent_with_brand_core
discouraged:
- generic_category_language
- unsupported_claims
- internal_capability_dumping
- overclaiming
- conflicting_messages
- vague_benefits

hierarchy:
required_order:
- positioning_statement
- core_promise
- value_proposition
- message_pillar
- proof_point
- call_to_action
notes:
- The hierarchy defines the preferred logic of the message system.
- Individual content outputs may omit layers only when field_applicability or application policy allows it.
- Lower-level proof points must support higher-level value propositions or message pillars.

audience_orientation:
default_required:
- audience_problem
- audience_benefit
- audience_next_step
default_forbidden:
- inward_capability_only_message
notes:
- Messaging should start from what the audience needs to understand, believe, or do.
- Internal capabilities should be framed as evidence for customer value, not as the message itself.
# -----------------------------------------------------------------------------
# MESSAGE ARCHITECTURE
# -----------------------------------------------------------------------------
# Required. Defines the approved message system.
# Replace all placeholder entries before policy validation.

message_architecture:
positioning_statement:
id: positioning_statement
label: Positioning Statement
message: "{Approved positioning statement.}"
required: true
proof_refs:
- "{proof_point_1_id}"

core_promise:
id: core_promise
label: Core Promise
message: "{Approved core promise.}"
required: true
proof_refs:
- "{proof_point_1_id}"

value_propositions:
minimum_required: 1
items:
- id: "{value_prop_1_id}"
label: "{Value proposition 1 label}"
message: "{Approved value proposition 1.}"
audience_benefit: "{Audience benefit supported by this value proposition.}"
proof_refs:
- "{proof_point_1_id}"

```
  - id: "{value_prop_2_id}"
    label: "{Value proposition 2 label}"
    message: "{Approved value proposition 2.}"
    audience_benefit: "{Audience benefit supported by this value proposition.}"
    proof_refs:
      - "{proof_point_2_id}"
```

message_pillars:
minimum_required: 3
maximum_recommended: 5
items:
- id: "{pillar_1_id}"
label: "{Pillar 1 label}"
message: "{Approved pillar 1 message.}"
supports_value_proposition:
- "{value_prop_1_id}"
proof_refs:
- "{proof_point_1_id}"

```
  - id: "{pillar_2_id}"
    label: "{Pillar 2 label}"
    message: "{Approved pillar 2 message.}"
    supports_value_proposition:
      - "{value_prop_1_id}"
    proof_refs:
      - "{proof_point_2_id}"

  - id: "{pillar_3_id}"
    label: "{Pillar 3 label}"
    message: "{Approved pillar 3 message.}"
    supports_value_proposition:
      - "{value_prop_2_id}"
    proof_refs:
      - "{proof_point_3_id}"
```

differentiators:
minimum_required: 1
items:
- id: "{differentiator_1_id}"
label: "{Differentiator 1 label}"
message: "{Approved differentiator statement.}"
# Allowed values: category_norm | competitor | alternative_approach | status_quo
contrast_type: "{contrast_type_value}"
proof_refs:
- "{proof_point_1_id}"

proof_points:
minimum_required: 1
items:
- id: "{proof_point_1_id}"
label: "{Proof point 1 label}"
# Allowed values: data | customer_story | credential | methodology | product_capability | third_party_source
proof_type: "{proof_type_value}"
statement: "{Approved proof point statement.}"
source_ref: "{source_reference_or_repository_key}"
# Allowed values: unverified | human_reviewed | source_verified | legally_approved
verification_status: "{verification_status_value}"

```
  - id: "{proof_point_2_id}"
    label: "{Proof point 2 label}"
    # Allowed values: data | customer_story | credential | methodology | product_capability | third_party_source
    proof_type: "{proof_type_value}"
    statement: "{Approved proof point statement.}"
    source_ref: "{source_reference_or_repository_key}"
    # Allowed values: unverified | human_reviewed | source_verified | legally_approved
    verification_status: "{verification_status_value}"

  - id: "{proof_point_3_id}"
    label: "{Proof point 3 label}"
    # Allowed values: data | customer_story | credential | methodology | product_capability | third_party_source
    proof_type: "{proof_type_value}"
    statement: "{Approved proof point statement.}"
    source_ref: "{source_reference_or_repository_key}"
    # Allowed values: unverified | human_reviewed | source_verified | legally_approved
    verification_status: "{verification_status_value}"
```

calls_to_action:
default:
id: default_cta
message: "{Approved default call to action.}"
alternatives:
- id: "{cta_1_id}"
message: "{Approved CTA variant.}"
when:
channel:
- website
- linkedin
# -----------------------------------------------------------------------------
# AUDIENCE MESSAGING
# -----------------------------------------------------------------------------
# Recommended. Defines audience-specific message adaptations.

audience_messaging:
# default_audience must reference a declared segment id below.

default_audience: "{audience_1_id}"
segments:
- id: "{audience_1_id}"
label: "{Audience 1 label}"
primary_need: "{Audience need, problem, or decision context.}"
approved_message: "{Approved audience-specific message.}"
relevant_value_props:
- "{value_prop_1_id}"
relevant_pillars:
- "{pillar_1_id}"
proof_refs:
- "{proof_point_1_id}"
preferred_cta: "{cta_1_id}"

```
- id: "{audience_2_id}"
  label: "{Audience 2 label}"
  primary_need: "{Audience need, problem, or decision context.}"
  approved_message: "{Approved audience-specific message.}"
  relevant_value_props:
    - "{value_prop_2_id}"
  relevant_pillars:
    - "{pillar_2_id}"
  proof_refs:
    - "{proof_point_2_id}"
  preferred_cta: default_cta
```
# -----------------------------------------------------------------------------
# CLAIMS POLICY
# -----------------------------------------------------------------------------
# Required for executable messaging governance.
# Defines which claims are allowed, restricted, or forbidden.

claims_policy:
allowed_claim_types:
- audience_benefit
- point_of_view
- capability
- methodology
- experience
- category_context

restricted_claim_types:
- performance_claim
- market_leadership_claim
- comparative_claim
- financial_impact_claim
- risk_reduction_claim
- compliance_claim
- transformation_claim

forbidden_claim_types:
- guaranteed_outcome
- unsupported_superiority
- unverifiable_market_leadership
- legal_or_regulatory_assurance_without_approval
- competitor_disparagement

evidence_requirements:
default:
proof_required: true
accepted_proof_types:
- data
- customer_story
- credential
- methodology
- product_capability
- third_party_source
by_claim_type:
performance_claim:
proof_required: true
accepted_proof_types:
- data
- third_party_source
legal_review_required: true
market_leadership_claim:
proof_required: true
accepted_proof_types:
- third_party_source
- data
legal_review_required: true
comparative_claim:
proof_required: true
accepted_proof_types:
- third_party_source
- data
legal_review_required: true
compliance_claim:
proof_required: true
accepted_proof_types:
- credential
- third_party_source
legal_review_required: true
financial_impact_claim:
proof_required: true
accepted_proof_types:
- data
- third_party_source
- customer_story
legal_review_required: true
risk_reduction_claim:
proof_required: true
accepted_proof_types:
- data
- methodology
- third_party_source
legal_review_required: false
transformation_claim:
proof_required: true
accepted_proof_types:
- customer_story
- data
- methodology
legal_review_required: false
# claim_language_triggers is used as an input signal for claim_type_classifier.
# It is not directly consumed by any deterministic rule.
# Classifiers may use these trigger terms as features when classifying claim risk level.
# If direct pattern enforcement is needed, add a D-rule that fires on trigger phrase
# matches and escalates to classifier review.

claim_language_triggers:
superlative_terms:
- best
- leading
- first
- only
- most
- unmatched
- unrivalled
absolute_terms:
- always
- never
- every
- guaranteed
- eliminates
- ensures
comparative_terms:
- better
- faster
- stronger
- more effective
- less risky
# -----------------------------------------------------------------------------
# LEXICAL POLICY
# -----------------------------------------------------------------------------
# Optional. Use when messaging has forbidden, discouraged, or preferred vocabulary.
# Keep this focused on message meaning. Tone-specific vocabulary should live in
# the Tone of Voice standard unless it affects messaging claims or positioning.

lexical_policy:
forbidden_words:
exact:
- "{forbidden_message_word_or_phrase_1}"
- "{forbidden_message_word_or_phrase_2}"

discouraged_words:
- "{discouraged_message_word_or_phrase_1}"
- "{discouraged_message_word_or_phrase_2}"

preferred_replacements:
# Map keys containing placeholders must be quoted to remain valid YAML.
"{forbidden_message_word_or_phrase_1}": "{preferred_replacement_1}"
"{forbidden_message_word_or_phrase_2}": "{preferred_replacement_2}"
# -----------------------------------------------------------------------------
# PATTERN POLICY
# -----------------------------------------------------------------------------
# Recommended. Defines reusable message and claim constraints.
# Rules reference patterns by id, not by list index.

pattern_policy:
forbidden_patterns:
- id: unsupported_superiority
description: Do not claim superiority unless the claim has approved evidence and legal clearance where required.
trigger_phrases:
- best in class
- market leading
- industry leading
- unrivalled
- unmatched
examples:
fail:
- "We offer the market-leading approach."
pass:
- "Our approach is built to help you move with clearer evidence and stronger controls."

```
- id: vague_value_proposition
  description: Avoid value propositions that do not name a clear audience benefit.
  examples:
    fail:
      - "We help organisations transform with powerful services."
    pass:
      - "We help you turn complex decisions into clear, governed action."

- id: inward_capability_only_message
  description: Avoid messages that list capabilities without connecting them to customer value.
  examples:
    fail:
      - "We have experts, platforms, frameworks, and delivery teams."
    pass:
      - "You get expert support, practical tools, and a clearer path to action."
```
# -----------------------------------------------------------------------------
# REQUIRED ELEMENTS
# -----------------------------------------------------------------------------
# Recommended. Defines message components generated copy should include.

required_elements:
default:
- audience_need
- customer_benefit
- clear_point_of_view
- approved_message_source
- proof_reference
- call_to_action
conditional:
- id: proof_for_restricted_claim
required_when:
restricted_claim_type_present: true
- id: legal_review_for_high_risk_claim
required_when:
legal_review_required: true
- id: audience_message_for_targeted_content
required_when:
audience_specific_content: true
# -----------------------------------------------------------------------------
# FIELD APPLICABILITY
# -----------------------------------------------------------------------------
# Required if different message fields need different thresholds.
# Every content_type in scope.applies_to.content_types that requires field-level
# threshold checking must have an entry here. Missing entries should produce a
# schema warning or validation error.

field_applicability:
positioning_statement:
sentence_style:
target_max_words: 24
hard_max_words: 36
proof_required: true
cta_required: false

core_promise:
sentence_style:
target_max_words: 16
hard_max_words: 24
proof_required: true
cta_required: false

value_proposition:
sentence_style:
target_max_words: 18
hard_max_words: 28
proof_required: true
cta_required: false

message_pillar:
sentence_style:
target_max_words: 16
hard_max_words: 26
proof_required: true
cta_required: false

proof_point:
sentence_style:
target_max_words: 18
hard_max_words: 30
proof_required: false
cta_required: false
# reason_to_believe is treated as a sibling of proof_point.
# It supports claims by grounding them in concrete evidence or experience.

reason_to_believe:
sentence_style:
target_max_words: 18
hard_max_words: 30
proof_required: true
cta_required: false

differentiator:
sentence_style:
target_max_words: 18
hard_max_words: 28
proof_required: true
cta_required: false

audience_message:
sentence_style:
target_max_words: 20
hard_max_words: 32
proof_required: true
cta_required: true

campaign_message:
sentence_style:
target_max_words: 18
hard_max_words: 30
proof_required: true
cta_required: true

sales_message:
sentence_style:
target_max_words: 20
hard_max_words: 34
proof_required: true
cta_required: true

boilerplate:
sentence_style:
target_max_words: 24
hard_max_words: 40
proof_required: false
cta_required: false

elevator_pitch:
sentence_style:
target_max_words: 30
hard_max_words: 45
proof_required: true
cta_required: false

headline:
sentence_style:
target_max_words: 10
hard_max_words: 14
proof_required: false
cta_required: false

subhead:
sentence_style:
target_max_words: 16
hard_max_words: 24
proof_required: false
cta_required: false

body_copy:
sentence_style:
target_max_words: 18
hard_max_words: 28
proof_required: true
cta_required: true

email_copy:
sentence_style:
target_max_words: 18
hard_max_words: 28
proof_required: true
cta_required: true

call_to_action:
sentence_style:
target_max_words: 10
hard_max_words: 14
proof_required: false
cta_required: true
# -----------------------------------------------------------------------------
# PERSONA PROFILES
# -----------------------------------------------------------------------------
# Optional. Use when the same framework needs slightly different behaviour
# for editors, executives, social teams, sales teams, new hires, or AI agents.

persona_profiles:
marketing_manager:
messaging_adjustment: standard
content_creator:
messaging_adjustment: standard
social_media:
messaging_adjustment: compressed_and_channel_native
executive_communications:
messaging_adjustment: strategic_and_evidence_led
sales:
messaging_adjustment: buyer_need_and_objection_led
partner_marketing:
messaging_adjustment: shared_value_and_joint_proof_led
new_hire:
messaging_adjustment: explanatory
ai_agent:
messaging_adjustment: strict_constraint_enforcement
# -----------------------------------------------------------------------------
# EXCEPTIONS
# -----------------------------------------------------------------------------
# Required for executable governance. All exceptions must be declared here.
# Undeclared exceptions hard fail.

exceptions:
undeclared_exception_behaviour: hard_fail
validation:
exception_must_be_declared_in_policy: true
exception_must_match_content_context: true
log_all_exception_activations: true

declared:
- id: quote_preservation_exception
description: Quoted material may retain source phrasing, including unapproved claims, unsupported wording, deprecated messages, sentence length, or proof gaps.
when:
content_zone:
- quotation
- citation
override:
enforcement_mode: quoted_material_relaxed
skip_rules:
- D001
- D005
- D007
- D008
- H005
- H007
- H008
- H009
- H010

```
- id: legal_text_exception
  description: Legal or regulated text may override messaging preferences where required by law or compliance.
  when:
    policy_context:
      higher_priority_policy_matches:
        - "{brand_id}.legal.*"
        - global.regulatory
  override:
    enforcement_mode: defer_to_higher_policy

- id: campaign_adaptation_exception
  description: Campaign policies may adapt approved messages for campaign context, provided the adapted message remains traceable to an approved pillar, value proposition, or audience message.
  when:
    application:
      - "{brand_id}.campaigns.*"
  override:
    enforcement_mode: campaign_adaptation_allowed
    requirements:
      - approved_message_source_required
      - proof_reference_required_for_claims
      - no_forbidden_claim_types

- id: legally_approved_claim_exception
  description: Restricted claims may be used when the claim, evidence, and wording have explicit legal approval.
  when:
    approval_status:
      - legally_approved
  override:
    enforcement_mode: restricted_claim_allowed
    requirements:
      - legal_approval_ref_required
      - proof_reference_required
```
# -----------------------------------------------------------------------------
# EXEMPLARS
# -----------------------------------------------------------------------------
# Recommended. Positive examples for human guidance and semantic scoring.

exemplars:
minimum_review_count: 2
# Markdown exemplar copies in the document body are for humans only.
# Authoritative exemplar text is retrieved from the policy repository.
# Validators must use repository versions, not Markdown copies.

markdown_examples:
role: human_readable_copy
authoritative: false
excluded_from_validation: true

storage:
# Allowed values: inline | referenced | external_repository
mode: referenced
source_key: "{brand_id}.standards.verbal-identity.messaging-framework"
section: exemplars
load_at_validation: true
retrieval:
# Allowed protocol values:
# - brando_policy_repo | local_file | http | mcp_resource
protocol: brando_policy_repo
base_path: /policies/exemplars/
# <exemplar_key> is a runtime variable resolved at validation time.
# Do NOT replace this. It is not a template fill-in placeholder.
key_format: "<exemplar_key>.md"
auth: service_account
timeout_seconds: 5
cache_ttl_seconds: 300

fallback_behaviour:
if_exemplars_unavailable: skip_rule_with_warning
affected_rules:
- H004

active_exemplar_keys:
- "{brand_id}.standards.verbal-identity.messaging-framework.exemplar.{example_key_1}"
- "{brand_id}.standards.verbal-identity.messaging-framework.exemplar.{example_key_2}"

source_contexts:
channels:
- website
- linkedin
- newsletter
- sales_enablement
- pitch_deck
content_types:
- positioning_statement
- value_proposition
- message_pillar
- audience_message
- campaign_message
- boilerplate
- elevator_pitch
# -----------------------------------------------------------------------------
# COMPETITIVE DIFFERENTIATION
# -----------------------------------------------------------------------------
# Optional. Helps human reviewers understand contrastive positioning.

competitive_differentiation:
competitors:
- "{competitor_1}"
- "{competitor_2}"
category_norms_to_avoid:
- "{Generic category phrase or message pattern to avoid}"
differentiators:
- "{Differentiator 1}"
- "{Differentiator 2}"
# -----------------------------------------------------------------------------
# ANTI-EXEMPLARS
# -----------------------------------------------------------------------------
# Optional. Negative examples for human review only.
# Anti-exemplars are excluded from all deterministic and heuristic validation.
# They must not be scored, repaired, or used as training signal unless a rule
# explicitly declares them as an input source.

anti_exemplars:
enforcement_role: negative_reference_only
used_by_rules: []
excluded_from_deterministic_validation: true
excluded_from_heuristic_validation: true
sources:
- id: "{anti_exemplar_source_1}"
label: "{Human-readable label}"
for_human_review_only: true
# -----------------------------------------------------------------------------
# DOCUMENT SELF-VALIDATION
# -----------------------------------------------------------------------------
# Recommended. Defines which parts of this file are subject to rule validation.

document_self_validation:
# Validate YAML structure, rule ID patterns, path references, declared values,
# and key consistency. Does NOT mean: run brand copy rules over the YAML text.

validate_yaml_structure: true
# Validate authoritative positive exemplars retrieved from the policy repository.
# Does NOT apply to the Markdown exemplar copies in the document body.

validate_authoritative_positive_exemplars: true
# Validate that every value_prop, pillar, proof_point, CTA, and audience ID
# referenced anywhere in the document resolves to a declared entry in
# message_architecture or audience_messaging.

validate_message_architecture_references: true
# Validate that every restricted claim type declared in
# claims_policy.restricted_claim_types has a corresponding evidence requirement
# entry in claims_policy.evidence_requirements.by_claim_type, or is explicitly
# covered by the default evidence requirement.

validate_claim_evidence_mapping: true
# Exclude the Markdown body guidance text from rule execution.

exclude_markdown_guidance: true
# Exclude the change log table from rule execution.

exclude_change_log: true
# Exclude YAML comments from rule execution. Comments are stripped before parsing.

exclude_comments: true
# Exclude anti-exemplar copy from rule execution.
# See anti_exemplars.excluded_from_deterministic_validation.

exclude_anti_exemplars: true
# Exclude the human-readable Markdown copies of exemplars from rule execution.
# Authoritative exemplar text lives in the repository.

exclude_markdown_exemplar_copies: true

notes:
- validate_authoritative_positive_exemplars applies only to repository exemplars retrieved via exemplars.storage.retrieval.
- Message architecture references include value_prop ids, pillar ids, proof_refs, CTA ids, and audience ids declared in audience_messaging.segments.
- Markdown exemplar copies are excluded per exemplars.markdown_examples.excluded_from_validation.
- Anti-exemplars are excluded per anti_exemplars.excluded_from_deterministic_validation.
- YAML comments are excluded as they are stripped before rule execution.
# -----------------------------------------------------------------------------
# CLASSIFIERS
# -----------------------------------------------------------------------------
# Optional. Declare any judgement-based classifiers required by heuristic rules.
# Any classifier referenced in a rule's detect.requires_classifier field
# must have a full specification entry here.

classifiers:
claim_type_classifier:
description: >
Classifies claims by type, including audience benefit, capability,
methodology, performance, market leadership, comparative, compliance,
financial impact, and guaranteed outcome claims. Also consumes
claims_policy.claim_language_triggers as input signals.
output:
type: object
properties:
claim_type:
type: string
confidence:
type: number
reason:
type: string
used_by_rules:
- H005
- H008
- H009
- H010

value_proposition_clarity_classifier:
description: >
Detects whether a message clearly names an audience, a meaningful benefit,
and the change or outcome the brand helps create.
output:
type: object
properties:
clear_value_proposition:
type: boolean
confidence:
type: number
reason:
type: string
used_by_rules:
- H001

audience_relevance_classifier:
description: >
Scores whether the message reflects the declared audience's needs,
priorities, decision context, and likely next step.
output:
type: object
properties:
audience_relevance_score:
type: number
reason:
type: string
used_by_rules:
- H002

differentiation_classifier:
description: >
Scores whether the message creates a meaningful distinction from category
norms, competitors, alternative approaches, or the status quo.
output:
type: object
properties:
differentiation_score:
type: number
reason:
type: string
used_by_rules:
- H003

narrative_coherence_classifier:
description: >
Scores whether the message connects the audience need, point of view,
benefit, proof, and next step into a coherent narrative.
output:
type: object
properties:
coherence_score:
type: number
reason:
type: string
used_by_rules:
- H006

proof_quality_classifier:
description: >
Scores whether proof points are specific, credible, relevant to the claim,
and appropriate for the claim risk level.
output:
type: object
properties:
proof_quality_score:
type: number
reason:
type: string
used_by_rules:
- H007
# -----------------------------------------------------------------------------
# EXECUTION
# -----------------------------------------------------------------------------
# Required for executable validation.

execution:
# Allowed values: blocking | advisory | audit_only

enforcement_mode: blocking

max_retry_attempts: 3
escalate_to_human_after: 3
# Declares the valid ID pattern for each rule phase.

rule_id_policy:
deterministic_pattern: "^D[0-9]{3}$"
heuristic_pattern: "^H[0-9]{3}[A-Z]?$"

rule_execution_order:
phase_1_deterministic:
# Classifier-dependent claim checks are classified as heuristic rules
# H008, H009, H010. Deterministic rules must be implementable via
# pattern logic, lexicons, measurable thresholds, or structural checks only.
- D001
- D005
- D006
- D007
- D008
- D009
- D010
phase_2_heuristic:
- H001
- H002
- H003
- H004
- H005
- H006
- H007
# H008, H009, H010 are classifier-dependent claim governance rules.
# They depend on claim_type_classifier and run after structural checks.
- H008
- H009
- H010
notes: Run all deterministic rules first. Only proceed to heuristic rules if all deterministic rules pass or produce soft warnings only.

heuristic_decisioning:
low_confidence_ignore_below: 0.60
medium_confidence_warn_at_or_above: 0.60
high_confidence_enforce_at_or_above: 0.85
threshold_resolution:
policy: per_rule_takes_precedence
notes:
- Where a rule declares its own threshold, that value governs for that rule.
- Global heuristic_decisioning thresholds apply only where a rule does not declare its own threshold.
- H004 uses minimum_score on a 0-100 percentage scale. All other heuristic rules use a 0.0-1.0 probability scale. Do not normalise across these scales.

retry_strategy:
mode: targeted_repair_then_regenerate
repair_scope:
deterministic_failures: message_component_level
heuristic_failures: paragraph_or_message_asset_level
after_two_failed_repairs: full_regeneration
repair_instruction_format:
include_violation_id: true
include_failing_text: true
include_remediation_action: true
include_message_source_reference: true
include_proof_reference: true
sequence:
- repair_deterministic_failures
- re-evaluate
- repair_heuristic_weaknesses
- re-evaluate
- regenerate_if_still_failing

output_contract:
must_pass:
- no_hard_fail_rules
may_pass_with_warnings:
- soft_warn_only
must_block:
- any_hard_fail_after_max_retries
- forbidden_claim_type_present
- required_proof_missing_for_restricted_claim
# -----------------------------------------------------------------------------
# RULES
# -----------------------------------------------------------------------------
# Required. Rules are executable validation checks.
# Rules reference pattern_policy entries by id, not by list index.

rules:
deterministic:
- id: D001
name: approved_message_source_missing
severity: hard_fail
applies_to:
- value_proposition
- message_pillar
- audience_message
- campaign_message
- sales_message
- body_copy
detect:
# structural_reference checks whether the content item carries an
# approved_message_source field that resolves to a declared approved
# message source. Audience messages resolve through audience_messaging,
# not message_architecture.
method: structural_reference
required_reference_types:
- positioning_statement
- core_promise
- value_proposition
- message_pillar
- audience_message
allowed_reference_sources:
- message_architecture.positioning_statement.id
- message_architecture.core_promise.id
- message_architecture.value_propositions.items.id
- message_architecture.message_pillars.items.id
- audience_messaging.segments.id
remediation:
action: attach_to_approved_message_source_or_rewrite

```
- id: D005
  name: undeclared_message_pillar_used
  severity: hard_fail
  applies_to:
    - message_pillar
    - audience_message
    - campaign_message
    - sales_message
    - body_copy
  detect:
    method: id_reference_check
    allowed_ids_from: message_architecture.message_pillars.items.id
    # approved_message_source is intentionally excluded here.
    # It may reference positioning_statement, core_promise, value_proposition,
    # or audience_message — not only message pillars. D001 handles that check.
    reference_fields:
      - message_pillar_id
      - relevant_pillars
  remediation:
    action: replace_with_declared_message_pillar_or_create_exception

- id: D006
  name: audience_segment_missing_for_targeted_message
  severity: hard_fail
  applies_to:
    - audience_message
    - campaign_message
    - sales_message
    - email_copy
  detect:
    method: structural_presence
    target: audience
  when:
    audience_specific_content: true
  remediation:
    action: declare_target_audience_or_rewrite_as_general_message

- id: D007
  name: sentence_exceeds_hard_max
  severity: hard_fail
  applies_to:
    - positioning_statement
    - core_promise
    - value_proposition
    - message_pillar
    - proof_point
    - reason_to_believe
    - differentiator
    - audience_message
    - campaign_message
    - sales_message
    - boilerplate
    - elevator_pitch
    - headline
    - subhead
    - body_copy
    - email_copy
    - call_to_action
  detect:
    method: sentence_word_count
    threshold_from_field_applicability: hard_max_words
    count_mode: whitespace_tokenized
    ignore_quoted_material: true
  remediation:
    action: split_or_simplify_message

- id: D008
  name: deprecated_message_used
  severity: hard_fail
  applies_to:
    - headline
    - subhead
    - body_copy
    - email_copy
    - value_proposition
    - message_pillar
    - audience_message
    - campaign_message
    - sales_message
  detect:
    method: deprecated_message_match
    source: deprecated_messages.items
    case_insensitive: true
  remediation:
    action: replace_with_current_approved_message

- id: D009
  name: message_hierarchy_order_invalid
  severity: soft_warn
  applies_to:
    - campaign_message
    - sales_message
    - body_copy
    - email_copy
    - elevator_pitch
    - boilerplate
  detect:
    method: structural_order_check
    required_order_from: messaging_policy.hierarchy.required_order
    allow_missing_optional_layers: true
  remediation:
    action: reorder_message_to_follow_approved_hierarchy

- id: D010
  name: missing_call_to_action
  severity: soft_warn
  applies_to:
    - audience_message
    - campaign_message
    - sales_message
    - body_copy
    - email_copy
    - call_to_action
  detect:
    method: structural_presence
    target: call_to_action
  when:
    cta_required: true
  remediation:
    action: add_single_clear_cta
```

heuristic:
- id: H001
name: unclear_value_proposition
severity: hard_fail
applies_to:
- positioning_statement
- core_promise
- value_proposition
- audience_message
- campaign_message
- sales_message
- body_copy
detect:
method: value_proposition_clarity_classifier
threshold: 0.80
remediation:
action: clarify_audience_benefit_and_outcome

```
- id: H002
  name: weak_audience_relevance
  severity: soft_warn
  applies_to:
    - audience_message
    - campaign_message
    - sales_message
    - email_copy
    - body_copy
  detect:
    method: audience_relevance_classifier
    threshold: 0.75
  remediation:
    action: align_message_to_declared_audience_need

- id: H003
  name: weak_differentiation
  severity: soft_warn
  applies_to:
    - positioning_statement
    - core_promise
    - value_proposition
    - differentiator
    - audience_message
    - campaign_message
    - body_copy
  detect:
    method: differentiation_classifier
    threshold: 0.70
  remediation:
    action: strengthen_distinctive_point_of_view_or_proof

- id: H004
  name: low_exemplar_alignment_score
  severity: soft_warn
  applies_to:
    - positioning_statement
    - value_proposition
    - message_pillar
    - audience_message
    - campaign_message
    - sales_message
    - headline
    - subhead
    - body_copy
  detect:
    method: semantic_similarity
    exemplar_set: exemplars.active_exemplar_keys
    # Score is on a 0-100 percentage scale.
    # Do not normalise to 0.0-1.0. See execution.heuristic_decisioning.threshold_resolution.
    minimum_score: 70
  remediation:
    action: revise_toward_approved_message_patterns

- id: H005
  name: overclaiming_risk
  severity: hard_fail
  applies_to:
    - headline
    - subhead
    - body_copy
    - email_copy
    - value_proposition
    - message_pillar
    - differentiator
    - audience_message
    - campaign_message
    - sales_message
  detect:
    method: overclaiming_risk_check
    requires_classifier: claim_type_classifier
    threshold: 0.85
  remediation:
    action: narrow_claim_or_add_approved_evidence

- id: H006
  name: weak_narrative_coherence
  severity: soft_warn
  applies_to:
    - campaign_message
    - sales_message
    - body_copy
    - email_copy
    - elevator_pitch
    - boilerplate
  detect:
    method: narrative_coherence_classifier
    threshold: 0.75
  remediation:
    action: connect_need_benefit_proof_and_next_step

- id: H007
  name: insufficient_proof_quality
  severity: soft_warn
  applies_to:
    - proof_point
    - reason_to_believe
    - value_proposition
    - message_pillar
    - differentiator
    - audience_message
    - campaign_message
    - sales_message
  detect:
    method: proof_quality_classifier
    threshold: 0.70
  remediation:
    action: improve_specificity_source_quality_or_claim_fit
# H008, H009, H010 are classifier-dependent claim governance rules.
# Severity remains hard_fail where declared. Classifier dependency changes
# the detection mechanism, not the governance risk level.
- id: H008
  name: proof_reference_missing_for_claim
  severity: hard_fail
  applies_to:
    - positioning_statement
    - core_promise
    - value_proposition
    - message_pillar
    - differentiator
    - audience_message
    - campaign_message
    - sales_message
    - body_copy
  detect:
    method: claim_proof_reference_check
    requires_classifier: claim_type_classifier
    proof_required_from: claims_policy.evidence_requirements
    reference_field: proof_refs
  unless_exception:
    - quote_preservation_exception
    - legal_text_exception
  remediation:
    action: add_proof_reference_or_narrow_claim

- id: H009
  name: forbidden_claim_type_used
  severity: hard_fail
  applies_to:
    - headline
    - subhead
    - body_copy
    - email_copy
    - value_proposition
    - message_pillar
    - differentiator
    - audience_message
    - campaign_message
    - sales_message
  detect:
    method: claim_type_match
    requires_classifier: claim_type_classifier
    source: claims_policy.forbidden_claim_types
  unless_exception:
    - quote_preservation_exception
  remediation:
    action: remove_forbidden_claim_or_rewrite_to_allowed_claim

- id: H010
  name: restricted_claim_without_approval
  severity: hard_fail
  applies_to:
    - headline
    - subhead
    - body_copy
    - email_copy
    - value_proposition
    - message_pillar
    - differentiator
    - audience_message
    - campaign_message
    - sales_message
  detect:
    method: restricted_claim_approval_check
    requires_classifier: claim_type_classifier
    restricted_claim_source: claims_policy.restricted_claim_types
    approval_required_when:
      legal_review_required: true
    approval_field: legal_approval_ref
  unless_exception:
    - legally_approved_claim_exception
    - quote_preservation_exception
  remediation:
    action: add_approval_reference_or_rewrite_to_lower_risk_claim
```
# -----------------------------------------------------------------------------
# DEPRECATED MESSAGES
# -----------------------------------------------------------------------------
# Optional. Use when older message lines must be blocked or replaced.
# Includes review cycle and governance notes so validators can determine
# whether deprecated messages are actively maintained.

deprecated_messages:
review_cycle: quarterly
notes:
- Deprecated messages are checked against all governed content types listed in D008.applies_to.
- Review this list each quarter and remove entries older than 24 months.
- Each deprecated message must carry a replacement_ref pointing to a current approved message source.
items:
- id: "{deprecated_message_1_id}"
text: "{Deprecated message text.}"
replacement_ref: "{value_prop_1_id}"
reason: "{Why this message is no longer approved.}"
# -----------------------------------------------------------------------------
# DECISION POLICY
# -----------------------------------------------------------------------------
# Required. Defines pass/warn/fail and publishing behaviour.

decision_policy:
pass_conditions:
- zero_hard_failures
warn_conditions:
- one_or_more_soft_warnings
fail_conditions:
- one_or_more_hard_failures
publish_conditions:
- status in [pass, warn]
- hard_fail_count == 0

warn_behaviour:
auto_publish_allowed: true
# most_restrictive_wins: if any matched channel, content_type, or claim type
# requires human sign-off, that requirement overrides all other matched rules.
conflict_resolution:
mode: most_restrictive_wins
notes:
- If any matched channel, content_type, or claim type requires human sign-off, human sign-off is required.
- Auto-publish is allowed only when no matched rule requires human sign-off.
requires_human_sign_off_on_warn:
channels:
- website
- pitch_deck
- sales_enablement
content_types:
- thought_leadership
- economic_buyer_message
- positioning_statement
- value_proposition
claim_types:
- restricted_claim_type
- comparative_claim
- market_leadership_claim
allows_auto_publish_on_warn:
channels:
- linkedin
- newsletter
content_types:
- blog_post
- event_announcement

human_review_conditions:
- retry_count >= 3
- unresolved_heuristic_conflict == true
- restricted_claim_type_present == true
- legal_review_required == true
# -----------------------------------------------------------------------------
# TELEMETRY
# -----------------------------------------------------------------------------
# Recommended for auditability. Required for automated governance pipelines.

telemetry:
log_policy_key: true
log_policy_version: true
log_rule_failures: true
log_retry_history: true
log_exception_usage: true
log_message_source_refs: true
log_proof_refs: true
log_claim_types: true
retain_validation_report: true
output_format: json
schema:
type: object
properties:
policy_key:
type: string
policy_version:
type: string
content_id:
type: string
content_type:
type: string
channel:
type: string
audience:
type: string
persona:
type: string
timestamp:
type: string
format: iso8601
message_source_refs:
type: array
items:
type: string
proof_refs:
type: array
items:
type: string
claim_types:
type: array
items:
type: string
rule_results:
type: array
items:
type: object
properties:
rule_id:
type: string
severity:
type: string
status:
type: string
reason:
type: string
score:
type: number
retry_count:
type: integer
exception_activations:
type: array
items:
type: object
properties:
exception_id:
type: string
reason:
type: string
matched_context:
type: object
final_decision:
type: string
validation_report_id:
type: string
effective_policy_ref:
type: string
# -----------------------------------------------------------------------------
# RELATED POLICY LINKS
# -----------------------------------------------------------------------------

related_standards:

* "{brand_id}.brand.core"
* "{brand_id}.standards.verbal-identity.tone-of-voice"
* "{brand_id}.standards.visual-identity"

related_applications:

* "{brand_id}.applications.linkedin"
* "{brand_id}.applications.thought-leadership"
* "{brand_id}.applications.case-study"
* "{brand_id}.applications.website"
* "{brand_id}.applications.newsletter"
* "{brand_id}.applications.event-announcement"
* "{brand_id}.applications.economic-buyer-message"

---
# {Brand Name} messaging framework

## How to complete this template

This is a Brando® Messaging Framework standard template. Complete the following steps in order before publishing.

1. Replace every `{placeholder}` value with brand-specific content.
2. Do not replace `<runtime_variable>` values. These are resolved at validation time by the Brando engine.
3. Set `status: draft` and `lifecycle_state: proposed` on first authoring. Update only after governance sign-off.
4. Set `schema.validation_status: ready_for_validation` on first authoring. Update only after a formal parse or review cycle.
5. Remove optional sections that do not apply, or retain them with placeholder values for future use.
6. Remove the `template` metadata block before policy validation.
7. Run the publishing checklist before changing `status` to `active`.

Placeholder reference:

| Token                         | Meaning                                                                                       | Example             |
| ----------------------------- | --------------------------------------------------------------------------------------------- | ------------------- |
| `{brand_id}`                  | Stable machine-readable brand identifier                                                      | `acme-corp`         |
| `{Brand Name}`                | Human-readable brand name                                                                     | `Acme Corp`         |
| `{messaging_principle_1}`     | First core messaging principle label                                                          | `audience_first`    |
| `{value_prop_1_id}`           | Approved value proposition identifier                                                         | `clarity_to_action` |
| `{pillar_1_id}`               | Approved message pillar identifier                                                            | `governed_growth`   |
| `{proof_point_1_id}`          | Approved proof point identifier                                                               | `audit_methodology` |
| `{contrast_type_value}`       | One of: category_norm, competitor, alternative_approach, status_quo                           | `competitor`        |
| `{proof_type_value}`          | One of: data, customer_story, credential, methodology, product_capability, third_party_source | `data`              |
| `{verification_status_value}` | One of: unverified, human_reviewed, source_verified, legally_approved                         | `human_reviewed`    |
| `{example_key_1}`             | Exemplar short key                                                                            | `website-hero`      |
| `<exemplar_key>`              | Runtime variable. Do not replace                                                              |                     |

---

## Purpose

This standard governs the approved messaging framework for {Brand Name}. It is designed for human creators, AI systems, validators, editors, sales teams, campaign teams, and publishing workflows.

The messaging framework defines what we say, why it matters, who it is for, and what proof supports it.

It governs:

* Positioning
* Core promise
* Value propositions
* Message pillars
* Audience messages
* Differentiators
* Proof points
* Claims
* Calls to action

---

## How to interpret this policy

This policy has five layers:

1. Message architecture defines the approved message system.
2. Claims policy defines what can and cannot be claimed.
3. Proof policy connects claims to evidence.
4. Exemplars show what good messaging looks like.
5. Execution rules determine whether output passes, warns, or fails.

The YAML front matter is the machine-executable layer. This Markdown body is the human-readable guidance layer. Where they conflict, the YAML governs.

If a rule conflicts with a higher-priority legal, regulatory, or safety policy, the higher-priority policy wins.

If a rule conflicts with an application-specific exception declared in the YAML, the declared exception applies.

---

## Messaging principles

### {Messaging Principle 1}

{Explain messaging principle 1 in plain language.}

Signals:

* {Signal 1}
* {Signal 2}
* {Signal 3}

Good examples:

* "{Good example 1}"
* "{Good example 2}"

Avoid:

* {Avoidance 1}
* {Avoidance 2}

---

### {Messaging Principle 2}

{Explain messaging principle 2 in plain language.}

Signals:

* {Signal 1}
* {Signal 2}
* {Signal 3}

Good examples:

* "{Good example 1}"
* "{Good example 2}"

Avoid:

* {Avoidance 1}
* {Avoidance 2}

---

### {Messaging Principle 3}

{Explain messaging principle 3 in plain language.}

Signals:

* {Signal 1}
* {Signal 2}
* {Signal 3}

Good examples:

* "{Good example 1}"
* "{Good example 2}"

Avoid:

* {Avoidance 1}
* {Avoidance 2}

---

## Message architecture

The message architecture is the source of truth for approved messaging.

Use it in this order:

1. Start with the positioning statement.
2. Support it with the core promise.
3. Select the relevant value proposition.
4. Choose the strongest message pillar for the audience and channel.
5. Attach proof points to any meaningful claim.
6. End with a clear next step where a CTA is required.

Campaigns may adapt language, but they must stay traceable to approved message sources.

---

## Claims and proof

Claims must be specific, proportionate, and supported.

Restricted claims need stronger evidence and may need legal review. This includes performance claims, market leadership claims, comparative claims, financial impact claims, risk reduction claims, and compliance claims.

Forbidden claims must not be used. This includes guaranteed outcomes, unsupported superiority, unverifiable market leadership, legal or regulatory assurance without approval, and competitor disparagement.

Proof points should be clear enough for a reviewer or validator to understand why the claim is allowed.

---

## Default execution expectations

Unless an explicit exception is declared in the YAML:

* Use an approved message source.
* Connect claims to approved proof points.
* Avoid forbidden claim types.
* Escalate restricted claims when legal review is required.
* Keep message hierarchy clear.
* Match the declared audience.
* Avoid generic category language.
* Use differentiators where distinction matters.
* Keep sentences within field-level hard limits declared in `field_applicability`.
* Include a clear call to action where `cta_required` is true.

---

## Exception model

Exceptions are allowed only when declared in the YAML `exceptions.declared` block. Undeclared exceptions hard fail.

Four exceptions are pre-declared in this template:

Quote preservation exception: quoted material may retain source phrasing even where it would otherwise fail messaging, claim, proof, deprecated-message, or sentence-length rules. Applies to `quotation` and `citation` content zones only.

Legal and regulated text exception: defers to higher-priority legal or regulatory policy where required by law or compliance.

Campaign adaptation exception: allows approved messages to be adapted for campaign context, provided the output remains traceable to approved source messages and proof points.

Legally approved claim exception: allows restricted claims when the exact claim, evidence, and wording have legal approval.

---

## Exemplars

Each exemplar below is referenced in the YAML by its `active_exemplar_key`. Validators use authoritative repository exemplars retrieved via `exemplars.storage.retrieval`, not the Markdown copies shown here.

### {exemplar-name}

Key: `{brand_id}.standards.verbal-identity.messaging-framework.exemplar.{example_key}`

"{Approved exemplar copy.}"

Why it works:

* {Reason 1}
* {Reason 2}
* {Reason 3}

---

## Anti-exemplars

Anti-exemplars are negative reference material for human review only. They are excluded from all deterministic and heuristic validation. They must not be scored, repaired, or published.

### {anti-exemplar-name}

"{Anti-exemplar copy.}"

Why it fails:

* {Reason 1}
* {Reason 2}
* {Reason 3}

---

## Validator interpretation notes

### Deterministic checks

Implement with direct pattern logic, lexicons, structural checks, measurable thresholds, and declared reference validation. Run in the order declared in `execution.rule_execution_order.phase_1_deterministic`.

Covered by: D001, D005, D006, D007, D008, D009, D010

### Heuristic checks

Implement using a classifier, scorer, or model-based evaluator. Run only after all deterministic checks pass or produce soft warnings only. Every heuristic check must return both a score and a reason. Never return a score alone.

Covered by: H001, H002, H003, H004, H005, H006, H007, H008, H009, H010

Note: H008, H009, and H010 are hard_fail severity. Classifier dependency does not reduce risk level. It changes the detection mechanism only. Heuristic hard-fail rules follow the same retry and escalation behaviour as deterministic hard-fail rules.

### Scale note for heuristic scores

H004 scores on a 0-100 percentage scale. All other heuristic rules score on a 0.0-1.0 probability scale. Do not normalise across these scales. See `execution.heuristic_decisioning.threshold_resolution`.

### Classifier reference

Any classifier referenced in a rule's `detect.requires_classifier` field must be declared in `classifiers`. Claim-dependent rules (H005, H008, H009, H010) depend on `claim_type_classifier`. See also `claims_policy.claim_language_triggers` for the input signals consumed by that classifier.

### Message architecture references

Validators should check that every referenced value proposition, message pillar, proof point, CTA, and audience segment resolves to a declared entry in `message_architecture` or `audience_messaging`. See `document_self_validation.validate_message_architecture_references`.

### Exemplar retrieval

Exemplars required by H004 are fetched via the protocol declared in `exemplars.storage.retrieval`. If retrieval fails, H004 is skipped with a soft warning per `fallback_behaviour`.

### Retry behaviour

On deterministic failure: repair at message component level, then re-evaluate before proceeding.
On heuristic failure: repair at paragraph or message asset level, then re-evaluate before proceeding.
After two failed repairs: trigger full regeneration.
After three total attempts: escalate to human review. Do not publish.

---

## Change log

| Version | Date       | Changes                    |
| ------- | ---------- | -------------------------- |
| 1.0.0   | YYYY-MM-DD | Initial published version. |

---

## Validation modes

This file can be validated in two modes.

Template validation: validates the structure of this reusable template. In this mode, the validator recognises `template.is_template: true` and does not require placeholder substitution.

Policy validation: validates an instantiated brand policy. In this mode, all `{placeholder}` values and `YYYY-MM-DD` date placeholders must be replaced, and the `template` metadata block must be removed.

---

## Publishing checklist

Before publication, confirm:

* All `{placeholder}` values have been replaced with brand-specific content.
* All `YYYY-MM-DD` date placeholders have been replaced with real ISO dates.
* No `<runtime_variable>` values have been replaced.
* The `template` metadata block has been removed.
* The YAML parses successfully with no errors.
* `schema.validation_status` reflects the actual validation state.
* `status` and `lifecycle_state` reflect the actual governance state.
* All rule IDs referenced in `execution.rule_execution_order` exist in `rules`.
* All exception IDs referenced in `unless_exception` blocks exist in `exceptions.declared`.
* All value proposition IDs referenced in message pillars resolve to declared entries.
* All proof point IDs referenced in claims, pillars, value propositions, and audience messages resolve.
* All CTA IDs referenced in audience messaging resolve.
* All audience IDs referenced in source fields resolve to declared `audience_messaging.segments`.
* All exemplar keys in `active_exemplar_keys` resolve, or `fallback_behaviour` is declared.
* Every forbidden word with a replacement remediation action has a `preferred_replacements` entry.
* Restricted claims have the proof and approval required by `claims_policy.evidence_requirements`.
* Forbidden claim types do not appear in governed copy.
* Positive exemplars do not violate any deterministic rule.
* Anti-exemplars are explicitly excluded from validation.
* All channel and content-type values in rules and `decision_policy` match `scope.applies_to`.
* H007 proof quality thresholds reflect this brand's claim risk model.
* The telemetry schema is valid and the policy key and version are attached to every validation report.
