---
# =============================================================================
#  BRANDO® APPLICATION POLICY TEMPLATE
#  brando-schema-1.0 | document_type: application_policy
#  =============================================================================
# 
#  PLACEHOLDER CONVENTION — READ BEFORE EDITING
#  -----------------------------------------------------------------------------
#  {curly_brace} placeholders must be replaced with brand-specific content
#  before this template is promoted to an application policy and policy-validated.
# 
#  <angle_bracket> values are runtime variables resolved at validation time.
#  Do NOT replace these. They are consumed by the validation engine.
# 
#  Quote every YAML value that contains a {curly_brace} placeholder.
#  Unquoted curly braces are interpreted as flow mapping syntax and will
#  cause a parse error. Quote all placeholder-containing values, including
#  list items, map keys, and scalar string values.
#  =============================================================================
#  -----------------------------------------------------------------------------
#  DOCUMENT IDENTITY
#  -----------------------------------------------------------------------------
#  Required. Stable, globally unique identifier for this application policy.
#  Recommended pattern: {brand_id}.applications.{application_id}

id: "{brand_id}.applications.{application_id}"
#  Required. Usually mirrors id. Use as the stable lookup key in policy
#  repositories, MCP servers, APIs, and audit logs.

key: "{brand_id}.applications.{application_id}"
#  Required. Human-readable title.

title: "{Brand Name} {Application Name} Application Policy"
#  Required. Short description used in repositories, UIs, search, and audit logs.

description: |
Application policy governing how {Brand Name} standards are applied to
{Application Name} outputs, including channel context, required components,
inherited standards, overrides, exceptions, validation rules, and publishing behaviour.
#  Required. Defines what kind of policy artefact this is.
#  Allowed values:
#  - standard | application | campaign | exception
#  - exemplar_set | lexicon | telemetry_schema

policy_kind: application
#  Required. Top-level governance pillar.
#  Allowed values controlled by Brando schema:
#  - standards | applications | campaigns | legal | market | safety

pillar: applications
#  Required. Category within the pillar. Use snake_case for controlled terms.

category: application_policy
#  Required. Subcategory within the category. Use snake_case for controlled terms.
#  Examples: linkedin | website | case_study | newsletter | pitch_deck | proposal

subcategory: "{application_id}"
#  Required. Used by Brando to distinguish policy standards from related artefacts.
#  Allowed values:
#  - policy_standard | application_policy | campaign_policy | exemplar
#  - exemplar_set | lexicon | classifier_spec | telemetry_schema | validation_report

document_type: application_policy
#  -----------------------------------------------------------------------------
#  TEMPLATE METADATA
#  -----------------------------------------------------------------------------
#  Identifies this file as a reusable template rather than an instantiated policy.
#  Remove this block when promoting to a brand-specific application policy.

template:
is_template: true
placeholder_status: contains_placeholders
instantiate_before_validation: true
#  -----------------------------------------------------------------------------
#  VERSIONING AND LIFECYCLE
#  -----------------------------------------------------------------------------
#  Required. Semantic version. Use MAJOR.MINOR.PATCH.
#  MAJOR: breaking schema or rule changes
#  MINOR: new rules, sections, scope, or behaviours
#  PATCH: typo, copy, clarification, non-breaking fixes

version: "1.0.0"
#  Required. Publication status.
#  Allowed values: draft | active | deprecated | archived

status: draft
#  Required. Governance lifecycle state.
#  Allowed values: proposed | in_review | approved | published | superseded | retired

lifecycle_state: proposed
#  Required once active/published. ISO date. Quote to prevent YAML date parsing.

effective_date: "YYYY-MM-DD"
#  Required. ISO date.

created: "YYYY-MM-DD"
#  Required. ISO date.

last_modified: "YYYY-MM-DD"
#  Recommended. ISO date for next scheduled governance review.

next_review: "YYYY-MM-DD"
#  -----------------------------------------------------------------------------
#  OWNERSHIP AND APPROVAL
#  -----------------------------------------------------------------------------

owner:
#  Required. Owning team or function.

team: "{Brand Team Name}"
#  Recommended. Steward responsible for governance upkeep.

steward: "{Steward Role or Name}"

approved_by:
#  Required once lifecycle_state is approved or published.

* "{Approving Team or Role}"
#  -----------------------------------------------------------------------------
#  SCHEMA METADATA
#  -----------------------------------------------------------------------------

schema:
#  Required. Schema class used by Brando.

type: BrandApplicationPolicy
#  Required. Schema version this document conforms to.

version: brando-schema-1.0
#  Required. Validation state of this file.
#  Allowed values:
#  - ready_for_validation: authored but not yet parsed or reviewed
#  - human_reviewed: reviewed by a human but not formally schema-validated
#  - schema_validated: parsed and validated against the declared schema

validation_status: ready_for_validation
#  -----------------------------------------------------------------------------
#  CLIENT NAMING MAP
#  -----------------------------------------------------------------------------
#  Optional but recommended. Maps client-facing terminology to Brando terms.
#  This field supports terminology mapping only. It does not affect enforcement logic.

naming:
client_term: "{Client-facing application name}"
canonical_term: Application Policy
policy_label: "{Application Name}"
rationale: |
{Explain how the client refers to this application, channel, format, or use case,
and how Brando should map it into the canonical applications layer. This field
does not affect enforcement logic.}
#  -----------------------------------------------------------------------------
#  APPLICATION PROFILE
#  -----------------------------------------------------------------------------
#  Required. Defines the application this policy governs.

application:
#  Required. Stable machine-readable application id.

id: "{application_id}"
#  Required. Human-readable application name.

name: "{Application Name}"
#  Required. Application type.
#  Allowed values may include:
#  - channel | content_format | sales_asset | editorial_asset | campaign_asset
#  - product_surface | event_asset | internal_enablement | partner_asset

type: "{application_type}"
#  Required. Primary channel or environment where this application is used.
#  Examples: linkedin | website | email | newsletter | pitch_deck | proposal

primary_channel: "{primary_channel}"
#  Recommended. Secondary channels if this application spans multiple outputs.

secondary_channels:
- "{secondary_channel_1}"
- "{secondary_channel_2}"
#  Required. Whether this policy governs a reusable application, not a campaign.

reusable_application: true
#  Recommended. Whether campaigns may further override this application policy.

campaign_overrides_allowed: true
#  Required. Declares whether this application policy can generate effective policies.

materialize_effective_application_policy: true
#  -----------------------------------------------------------------------------
#  SCOPE
#  -----------------------------------------------------------------------------
#  Required. Defines when this application policy applies.

scope:
applies_to:
# Required. Distribution or publishing environments.
# Do not mix channels with content types in this list.
channels:
- "{primary_channel}"
- "{secondary_channel_1}"
- "{secondary_channel_2}"

```
# Required. Types of content, components, assets, or outputs governed by this application.
# Composite outputs should be decomposed into governed fields before validation.
content_types:
  - "{application_content_type_1}"
  - "{application_content_type_2}"
  - headline
  - subhead
  - body_copy
  - call_to_action
  - image_asset
  - layout_asset
#  Recommended. Audience or persona types this application may target.
audiences:
  - marketing_manager
  - content_creator
  - executive_communications
  - sales
  - partner_marketing
  - new_hire
  - ai_agent
  - "{audience_1_id}"
  - "{audience_2_id}"
#  Recommended. Zones within content or assets.
content_zones:
  - rendered_copy
  - visual_asset
  - logo_zone
  - image_zone
  - metadata
  - quotation
  - citation
  - legal_disclaimer
  - platform_ui_overlay
#  Recommended. Output contexts.
output_contexts:
  - generated_content
  - edited_content
  - human_authored_content
  - ai_assisted_content
  - final_published_asset
```

excludes:
content_types:
- legal_disclaimer
- regulated_disclosure
- invoice
- procurement_template

notes:
- Applies to generated, edited, and assembled application-specific outputs.
- Does not replace underlying brand standards. It resolves, narrows, or contextualises them.
- Does not apply to legal or compliance text unless a downstream policy explicitly says so.
- Does not govern one-off campaign strategy unless a campaign policy inherits from this application.
#  -----------------------------------------------------------------------------
#  POLICY PRECEDENCE
#  -----------------------------------------------------------------------------
#  Recommended. Defines how this policy behaves when other policies also apply.

policy_precedence:
priority_order_highest_first:
- global.safety
- global.regulatory
- market.legal
- enterprise.brand-core
- "{brand_id}.campaigns.*"
- "{brand_id}.applications.{application_id}"
- "{brand_id}.standards.verbal-identity.messaging-framework"
- "{brand_id}.standards.verbal-identity.tone-of-voice"
- "{brand_id}.standards.visual-identity.logo"
- "{brand_id}.standards.visual-identity.colour"
- "{brand_id}.standards.visual-identity.typography"
- "{brand_id}.standards.visual-identity.layout"
- "{brand_id}.standards.visual-identity.imagery"
- "{brand_id}.standards.visual-identity.iconography"
- "{brand_id}.standards.visual-identity.illustration"
- "{brand_id}.standards.motion"

conflict_resolution:
# Allowed values:
# - higher_priority_wins | most_restrictive_wins | explicit_exception_required
mode: most_restrictive_wins
notes:
- Legal, regulatory, safety, and market policies always override application preferences.
- Campaign policy may narrow or contextualise this application policy only within its declared scope.
- Application policy may narrow standards for a channel or format but must not weaken higher-priority rules.
- Where content length and layout density conflict, comprehension and accessibility checks govern the final decision.
- Exceptions must be explicit and machine-readable to override defaults.
#  -----------------------------------------------------------------------------
#  INHERITANCE
#  -----------------------------------------------------------------------------
#  Required. Application policies should inherit from relevant standards rather than duplicate them.

inheritance:
inherits_from:
- "{brand_id}.brand.core"
- "{brand_id}.standards.verbal-identity.tone-of-voice"
- "{brand_id}.standards.verbal-identity.messaging-framework"
- "{brand_id}.standards.visual-identity.colour"
- "{brand_id}.standards.visual-identity.logo"
- "{brand_id}.standards.visual-identity.typography"
- "{brand_id}.standards.visual-identity.layout"
- "{brand_id}.standards.visual-identity.imagery"
- "{brand_id}.standards.visual-identity.iconography"
- "{brand_id}.standards.visual-identity.illustration"
- "{brand_id}.standards.motion"

may_be_overridden_by:
- "{brand_id}.campaigns.*"
- "{brand_id}.market.*"
- "{brand_id}.legal.*"
- "{brand_id}.exceptions.*"

override_constraints:
application_may_narrow_standards: true
application_may_weaken_legal_safety_or_regulatory_rules: false
campaign_may_narrow_application_policy: true
campaign_may_weaken_application_policy_without_exception: false
#  -----------------------------------------------------------------------------
#  RESOLUTION BEHAVIOUR
#  -----------------------------------------------------------------------------
#  Recommended for executable policy systems.

resolution:
resolve_inheritance_before_validation: true
resolve_standard_dependencies_before_rule_execution: true
resolve_application_overrides_before_rule_execution: true
resolve_campaign_overrides_before_rule_execution: true
resolve_exceptions_before_rule_execution: true
materialize_effective_policy: true
effective_policy_output:
include_resolved_standards: true
include_application_overrides: true
include_campaign_overrides: true
include_applied_exceptions: true
include_precedence_path: true
include_validation_rules: true
include_required_components: true
#  -----------------------------------------------------------------------------
#  STANDARD DEPENDENCIES
#  -----------------------------------------------------------------------------
#  Required. Declares which standards this application depends on.
#  Version ranges are recommended to prevent breaking changes from silently changing behaviour.

standard_dependencies:
required:
- id: "{brand_id}.brand.core"
version: "^1.0.0"
role: brand_foundation

```
- id: "{brand_id}.standards.verbal-identity.tone-of-voice"
  version: "^1.0.0"
  role: expression_rules

- id: "{brand_id}.standards.verbal-identity.messaging-framework"
  version: "^1.0.0"
  role: meaning_claims_and_proof

- id: "{brand_id}.standards.visual-identity.colour"
  version: "^1.0.0"
  role: colour_tokens_and_contrast

- id: "{brand_id}.standards.visual-identity.logo"
  version: "^1.0.0"
  role: logo_usage_and_clearspace

- id: "{brand_id}.standards.visual-identity.typography"
  version: "^1.0.0"
  role: type_system_and_readability
```

optional:
- id: "{brand_id}.standards.visual-identity.layout"
version: "^1.0.0"
role: layout_grid_spacing_and_density

```
- id: "{brand_id}.standards.visual-identity.imagery"
  version: "^1.0.0"
  role: imagery_subject_style_and_rights

- id: "{brand_id}.standards.visual-identity.iconography"
  version: "^1.0.0"
  role: icon_usage_and_semantics

- id: "{brand_id}.standards.visual-identity.illustration"
  version: "^1.0.0"
  role: illustration_usage_and_semantics

- id: "{brand_id}.standards.motion"
  version: "^1.0.0"
  role: motion_tokens_safety_and_timing
```

fallback_behaviour:
if_required_standard_unavailable: hard_fail
if_optional_standard_unavailable: skip_with_warning
cached_pass_allowed: true
cached_pass_max_age_seconds: 604800
cached_pass_requires_prior_schema_validated_state: true
log_cached_pass_usage: true
#  -----------------------------------------------------------------------------
#  APPLICATION REQUIREMENTS
#  -----------------------------------------------------------------------------
#  Required. Defines the minimum component contract for this application.

application_requirements:
required_components:
- id: primary_message
source_standard: "{brand_id}.standards.verbal-identity.messaging-framework"
required: true
allowed_sources:
- positioning_statement
- core_promise
- value_proposition
- audience_message

```
- id: tone_profile
  source_standard: "{brand_id}.standards.verbal-identity.tone-of-voice"
  required: true
  allowed_values:
    - standard
    - compressed
    - conversational
    - formal_but_direct
    - strategic_and_evidence_led

- id: visual_treatment
  source_standard: "{brand_id}.standards.visual-identity.layout"
  required: true
  allowed_values:
    - text_only
    - image_led
    - logo_led
    - data_led
    - editorial
    - campaign

- id: call_to_action
  source_standard: "{brand_id}.standards.verbal-identity.messaging-framework"
  required_when:
    cta_required: true
```

conditional_components:
- id: logo
required_when:
branded_asset: true

```
- id: proof_reference
  required_when:
    claim_present: true

- id: image_rights_reference
  required_when:
    imagery_used: true

- id: accessibility_alt_text
  required_when:
    visual_asset_contains_meaning: true

- id: legal_approval_reference
  required_when:
    restricted_claim_type_present: true
```
#  -----------------------------------------------------------------------------
#  APPLICATION OVERRIDES
#  -----------------------------------------------------------------------------
#  Recommended. Defines application-level adjustments to inherited standards.
#  These should narrow, contextualise, or operationalise inherited standards, not duplicate them.

application_overrides:
tone_of_voice:
enabled: true
source_ref: "{brand_id}.standards.verbal-identity.tone-of-voice"
overrides:
sentence_style:
target_max_words: "{target_max_words}"
hard_max_words: "{hard_max_words}"
questions:
minimum: "{question_minimum}"
calls_to_action:
required: "{cta_required_boolean}"
tone_adjustment: "{application_tone_adjustment}"

messaging_framework:
enabled: true
source_ref: "{brand_id}.standards.verbal-identity.messaging-framework"
overrides:
required_message_sources:
- "{message_source_1}"
- "{message_source_2}"
proof_required: "{proof_required_boolean}"
restricted_claims_allowed_with_approval: true
forbidden_claims_allowed: false

colour:
enabled: true
source_ref: "{brand_id}.standards.visual-identity.colour"
overrides:
palette_mode: "{palette_mode}"
minimum_contrast_ratio: "{minimum_contrast_ratio}"
print_context_requires_cmyk: "{print_context_requires_cmyk_boolean}"
cmyk_materialization_profile: ISO Coated v2 (ECI)
cmyk_materialization_logs_warning: true

logo:
enabled: true
source_ref: "{brand_id}.standards.visual-identity.logo"
overrides:
logo_required: "{logo_required_boolean}"
allowed_logo_variants:
- "{logo_variant_1}"
- "{logo_variant_2}"
minimum_logo_size: "{minimum_logo_size}"
clearspace_required: true

typography:
enabled: true
source_ref: "{brand_id}.standards.visual-identity.typography"
overrides:
allowed_type_roles:
- heading
- body
- caption
- call_to_action
maximum_font_requests: "{maximum_font_requests}"
maximum_font_payload_kb: "{maximum_font_payload_kb}"

layout:
enabled: true
source_ref: "{brand_id}.standards.visual-identity.layout"
overrides:
allowed_layout_patterns:
- "{layout_pattern_1}"
- "{layout_pattern_2}"
target_aspect_ratios:
- "{aspect_ratio_1}"
- "{aspect_ratio_2}"
breakpoint_validation_required: true
dynamic_platform_safe_area_required: true

imagery:
enabled: "{imagery_enabled_boolean}"
source_ref: "{brand_id}.standards.visual-identity.imagery"
overrides:
image_allowed: "{image_allowed_boolean}"
image_rights_required: true
likeness_collision_check_required: true
generic_stock_risk_threshold: "{generic_stock_risk_threshold}"

motion:
enabled: "{motion_enabled_boolean}"
source_ref: "{brand_id}.standards.motion"
overrides:
motion_allowed: "{motion_allowed_boolean}"
reduced_motion_variant_required: true
maximum_payload_kb: "{maximum_motion_payload_kb}"
#  -----------------------------------------------------------------------------
#  FORMAT AND PLATFORM CONSTRAINTS
#  -----------------------------------------------------------------------------
#  Recommended. Defines the operational constraints of the application.

format_constraints:
#  Recommended. Large or fast-changing platform specifications may be referenced
#  externally to keep this application policy readable and maintainable.

external_spec_refs:
- id: "{platform_spec_ref_1}"
source: "{brand_id}.specs.platforms.{platform_id}:^1.0.0"
required: false
fallback_behaviour: use_inline_target_formats_with_warning

target_formats:
- id: "{format_1_id}"
label: "{Format 1 label}"
channel: "{primary_channel}"
aspect_ratio: "{aspect_ratio_1}"
min_width_px: "{min_width_px}"
min_height_px: "{min_height_px}"
max_file_size_kb: "{max_file_size_kb}"
allowed_file_types:
- png
- jpg
- svg
- pdf
- mp4
required_safe_areas:
- primary_message_safe_area
- logo_safe_area
- call_to_action_safe_area

```
- id: "{format_2_id}"
  label: "{Format 2 label}"
  channel: "{secondary_channel_1}"
  aspect_ratio: "{aspect_ratio_2}"
  min_width_px: "{min_width_px}"
  min_height_px: "{min_height_px}"
  max_file_size_kb: "{max_file_size_kb}"
  allowed_file_types:
    - png
    - jpg
    - svg
    - pdf
    - mp4
  required_safe_areas:
    - primary_message_safe_area
    - logo_safe_area
```

platform_ui_overlays:
# Use for social platforms, video players, CMS chrome, or app UI that may cover content.
enabled: true
source: "{platform_overlay_spec_ref}"
validate_required_content_not_obscured: true

responsive_validation:
required: true
target_aspect_ratios:
- "1:1"
- "4:5"
- "9:16"
- "16:9"
target_breakpoints:
- mobile
- tablet
- desktop
#  -----------------------------------------------------------------------------
#  FIELD APPLICABILITY
#  -----------------------------------------------------------------------------
#  Required if different application fields need different thresholds.
#  Missing entries should produce a schema warning or validation error.

field_applicability:
headline:
required: "{headline_required_boolean}"
sentence_style:
target_max_words: 10
hard_max_words: 14
proof_required: false
cta_required: false

subhead:
required: "{subhead_required_boolean}"
sentence_style:
target_max_words: 16
hard_max_words: 24
proof_required: false
cta_required: false

body_copy:
required: "{body_copy_required_boolean}"
sentence_style:
target_max_words: 18
hard_max_words: 28
proof_required: true
cta_required: true

call_to_action:
required: "{cta_required_boolean}"
sentence_style:
target_max_words: 10
hard_max_words: 14
proof_required: false
cta_required: false

image_asset:
required: "{image_asset_required_boolean}"
rights_required: true
alt_text_required: true
focal_point_required: true
multi_aspect_safe_area_required: true

logo:
required: "{logo_required_boolean}"
clearspace_required: true
minimum_contrast_required: true
responsive_variant_required: true

layout_asset:
required: true
grid_required: true
safe_area_required: true
maximum_visual_density_score: 0.72
cognitive_load_check_required: true

motion_asset:
required: false
reduced_motion_variant_required: true
vestibular_safety_check_required: true
payload_budget_required: true
#  -----------------------------------------------------------------------------
#  AI AGENT REMEDIATION CONTRACT
#  -----------------------------------------------------------------------------
#  Recommended. Ensures machine repairs are returned as executable instructions,
#  not only human-readable prose.

ai_agent_remediation:
output_format: json
include_negative_prompt_when_prompt_output_fidelity_fails: true
instruction_schema:
type: object
required:
- violation_id
- policy_path
- failing_component
- remediation_action
- constraints_to_preserve
properties:
violation_id:
type: string
policy_path:
type: string
failing_component:
type: string
remediation_action:
type: string
negative_prompt:
type: string
constraints_to_preserve:
type: array
items:
type: string
suggested_next_prompt:
type: string
#  -----------------------------------------------------------------------------
#  CONTENT ASSEMBLY POLICY
#  -----------------------------------------------------------------------------
#  Recommended. Defines how verbal, visual, and asset components are assembled.

content_assembly_policy:
approved_source_required: true
constraint_collision_resolution:
# When an approved source message exceeds the available application format,
# format legibility and comprehension win. The output must use a compressed
# variant that remains traceable to the approved source message.
mode: format_and_comprehension_win
compressed_variant_required_when:
approved_message_exceeds_field_limit: true
compressed_variant_must_preserve:
- core_claim
- audience_benefit
- proof_requirement
- legal_qualifiers
- approved_message_source_ref
human_review_required_when:
- legal_qualifier_must_be_shortened
- restricted_claim_type_present
- compressed_variant_changes_claim_meaning

component_traceability_required: true
generated_asset_prompt_trace_required: true
prompt_output_fidelity_required: true

required_trace_fields:
- policy_key
- policy_version
- application_policy_key
- inherited_standard_refs
- message_source_refs
- proof_refs
- visual_token_refs
- layout_pattern_ref
- asset_rights_refs
- exception_refs

assembly_rules:
- id: primary_message_before_detail
description: Primary message must be identifiable before supporting detail.

```
- id: proof_attached_to_claims
  description: Claims must carry proof references where required by the Messaging Framework standard.

- id: visual_hierarchy_supports_message
  description: Visual hierarchy must support the declared message priority.

- id: cta_not_obscured
  description: Required calls to action must not be obscured by platform overlays, crop zones, or layout density.

- id: no_orphaned_components
  description: Each included component must support a declared message, audience need, proof point, or visual function.
```
#  -----------------------------------------------------------------------------
#  EXCEPTIONS
#  -----------------------------------------------------------------------------
#  Required for executable governance. All exceptions must be declared here.
#  Undeclared exceptions hard fail.

exceptions:
undeclared_exception_behaviour: hard_fail
validation:
exception_must_be_declared_in_policy: true
exception_must_match_content_context: true
log_all_exception_activations: true

declared:
- id: legal_text_exception
description: Legal or regulated text may override application preferences where required by law or compliance.
when:
policy_context:
higher_priority_policy_matches:
- "{brand_id}.legal.*"
- global.regulatory
override:
enforcement_mode: defer_to_higher_policy

```
- id: quote_preservation_exception
  description: Quoted material may retain source phrasing where it would otherwise fail tone, messaging, or layout rules.
  when:
    content_zone:
      - quotation
      - citation
  override:
    enforcement_mode: quoted_material_relaxed
    skip_rules:
      - D003
      - D004
      - D005
      - H001
      - H002

- id: campaign_override_exception
  description: Campaign policy may override this application policy only where the campaign policy declares a scoped override and remains compliant with higher-priority standards.
  when:
    policy_context:
      higher_priority_policy_matches:
        - "{brand_id}.campaigns.*"
  override:
    enforcement_mode: campaign_override_allowed
    requirements:
      - override_scope_required
      - inherited_standard_trace_required
      - no_legal_safety_or_regulatory_weakening

- id: platform_constraint_exception
  description: Platform constraints may require minor formatting variation where the platform specification prevents exact standard compliance.
  when:
    platform_constraint:
      unavoidable: true
  override:
    enforcement_mode: platform_constraint_relaxed
    requirements:
      - platform_constraint_ref_required
      - nearest_compliant_variant_required
      - human_review_required
```
#  -----------------------------------------------------------------------------
#  EXEMPLARS
#  -----------------------------------------------------------------------------
#  Recommended. Positive examples for human guidance and semantic scoring.

exemplars:
minimum_review_count: 2

markdown_examples:
role: human_readable_copy
authoritative: false
excluded_from_validation: true

storage:
# Allowed values: inline | referenced | external_repository
mode: referenced
source_key: "{brand_id}.applications.{application_id}"
section: exemplars
load_at_validation: true
retrieval:
# Allowed protocol values:
# - brando_policy_repo | local_file | http | mcp_resource
protocol: brando_policy_repo
base_path: /policies/exemplars/
key_format: "<exemplar_key>.md"
auth: service_account
timeout_seconds: 5
cache_ttl_seconds: 300

fallback_behaviour:
if_exemplars_unavailable: skip_rule_with_warning
affected_rules:
- H004

active_exemplar_keys:
- "{brand_id}.applications.{application_id}.exemplar.{example_key_1}"
- "{brand_id}.applications.{application_id}.exemplar.{example_key_2}"

source_contexts:
channels:
- "{primary_channel}"
- "{secondary_channel_1}"
content_types:
- "{application_content_type_1}"
- "{application_content_type_2}"
#  -----------------------------------------------------------------------------
#  ANTI-EXEMPLARS
#  -----------------------------------------------------------------------------
#  Optional. Negative examples for human review only.

anti_exemplars:
enforcement_role: negative_reference_only
used_by_rules: []
excluded_from_deterministic_validation: true
excluded_from_heuristic_validation: true
sources:
- id: "{anti_exemplar_source_1}"
label: "{Human-readable label}"
for_human_review_only: true
#  -----------------------------------------------------------------------------
#  DOCUMENT SELF-VALIDATION
#  -----------------------------------------------------------------------------
#  Recommended. Defines which parts of this file are subject to rule validation.

document_self_validation:
validate_yaml_structure: true
validate_required_standard_dependencies: true
validate_application_override_paths: true
validate_field_applicability_coverage: true
validate_component_traceability: true
validate_exception_references: true
validate_exemplar_references: true
validate_channel_content_type_alignment: true
validate_format_constraints: true
validate_no_circular_policy_references: true

exclude_markdown_guidance: true
exclude_change_log: true
exclude_comments: true
exclude_anti_exemplars: true
exclude_markdown_exemplar_copies: true

notes:
- Application policies must not duplicate full standard definitions.
- Application overrides must resolve to declared paths in inherited standards.
- All referenced standards must be available or covered by declared fallback behaviour.
- All exceptions referenced in rules must resolve to exceptions.declared.
- YAML comments are excluded as they are stripped before rule execution.
#  -----------------------------------------------------------------------------
#  CLASSIFIERS
#  -----------------------------------------------------------------------------
#  Optional. Declare judgement-based classifiers required by heuristic rules.

classifiers:
application_fit_classifier:
description: |
Scores whether the assembled output fits the declared application,
channel, audience, and format context.
output:
type: object
properties:
application_fit_score:
type: number
confidence:
type: number
reason:
type: string
suggested_repairs:
type: array
items:
type: string
used_by_rules:
- H001

cross_standard_coherence_classifier:
description: |
Scores whether tone, messaging, visual treatment, layout, typography,
imagery, and CTA work together without semantic or visual conflict.
output:
type: object
properties:
coherence_score:
type: number
confidence:
type: number
reason:
type: string
conflict_paths:
type: array
items:
type: string
used_by_rules:
- H002

audience_context_classifier:
description: |
Scores whether the output reflects the declared audience need,
decision context, knowledge level, and expected next action.
output:
type: object
properties:
audience_context_score:
type: number
confidence:
type: number
reason:
type: string
used_by_rules:
- H003

exemplar_alignment_classifier:
description: |
Scores whether the application output aligns with approved exemplars
for the same application, channel, or format.
output:
type: object
properties:
exemplar_alignment_score:
type: number
confidence:
type: number
reason:
type: string
used_by_rules:
- H004

prompt_output_fidelity_classifier:
description: |
Compares the structured prompt or generation brief against the rendered
output. Detects whether required application, channel, standard, component,
or format instructions were ignored or contradicted. When the check fails,
the validator should produce both a positive repair instruction and a
negative prompt that prevents the failed attributes from reappearing.
output:
type: object
properties:
prompt_output_fidelity_score:
type: number
confidence:
type: number
reason:
type: string
mismatched_requirements:
type: array
items:
type: string
negative_prompt:
type: string
suggested_next_prompt:
type: string
used_by_rules:
- H005

comprehension_risk_classifier:
description: |
Scores whether the final application output is likely to be understood
quickly and correctly by the declared audience in the target environment.
The score should use a 0.0 to 1.0 scale and may combine text density,
graphic element count, whitespace ratio, contrast risk, saliency conflict,
reading order, and platform overlay obstruction.
calculation_guidance:
suggested_formula: "min(1.0, (text_area_ratio * 0.30) + (graphic_element_count * 0.05) + (saliency_conflict_score * 0.25) + (contrast_risk_score * 0.20) + (overlay_obstruction_score * 0.20))"
required_diagnostics:
- text_area_ratio
- graphic_element_count
- whitespace_ratio
- saliency_conflict_score
- contrast_risk_score
- overlay_obstruction_score
- crowded_regions
repair_guidance:
- Return coordinate regions for crowded or obstructed areas.
- Identify whether the repair should reduce text, reduce visual elements, increase whitespace, move CTA, or change layout pattern.
output:
type: object
properties:
comprehension_risk_score:
type: number
confidence:
type: number
reason:
type: string
crowded_regions:
type: array
items:
type: object
suggested_repairs:
type: array
items:
type: string
used_by_rules:
- H006
#  -----------------------------------------------------------------------------
#  EXECUTION
#  -----------------------------------------------------------------------------
#  Required for executable validation.

execution:
#  Allowed values: blocking | advisory | audit_only

enforcement_mode: blocking

max_retry_attempts: 3
escalate_to_human_after: 3

rule_id_policy:
deterministic_pattern: "^D[0-9]{3}$"
heuristic_pattern: "^H[0-9]{3}[A-Z]?$"

rule_execution_order:
phase_0_resolution:
- resolve_inherited_standards
- resolve_application_overrides
- resolve_campaign_overrides
- resolve_exceptions
- materialize_effective_policy

```
phase_1_deterministic:
  - D001
  - D002
  - D003
  - D004
  - D005
  - D006
  - D007
  - D008
  - D009
  - D010
  - D011
  - D012
  - D013
  - D014
  - D015
  - D016

phase_2_heuristic:
  - H001
  - H002
  - H003
  - H004
  - H005
  - H006

notes: Run resolution first, then deterministic rules, then heuristic rules if deterministic rules pass or produce soft warnings only.
```

heuristic_decisioning:
low_confidence_ignore_below: 0.60
medium_confidence_warn_at_or_above: 0.60
high_confidence_enforce_at_or_above: 0.85
threshold_resolution:
policy: per_rule_takes_precedence
notes:
- All heuristic rules use a 0.0 to 1.0 scale.
- Where a rule declares its own threshold, that value governs for that rule.
- Global heuristic_decisioning thresholds apply only where a rule does not declare its own threshold.

retry_strategy:
mode: targeted_repair_then_regenerate
repair_scope:
missing_reference_failures: metadata_or_reference_level
component_failures: component_level
format_failures: layout_or_export_level
cross_standard_failures: affected_standard_path_level
heuristic_failures: asset_or_output_level
after_two_failed_repairs: full_regeneration
repair_instruction_format:
include_violation_id: true
include_failing_text_or_asset_ref: true
include_policy_path: true
include_remediation_action: true
include_inherited_standard_ref: true
include_application_override_ref: true
include_suggested_repairs: true
sequence:
- repair_missing_references
- re-evaluate
- repair_component_or_format_failures
- re-evaluate
- repair_cross_standard_conflicts
- re-evaluate
- regenerate_if_still_failing

output_contract:
must_pass:
- no_hard_fail_rules
- required_standard_dependencies_available_or_cached
- application_scope_matches_output_context
- required_components_present
- no_forbidden_override_paths
may_pass_with_warnings:
- soft_warn_only
- optional_standard_unavailable_with_declared_fallback
- cached_pass_with_warning
must_block:
- any_hard_fail_after_max_retries
- required_standard_dependency_missing
- undeclared_exception_used
- application_scope_mismatch
- legal_safety_or_regulatory_conflict
- required_component_missing
#  -----------------------------------------------------------------------------
#  RULES
#  -----------------------------------------------------------------------------
#  Required. Rules are executable validation checks.

rules:
deterministic:
- id: D001
name: required_standard_dependency_missing
severity: hard_fail
detect:
method: dependency_resolution_check
source: standard_dependencies.required
fallback: standard_dependencies.fallback_behaviour
remediation:
action: restore_required_standard_reference_or_block_validation

```
- id: D002
  name: application_scope_mismatch
  severity: hard_fail
  detect:
    method: scope_match_check
    required_contexts:
      - scope.applies_to.channels
      - scope.applies_to.content_types
      - application.primary_channel
  remediation:
    action: route_to_correct_application_policy_or_update_scope

- id: D003
  name: required_component_missing
  severity: hard_fail
  detect:
    method: required_component_check
    source: application_requirements.required_components
    conditional_source: application_requirements.conditional_components
  remediation:
    action: add_required_component_or_declare_valid_exception

- id: D004
  name: inherited_standard_override_path_invalid
  severity: hard_fail
  detect:
    method: override_path_resolution_check
    source: application_overrides
    required_reference_source: standard_dependencies
  remediation:
    action: correct_override_path_or_remove_invalid_override

- id: D005
  name: forbidden_standard_weakening_detected
  severity: hard_fail
  detect:
    method: override_constraint_check
    source: inheritance.override_constraints
    forbidden_actions:
      - weaken_legal_rule
      - weaken_safety_rule
      - weaken_regulatory_rule
      - disable_required_standard_without_exception
  remediation:
    action: remove_forbidden_override_or_create_higher_priority_exception

- id: D006
  name: unresolved_exception_reference
  severity: hard_fail
  detect:
    method: exception_reference_check
    source: exceptions.declared
    references_from:
      - rules.deterministic.unless_exception
      - rules.heuristic.unless_exception
      - content_assembly_policy.required_trace_fields
  remediation:
    action: declare_exception_or_remove_reference

- id: D007
  name: field_applicability_missing
  severity: hard_fail
  detect:
    method: field_applicability_coverage_check
    content_types_from: scope.applies_to.content_types
    fields_from: field_applicability
    check_only_fields_used_by_rules: true
  remediation:
    action: add_field_applicability_entry_or_remove_field_from_scope

- id: D008
  name: format_constraint_violation
  severity: hard_fail
  detect:
    method: format_constraint_check
    source: format_constraints.target_formats
    check:
      - aspect_ratio
      - min_width_px
      - min_height_px
      - max_file_size_kb
      - allowed_file_types
  remediation:
    action: export_to_compliant_format_or_select_valid_application_format

- id: D009
  name: platform_safe_area_violation
  severity: hard_fail
  detect:
    method: dynamic_safe_area_check
    source: format_constraints.platform_ui_overlays
    required_content:
      - primary_message
      - logo
      - call_to_action
    target_aspect_ratios_from: format_constraints.responsive_validation.target_aspect_ratios
  remediation:
    action: reposition_required_content_inside_dynamic_safe_area

- id: D010
  name: traceability_metadata_missing
  severity: hard_fail
  detect:
    method: trace_field_presence_check
    source: content_assembly_policy.required_trace_fields
  remediation:
    action: attach_required_traceability_metadata

- id: D011
  name: circular_policy_reference_detected
  severity: hard_fail
  detect:
    method: graph_cycle_check
    scope:
      - inheritance
      - standard_dependencies
      - application_overrides
      - policy_precedence
  remediation:
    action: remove_circular_reference_or_split_policy_dependency

- id: D012
  name: component_not_supported_by_message_or_visual_role
  severity: soft_warn
  detect:
    method: orphaned_component_check
    source: content_assembly_policy.assembly_rules
    required_support:
      - declared_message
      - audience_need
      - proof_point
      - visual_function
  remediation:
    action: remove_or_attach_component_to_declared_purpose

- id: D013
  name: call_to_action_inception_detected
  severity: hard_fail
  applies_to:
    - call_to_action
  detect:
    method: recursive_requirement_check
    forbidden_condition:
      field: call_to_action
      requires_self: true
  remediation:
    action: set_cta_required_false_for_call_to_action_field

- id: D014
  name: constraint_priority_conflict_detected
  severity: hard_fail
  detect:
    method: constraint_collision_check
    source: content_assembly_policy.constraint_collision_resolution
    collision_types:
      - approved_message_exceeds_field_limit
      - legal_qualifier_exceeds_safe_area
      - required_proof_exceeds_layout_capacity
      - cta_required_but_not_available_in_format
  remediation:
    action: create_compressed_traceable_variant_or_escalate_to_human_review

- id: D015
  name: tone_image_alignment_failure
  severity: hard_fail
  detect:
    method: cross_standard_alignment_check
    when:
      imagery_used: true
    inputs:
      tone_adjustment: application_overrides.tone_of_voice.overrides.tone_adjustment
      imagery_generic_stock_risk: application_overrides.imagery.overrides.generic_stock_risk_threshold
    forbidden_pairings:
      - tone_adjustment: strategic_and_evidence_led
        imagery_generic_stock_risk_greater_than: 0.30
      - tone_adjustment: formal_but_direct
        imagery_generic_stock_risk_greater_than: 0.40
  remediation:
    action: replace_image_with_more_specific_evidence_led_visual

- id: D016
  name: reading_gravity_violation
  severity: soft_warn
  detect:
    method: reading_gravity_check
    target_component: primary_message
    preferred_regions_by_aspect_ratio:
      "1:1":
        - top_left
        - focal_center
      "4:5":
        - top_left
        - upper_center
      "9:16":
        - upper_center
        - focal_center
      "16:9":
        - top_left
        - left_center
    allow_override_when:
      dominant_focal_subject_requires_alternate_hierarchy: true
  remediation:
    action: reposition_primary_message_to_preferred_reading_gravity_region
```

heuristic:
- id: H001
name: weak_application_fit
severity: hard_fail
detect:
method: application_fit_classifier
threshold: 0.80
remediation:
action: revise_output_for_application_channel_format_and_audience

```
- id: H002
  name: weak_cross_standard_coherence
  severity: soft_warn
  detect:
    method: cross_standard_coherence_classifier
    threshold: 0.75
  remediation:
    action: align_tone_message_visual_layout_and_cta

- id: H003
  name: weak_audience_context_fit
  severity: soft_warn
  detect:
    method: audience_context_classifier
    threshold: 0.75
  remediation:
    action: adapt_output_to_declared_audience_need_and_next_step

- id: H004
  name: weak_application_exemplar_alignment
  severity: soft_warn
  detect:
    method: exemplar_alignment_classifier
    exemplar_set: exemplars.active_exemplar_keys
    threshold: 0.70
  remediation:
    action: revise_toward_approved_application_patterns

- id: H005
  name: prompt_output_fidelity_failure
  severity: hard_fail
  detect:
    method: prompt_output_fidelity_classifier
    threshold: 0.85
    output_requires:
      - mismatched_requirements
      - negative_prompt
      - suggested_next_prompt
  remediation:
    action: regenerate_or_repair_output_to_match_declared_prompt_requirements
    ai_agent_instruction:
      format: json
      include_negative_prompt: true
      preserve_constraints:
        - approved_message_source_ref
        - proof_refs
        - format_constraints
        - inherited_standard_refs
        - legal_qualifiers

- id: H006
  name: comprehension_risk_too_high
  severity: hard_fail
  detect:
    method: comprehension_risk_classifier
    threshold: 0.80
    direction: fail_at_or_above
  remediation:
    action: reduce_density_clarify_hierarchy_or_split_output
```
#  -----------------------------------------------------------------------------
#  DECISION POLICY
#  -----------------------------------------------------------------------------
#  Required. Defines pass/warn/fail and publishing behaviour.

decision_policy:
pass_conditions:
- zero_hard_failures
warn_conditions:
- one_or_more_soft_warnings
fail_conditions:
- one_or_more_hard_failures
publish_conditions:
- status in [pass, warn]
- hard_fail_count == 0
- required_components_present == true
- application_scope_matched == true

warn_behaviour:
auto_publish_allowed: true
conflict_resolution:
mode: most_restrictive_wins
notes:
- If any matched channel, content type, component, or inherited standard requires human sign-off, human sign-off is required.
- Auto-publish is allowed only when no matched rule requires human sign-off.
requires_human_sign_off_on_warn:
channels:
- website
- pitch_deck
- proposal
- sales_enablement
content_types:
- thought_leadership
- economic_buyer_message
- case_study
conditions:
- restricted_claim_type_present
- optional_standard_unavailable
- cached_pass_used
- platform_constraint_exception_used
allows_auto_publish_on_warn:
channels:
- linkedin
- newsletter
content_types:
- social_post
- event_announcement

human_review_conditions:
- retry_count >= 3
- unresolved_heuristic_conflict == true
- platform_constraint_exception_used == true
- cached_pass_used == true
- legal_review_required == true
#  -----------------------------------------------------------------------------
#  TELEMETRY
#  -----------------------------------------------------------------------------
#  Recommended for auditability. Required for automated governance pipelines.

telemetry:
log_policy_key: true
log_policy_version: true
log_application_policy_key: true
log_application_id: true
log_inherited_standard_refs: true
log_application_overrides: true
log_campaign_overrides: true
log_rule_failures: true
log_retry_history: true
log_exception_usage: true
log_cached_pass_usage: true
log_required_components: true
log_traceability_metadata: true
retain_validation_report: true
output_format: json
schema:
type: object
properties:
policy_key:
type: string
policy_version:
type: string
application_policy_key:
type: string
application_id:
type: string
content_id:
type: string
content_type:
type: string
channel:
type: string
audience:
type: string
persona:
type: string
timestamp:
type: string
format: iso8601
inherited_standard_refs:
type: array
items:
type: string
application_overrides:
type: array
items:
type: object
campaign_overrides:
type: array
items:
type: object
required_components:
type: array
items:
type: string
traceability_metadata:
type: object
rule_results:
type: array
items:
type: object
properties:
rule_id:
type: string
severity:
type: string
status:
type: string
reason:
type: string
score:
type: number
policy_path:
type: string
retry_count:
type: integer
exception_activations:
type: array
items:
type: object
properties:
exception_id:
type: string
reason:
type: string
matched_context:
type: object
cached_pass_used:
type: boolean
final_decision:
type: string
validation_report_id:
type: string
effective_policy_ref:
type: string
#  -----------------------------------------------------------------------------
#  RELATED POLICY LINKS
#  -----------------------------------------------------------------------------

related_standards:

* "{brand_id}.brand.core"
* "{brand_id}.standards.verbal-identity.tone-of-voice"
* "{brand_id}.standards.verbal-identity.messaging-framework"
* "{brand_id}.standards.visual-identity.colour"
* "{brand_id}.standards.visual-identity.logo"
* "{brand_id}.standards.visual-identity.typography"
* "{brand_id}.standards.visual-identity.layout"
* "{brand_id}.standards.visual-identity.imagery"
* "{brand_id}.standards.visual-identity.iconography"
* "{brand_id}.standards.visual-identity.illustration"
* "{brand_id}.standards.motion"

related_applications:

* "{brand_id}.applications.linkedin"
* "{brand_id}.applications.website"
* "{brand_id}.applications.case-study"
* "{brand_id}.applications.newsletter"
* "{brand_id}.applications.pitch-deck"
* "{brand_id}.applications.proposal"

related_campaigns:

* "{brand_id}.campaigns.*"

---
#  {Brand Name} {Application Name} application policy
# # How to complete this template

This is a Brando® Application Policy template. Complete the following steps in order before publishing.

1. Replace every `{placeholder}` value with application-specific and brand-specific content.
2. Do not replace `<runtime_variable>` values. These are resolved at validation time by the Brando engine.
3. Set `status: draft` and `lifecycle_state: proposed` on first authoring. Update only after governance sign-off.
4. Set `schema.validation_status: ready_for_validation` on first authoring. Update only after a formal parse or review cycle.
5. Remove optional sections that do not apply, or retain them with placeholder values for future use.
6. Remove the `template` metadata block before policy validation.
7. Run the publishing checklist before changing `status` to `active`.

Placeholder reference:

| Token                          | Meaning                                        | Example                      |
| ------------------------------ | ---------------------------------------------- | ---------------------------- |
| `{brand_id}`                   | Stable machine-readable brand identifier       | `advanced-analytica`         |
| `{Brand Name}`                 | Human-readable brand name                      | `Advanced Analytica`         |
| `{application_id}`             | Stable machine-readable application identifier | `linkedin`                   |
| `{Application Name}`           | Human-readable application name                | `LinkedIn`                   |
| `{application_type}`           | Application type                               | `channel`                    |
| `{primary_channel}`            | Main publishing channel                        | `linkedin`                   |
| `{application_content_type_1}` | Governed content or asset type                 | `social_post`                |
| `{format_1_id}`                | Target format identifier                       | `linkedin-single-image-post` |
| `{aspect_ratio_1}`             | Target output ratio                            | `1:1`                        |
| `<exemplar_key>`               | Runtime variable. Do not replace               |                              |

---
# # Purpose

This application policy governs how {Brand Name} applies its brand standards to {Application Name} outputs.

It is the bridge between reusable standards and real-world execution.

Standards define the brand rules. Application policies define how those rules behave in a specific format, channel, or use case.

Campaign policies may inherit from this application policy and narrow it further, but they must not weaken higher-priority legal, regulatory, safety, or brand governance requirements.

---
# # How to interpret this policy

This policy has six layers:

1. Application profile defines the use case, channel, format, and purpose.
2. Standard dependencies declare which brand standards this application inherits from.
3. Application overrides contextualise inherited standards for the channel or format.
4. Format constraints define the operational requirements of the output.
5. Execution rules determine whether output passes, warns, or fails.
6. Telemetry records the validation path for audit and governance.

The YAML front matter is the machine-executable layer. This Markdown body is the human-readable guidance layer. Where they conflict, the YAML governs.

---
# # Application layer in the Brando® stack

The recommended governance stack is:

1. `brand.core`
2. `standards.*`
3. `applications.*`
4. `campaigns.*`
5. Assets, content, and executions

This policy sits at the `applications.*` layer.

It should not duplicate full standards. It should inherit from standards and declare only the application-specific constraints, required components, overrides, exceptions, and validation behaviour.

---
# # Default execution expectations

Unless an explicit exception is declared in the YAML:

* Use all required inherited standards.
* Validate that the output matches this application scope.
* Include every required component for the application.
* Resolve all application overrides before rule execution.
* Maintain traceability to message, proof, visual, and asset sources.
* Validate platform format, aspect ratio, safe area, and output constraints.
* Ensure required content is not obscured by platform UI overlays.
* Validate prompt-output fidelity for generated assets.
* Block undeclared exceptions and unresolved policy references.

---
# # Application override model

Application overrides are allowed when they narrow or contextualise standards for a channel or format.

For example:

* A LinkedIn application policy may require a shorter sentence limit than the global Tone of Voice standard.
* A website application policy may require stronger contrast or stricter logo placement.
* A pitch deck application policy may require proof references for every strategic claim.

Application overrides must not weaken legal, regulatory, safety, or mandatory brand requirements unless a higher-priority exception explicitly allows it.

---
# # Campaign relationship

Campaign policies may inherit from this application policy.

A campaign policy can adapt messages, visual emphasis, formats, and calls to action for a campaign context. It must remain traceable to approved standards and application requirements.

If a campaign needs to override this application policy, the override must be scoped, machine-readable, and logged.

---
# # Validation modes

This file can be validated in two modes.

Template validation: validates the structure of this reusable template. In this mode, the validator recognises `template.is_template: true` and does not require placeholder substitution.

Policy validation: validates an instantiated application policy. In this mode, all `{placeholder}` values and `YYYY-MM-DD` date placeholders must be replaced, and the `template` metadata block must be removed.

---
# # Validator interpretation notes
# ## Deterministic checks

Implement with dependency resolution, structural checks, reference checks, format checks, safe-area checks, override path validation, and measurable thresholds.

Covered by: D001, D002, D003, D004, D005, D006, D007, D008, D009, D010, D011, D012, D013, D014, D015, D016
# ## Heuristic checks

Implement using classifiers, scorers, or model-based evaluators. Every heuristic check must return both a score and a reason. Never return a score alone.

Covered by: H001, H002, H003, H004, H005, H006

All heuristic rules use a 0.0 to 1.0 scale.
# ## Cached dependency behaviour

Required standards should hard fail if unavailable unless a cached pass is explicitly allowed by `standard_dependencies.fallback_behaviour`.

Cached passes must be logged and should trigger human review for higher-risk channels or outputs.
# ## Prompt-output fidelity

Generated outputs must be checked against the structured prompt, generation brief, or system instruction that created them.

A compliant prompt is not enough. The rendered output must also comply.

When H005 fails, the validator should return a JSON remediation payload for AI agents, including a positive repair instruction, a negative prompt, the failed requirements, and the constraints that must be preserved in the next generation.

---
# # Change log

| Version | Date       | Changes                    |
| ------- | ---------- | -------------------------- |
| 1.0.0   | YYYY-MM-DD | Initial published version. |

---
# # Publishing checklist

Before publication, confirm:

* All `{placeholder}` values have been replaced with brand-specific and application-specific content.
* All `YYYY-MM-DD` date placeholders have been replaced with real ISO dates.
* No `<runtime_variable>` values have been replaced.
* The `template` metadata block has been removed.
* The YAML parses successfully with no errors.
* `schema.validation_status` reflects the actual validation state.
* `status` and `lifecycle_state` reflect the actual governance state.
* All required standard dependencies resolve or have declared fallback behaviour.
* All application override paths resolve to inherited standards.
* The application scope matches declared channels and content types.
* All required components are declared and traceable.
* All exception IDs referenced in rules resolve to `exceptions.declared`.
* All rule IDs referenced in `execution.rule_execution_order` exist in `rules`.
* All format constraints match real platform or output requirements.
* Safe area rules account for platform UI overlays where relevant.
* `call_to_action.cta_required` is false to avoid recursive CTA-inception failures.
* Constraint collisions between approved message length and application format have a declared resolution strategy.
* External platform specs resolve, or inline format constraints are complete.
* AI-agent remediation returns JSON with negative prompts where prompt-output fidelity fails.
* Cognitive load scoring returns actionable diagnostics, not only a score.
* Positive exemplars do not violate deterministic rules.
* Anti-exemplars are explicitly excluded from validation.
* Telemetry schema is valid and captures policy key, version, application id, inherited standards, overrides, rule results, and final decision.
