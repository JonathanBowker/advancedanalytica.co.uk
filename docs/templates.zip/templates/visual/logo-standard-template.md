---
#  =============================================================================
#  BRANDO® LOGO STANDARD TEMPLATE
#  brando-schema-1.0 | document_type: policy_standard
#  =============================================================================
# 
#  PLACEHOLDER CONVENTION - READ BEFORE EDITING
#  -----------------------------------------------------------------------------
#  {curly_brace} placeholders must be replaced with brand-specific content
#  before this template is promoted to a brand policy and policy-validated.
# 
#  <angle_bracket> values are runtime variables resolved at validation time.
#  Do NOT replace these. They are consumed by the validation engine.
# 
#  Quote every YAML value that contains a {curly_brace} placeholder.
#  Unquoted curly braces are interpreted as flow mapping syntax and will
#  cause a parse error. Quote all placeholder-containing values, including
#  list items, map keys, and scalar string values.
# 
#  Prose fields such as description, rationale, notes, and guidance should use
#  quoted strings or block scalar style to reduce YAML parsing risk.
#  =============================================================================
#  -----------------------------------------------------------------------------
#  DOCUMENT IDENTITY
#  -----------------------------------------------------------------------------
#  Required. Stable, globally unique identifier for this policy.
#  Recommended pattern: {brand_id}.standards.visual-identity.logo

id: "{brand_id}.standards.visual-identity.logo"
#  Required. Usually mirrors id. Use as the stable lookup key in policy
#  repositories, MCP servers, APIs, and audit logs.

key: "{brand_id}.standards.visual-identity.logo"
#  Required. Human-readable title.

title: "{Brand Name} Logo"
#  Required. Short description used in repositories, UIs, search, and audit logs.

description: |
Core logo standard governing approved logo assets, variants, clearspace,
minimum size, colour usage, responsive behaviour, lockups, recognition,
geometric fidelity, trademark marking, and misuse prevention across
{Brand Name} communications.
#  Required. Defines what kind of policy artefact this is.
#  Allowed values:
#  - standard | application | campaign | exception
#  - exemplar_set | lexicon | telemetry_schema

policy_kind: standard
#  Required. Top-level governance pillar.
#  Allowed values controlled by Brando schema:
#  - standards | applications | campaigns | legal | market | safety

pillar: standards
#  Required. Category within the pillar. Use snake_case for controlled terms.

category: visual_identity
#  Required. Subcategory within the category. Use snake_case for controlled terms.

subcategory: logo
#  Required. Used by Brando to distinguish policy standards from related artefacts.
#  Allowed values:
#  - policy_standard | application_policy | campaign_policy | exemplar
#  - exemplar_set | lexicon | classifier_spec | telemetry_schema | validation_report

document_type: policy_standard
#  -----------------------------------------------------------------------------
#  TEMPLATE METADATA
#  -----------------------------------------------------------------------------
#  Identifies this file as a reusable template rather than an instantiated policy.
#  Remove this block when promoting to a brand-specific policy.

template:
is_template: true
placeholder_status: contains_placeholders
instantiate_before_validation: true
#  -----------------------------------------------------------------------------
#  VERSIONING AND LIFECYCLE
#  -----------------------------------------------------------------------------
#  Required. Semantic version. Use MAJOR.MINOR.PATCH.

version: "1.0.0"
#  Required. Publication status.
#  Allowed values: draft | active | deprecated | archived

status: draft
#  Required. Governance lifecycle state.
#  Allowed values: proposed | in_review | approved | published | superseded | retired

lifecycle_state: proposed
#  Required once active/published. ISO date. Quote to prevent YAML date parsing.

effective_date: "YYYY-MM-DD"
#  Required. ISO date.

created: "YYYY-MM-DD"
#  Required. ISO date.

last_modified: "YYYY-MM-DD"
#  Recommended. ISO date for next scheduled governance review.

next_review: "YYYY-MM-DD"
#  -----------------------------------------------------------------------------
#  OWNERSHIP AND APPROVAL
#  -----------------------------------------------------------------------------

owner:
#  Required. Owning team or function.

team: "{Brand Team Name}"
#  Recommended. Steward responsible for governance upkeep.

steward: "{Steward Role or Name}"

approved_by:
#  Required once lifecycle_state is approved or published.

* "{Approving Team or Role}"
#  -----------------------------------------------------------------------------
#  SCHEMA METADATA
#  -----------------------------------------------------------------------------

schema:
#  Required. Schema class used by Brando.

type: BrandLogoStandard
#  Required. Schema version this document conforms to.

version: brando-schema-1.0
#  Required. Validation state of this file.
#  Allowed values:
#  - ready_for_validation: authored but not yet parsed or reviewed
#  - human_reviewed: reviewed by a human but not formally schema-validated
#  - schema_validated: parsed and validated against the declared schema

validation_status: ready_for_validation
#  -----------------------------------------------------------------------------
#  CLIENT NAMING MAP
#  -----------------------------------------------------------------------------
#  Optional but recommended. Maps client-facing terminology to Brando terms.
#  This field supports terminology mapping only. It does not affect enforcement logic.

naming:
client_term: Logo
canonical_term: Visual Identity
policy_label: Logo
rationale: |
{Explain how the client names this artefact and how Brando should map it
into the canonical governance model. canonical_term maps to category;
policy_label maps to subcategory. This field does not affect enforcement logic.}
#  -----------------------------------------------------------------------------
#  SCOPE
#  -----------------------------------------------------------------------------
#  Required. Defines when this policy applies.

scope:
applies_to:
# Required. Distribution, publishing, or design environments.
# Do not mix channels with asset or content types in this list.
channels:
- website
- linkedin
- email
- newsletter
- event_platform
- sales_enablement
- pitch_deck
- proposal
- print
- packaging
- signage
- app_store
- favicon
- social_avatar
- product_ui

```
# Required. Logo asset types, use cases, and rendered components governed by this policy.
# Composite outputs such as websites, pitch decks, proposals, signage, and social posts
# should be decomposed into governed logo placements before rule execution.
content_types:
  - primary_logo
  - secondary_logo
  - wordmark
  - symbol
  - monogram
  - favicon
  - app_icon
  - social_avatar
  - watermark
  - endorsement_logo
  - certification_logo
  - partner_lockup
  - co_brand_lockup
  - campaign_lockup
  - product_lockup
  - event_lockup
  - footer_logo
  - header_logo
  - hero_logo
  - print_logo
  - signage_logo
  - packaging_logo
#  Recommended. Usage contexts for logo behaviour.
usage_contexts:
  - brand_owned
  - partner_owned
  - paid_media
  - earned_media
  - social_media
  - product_interface
  - legal_required
  - small_format
  - large_format
  - animated
  - static
  - light_background
  - dark_background
  - image_background
  - gradient_background
#  Recommended. Zones within the rendered asset.
# Clearspace is explicitly declared so samplers can distinguish logo ink from protected space.
content_zones:
  - logo_ink
  - clearspace_area
  - background_area
  - safe_area
  - crop_area
  - metadata
  - legal_disclaimer
```

excludes:
content_types:
- internal_draft_sketch
- historical_archive_logo
- competitor_logo_reference
- legal_contract_scan

notes:
- Applies to generated, edited, placed, transformed, exported, and rendered logo assets.
- Applies to both source assets and rendered outputs.
- Does not apply to historical archive material unless reused in live communications.
- Does not apply to third-party competitor logos unless they appear in partner, comparison, or legal contexts governed by downstream policy.
#  -----------------------------------------------------------------------------
#  POLICY PRECEDENCE
#  -----------------------------------------------------------------------------

policy_precedence:
priority_order_highest_first:
- global.safety
- global.regulatory
- market.legal
- enterprise.brand-core
- "{brand_id}.standards.visual-identity.logo"
- "{brand_id}.standards.visual-identity.colour"
- "{brand_id}.standards.visual-identity.layout"
- "{brand_id}.standards.verbal-identity.messaging-framework"
- "{brand_id}.applications.*"
- campaign.local

conflict_resolution:
# Allowed values:
# - higher_priority_wins | most_restrictive_wins | explicit_exception_required
mode: most_restrictive_wins
notes:
- Legal, regulatory, safety, and market-specific trademark requirements override visual preferences.
- Logo geometry, approved asset usage, and trademark marking are treated as non-negotiable unless an explicit exception exists.
- Colour Standard governs colour token validity. Logo Standard governs which colour tokens may be applied to logo assets.
- Layout Standard governs placement systems. Logo Standard governs logo clearspace, recognition, minimum size, and misuse.
- Where layout density conflicts with logo recognition, logo recognition wins and the layout must adapt.
- Exceptions must be explicit and machine-readable to override defaults.
#  -----------------------------------------------------------------------------
#  INHERITANCE
#  -----------------------------------------------------------------------------

inheritance:
inherits_from:
- "{brand_id}.brand.core"
- "{brand_id}.standards.visual-identity.colour:^1.0.0"
may_be_overridden_by:
- "{brand_id}.applications.website"
- "{brand_id}.applications.linkedin"
- "{brand_id}.applications.pitch-deck"
- "{brand_id}.applications.packaging"
- "{brand_id}.applications.signage"
- "{brand_id}.campaigns.*"
- "{brand_id}.legal.*"
- "{brand_id}.market.*"
#  -----------------------------------------------------------------------------
#  RESOLUTION BEHAVIOUR
#  -----------------------------------------------------------------------------

resolution:
resolve_inheritance_before_validation: true
resolve_exceptions_before_rule_execution: true
materialize_effective_policy: true
effective_policy_output:
include_resolved_rules: true
include_applied_exceptions: true
include_precedence_path: true
include_resolved_logo_assets: true
include_responsive_variant_path: true
include_trademark_requirements: true
#  -----------------------------------------------------------------------------
#  LOGO PRINCIPLES
#  -----------------------------------------------------------------------------

principles:
required:
- "{logo_principle_1}"
- "{logo_principle_2}"
- "{logo_principle_3}"
definitions:
"{logo_principle_1}":
description: "{Describe logo principle 1 in one clear sentence.}"
"{logo_principle_2}":
description: "{Describe logo principle 2 in one clear sentence.}"
"{logo_principle_3}":
description: "{Describe logo principle 3 in one clear sentence.}"
#  -----------------------------------------------------------------------------
#  LOGO POLICY
#  -----------------------------------------------------------------------------
#  Required. Defines the intended logo system.

logo_policy:
objectives:
required:
- preserve_geometric_integrity
- preserve_recognition
- maintain_clearspace
- maintain_legibility
- use_approved_assets_only
- apply_approved_colour_tokens_only
- respect_market_legal_marking
- support_responsive_logo_behaviour

logo_characteristics:
required:
- recognisable
- proportional
- clear
- accessible
- consistent_with_brand_core
- fit_for_context
forbidden:
- distorted
- redrawn
- recoloured_without_token
- colour_inversion_without_token
- outlined_without_approval
- shadowed_without_approval
- textured_without_approval
- placed_on_busy_background_without_treatment
- used_below_minimum_size
- insufficient_clearspace

colour_standard_ref: "{brand_id}.standards.visual-identity.colour:^1.0.0"

approved_colour_behaviour:
use_colour_tokens_only: true
allow_reversed_variant: true
allow_colour_inversion_without_token: false
allow_tints_or_opacity_changes: false
allow_gradient_logo_fill: false
allow_image_masking: false
notes:
- Reversed logo usage must use an approved reversed asset or approved colour token, not arbitrary colour inversion.
- Logo colour may not be sampled from nearby artwork unless explicitly declared as a tokenized application rule.

minimum_accessibility:
default_minimum_contrast_ratio: 4.5
large_logo_minimum_contrast_ratio: 3.0
watermark_minimum_contrast_ratio: 1.5
watermark_exemption_condition: redundant_primary_logo_present
notes:
- Low-contrast watermarks are allowed only when they are decorative and redundant to a primary high-contrast logo elsewhere in the same asset.
- A watermark must never be the only visible brand identifier in an asset.
#  -----------------------------------------------------------------------------
#  APPROVED LOGO ASSETS
#  -----------------------------------------------------------------------------
#  Required. Defines approved logo variants and source references.
#  Replace placeholders before policy validation.

logo_assets:
repository:
mode: referenced
source_key: "{brand_id}.standards.visual-identity.logo"
protocol: brando_policy_repo
base_path: /policies/assets/logo/
auth: service_account
timeout_seconds: 5
cache_ttl_seconds: 300
fallback_behaviour:
if_logo_unavailable: cached_pass_with_warning
cached_pass_max_age_seconds: 604800
cache_integrity_check_required: true
if_cache_unavailable: hard_fail
notes:
- Repository outages should not paralyse production when a recent known-good cached asset exists.
- Cached pass must be logged as a warning and must include cache age, asset hash, and validation timestamp.

primary_logo:
id: primary_logo
label: Primary Logo
asset_ref: "{primary_logo_asset_ref}"
file_formats:
- svg
- png
- pdf
required: true
colour_variants:
- full_colour
- one_colour_dark
- one_colour_light
- reversed
default_colour_variant: full_colour
clearspace:
unit_basis: "{clearspace_unit_basis}"
minimum_units: "{minimum_clearspace_units}"
minimum_size:
digital_px_width: "{minimum_digital_width_px}"
print_mm_width: "{minimum_print_width_mm}"
trademark_marking:
default_required: false
mark: "{trademark_mark}"
placement: "{trademark_mark_placement}"

secondary_logo:
id: secondary_logo
label: Secondary Logo
asset_ref: "{secondary_logo_asset_ref}"
file_formats:
- svg
- png
- pdf
required: false
allowed_when:
- constrained_space
- secondary_brand_context
- application_policy_declares

wordmark:
id: wordmark
label: Wordmark
asset_ref: "{wordmark_asset_ref}"
required: true
minimum_size:
digital_px_width: "{wordmark_minimum_digital_width_px}"
print_mm_width: "{wordmark_minimum_print_width_mm}"

symbol:
id: symbol
label: Symbol
asset_ref: "{symbol_asset_ref}"
required: false
allowed_when:
- small_format
- app_icon
- favicon
- social_avatar
- responsive_fallback

monogram:
id: monogram
label: Monogram
asset_ref: "{monogram_asset_ref}"
required: false
allowed_when:
- very_small_format
- responsive_fallback
- app_icon
- favicon

favicon:
id: favicon
label: Favicon
asset_ref: "{favicon_asset_ref}"
required: false
file_formats:
- svg
- png
- ico

app_icon:
id: app_icon
label: App Icon
asset_ref: "{app_icon_asset_ref}"
required: false
file_formats:
- svg
- png
#  -----------------------------------------------------------------------------
#  RESPONSIVE LOGO POLICY
#  -----------------------------------------------------------------------------

responsive_logo_policy:
enabled: true
evaluate_responsive_fallbacks_before_blocking: true
default_fallback_order:
- primary_logo
- wordmark
- symbol
- monogram
- favicon
responsive_variants:
- id: desktop_primary
use_when:
min_width_px: 1024
preferred_logo_ref: primary_logo
fallback_logo_refs:
- wordmark
- symbol

```
- id: tablet_primary
  use_when:
    min_width_px: 768
    max_width_px: 1023
  preferred_logo_ref: wordmark
  fallback_logo_refs:
    - primary_logo
    - symbol

- id: mobile_compact
  use_when:
    min_width_px: 320
    max_width_px: 767
  preferred_logo_ref: symbol
  fallback_logo_refs:
    - monogram
    - favicon

- id: favicon_small
  use_when:
    max_width_px: 64
  preferred_logo_ref: favicon
  fallback_logo_refs:
    - symbol
    - monogram
```

notes:
- Responsive fallback is a remediation path, not a free choice.
- If a logo fails recognition at a given size, the validator should test approved responsive fallbacks before blocking.
- Build should block only when no approved fallback passes recognition, contrast, clearspace, and legal marking checks.
#  -----------------------------------------------------------------------------
#  LOCKUP POLICY
#  -----------------------------------------------------------------------------

lockup_policy:
allow_programmatic_lockup_generation: true
require_optical_balance_check: true
lockup_types:
- partner_lockup
- co_brand_lockup
- campaign_lockup
- product_lockup
- endorsement_logo
- certification_logo
parity_modes:
allowed:
- brand_first
- optical_parity
- partner_first_by_contract
default: optical_parity
alignment:
allowed:
- baseline
- optical_center
- cap_height
- symbol_center
default: optical_center
separators:
allowed:
- vertical_rule
- spacing_only
- plus_symbol
- x_symbol
forbidden:
- decorative_divider
- unapproved_icon
- unapproved_pattern
notes:
- Optical centering may differ from mathematical centering because logo weights are asymmetrical.
- H005 checks visual weight distribution and perceived balance, not just geometric bounding boxes.
#  -----------------------------------------------------------------------------
#  TRADEMARK AND LEGAL MARKING POLICY
#  -----------------------------------------------------------------------------

trademark_policy:
market_legal_ref: "{brand_id}.legal.trademark"
default_required: false
marks:
allowed:
- ™
- ®
- SM
forbidden:
- unapproved_trademark_mark
placement:
allowed:
- upper_right
- baseline_right
- market_specific
default: upper_right
size:
relative_to_logo_height: "{trademark_mark_relative_size}"
minimum_px_height: "{trademark_mark_minimum_px_height}"
when_required:
- market_legal_requires
- application_policy_requires
- product_or_service_mark_context
notes:
- Trademark marking requirements are resolved from market.legal before logo validation.
- Missing required trademark marking is a hard fail unless an explicit legal exception applies.
#  -----------------------------------------------------------------------------
#  FIELD APPLICABILITY
#  -----------------------------------------------------------------------------

field_applicability:
primary_logo:
minimum_contrast_ratio: 4.5
recognition_threshold: 0.85
clearspace_required: true
trademark_marking_check_required: true

secondary_logo:
minimum_contrast_ratio: 4.5
recognition_threshold: 0.85
clearspace_required: true
trademark_marking_check_required: true

wordmark:
minimum_contrast_ratio: 4.5
recognition_threshold: 0.85
clearspace_required: true
trademark_marking_check_required: true

symbol:
minimum_contrast_ratio: 4.5
recognition_threshold: 0.80
clearspace_required: true
trademark_marking_check_required: false

monogram:
minimum_contrast_ratio: 4.5
recognition_threshold: 0.80
clearspace_required: true
trademark_marking_check_required: false

favicon:
minimum_contrast_ratio: 3.0
recognition_threshold: 0.75
clearspace_required: false
trademark_marking_check_required: false

app_icon:
minimum_contrast_ratio: 3.0
recognition_threshold: 0.80
clearspace_required: false
trademark_marking_check_required: false

watermark:
minimum_contrast_ratio: 1.5
recognition_threshold: 0.50
clearspace_required: false
trademark_marking_check_required: false
allowed_only_when_redundant_primary_logo_present: true

partner_lockup:
minimum_contrast_ratio: 4.5
recognition_threshold: 0.85
clearspace_required: true
trademark_marking_check_required: true
optical_balance_required: true

co_brand_lockup:
minimum_contrast_ratio: 4.5
recognition_threshold: 0.85
clearspace_required: true
trademark_marking_check_required: true
optical_balance_required: true

campaign_lockup:
minimum_contrast_ratio: 4.5
recognition_threshold: 0.85
clearspace_required: true
trademark_marking_check_required: true
optical_balance_required: true
#  -----------------------------------------------------------------------------
#  MISUSE POLICY
#  -----------------------------------------------------------------------------

misuse_policy:
forbidden_transformations:
- stretch
- skew
- rotate_without_approval
- crop_logo
- redraw_logo
- reconstruct_logo_from_type
- apply_shadow_without_approval
- apply_glow_without_approval
- apply_outline_without_approval
- apply_texture_without_approval
- apply_gradient_without_approval
- colour_inversion_without_token
- change_logo_colour_without_token
- place_on_unapproved_pattern
- place_on_busy_background_without_treatment
- animate_without_motion_policy

forbidden_backgrounds:
- low_contrast_image_area
- visually_busy_area_under_logo_ink
- pattern_under_logo_ink_without_treatment
- gradient_low_contrast_point_under_logo_ink

approved_treatments:
- approved_reversed_variant
- approved_single_colour_variant
- approved_logo_container
- approved_clearspace_panel
- approved_partner_lockup_template
#  -----------------------------------------------------------------------------
#  REQUIRED ELEMENTS
#  -----------------------------------------------------------------------------

required_elements:
default:
- approved_logo_asset
- approved_logo_variant
- approved_colour_token
- clearspace
- minimum_size
- sufficient_contrast
- responsive_variant_mapping
- trademark_marking_status

conditional:
- id: trademark_mark_required_by_market
required_when:
market_legal_requires_trademark_mark: true
- id: lockup_parity_for_partner_context
required_when:
lockup_context_present: true
- id: responsive_fallback_for_small_format
required_when:
small_format: true
- id: watermark_redundant_primary_logo
required_when:
content_type: watermark
#  -----------------------------------------------------------------------------
#  EXCEPTIONS
#  -----------------------------------------------------------------------------

exceptions:
undeclared_exception_behaviour: hard_fail
validation:
exception_must_be_declared_in_policy: true
exception_must_match_content_context: true
log_all_exception_activations: true

declared:
- id: legal_text_exception
description: Legal or regulated uses may override logo preferences where required by law or compliance.
when:
policy_context:
higher_priority_policy_matches:
- "{brand_id}.legal.*"
- global.regulatory
override:
enforcement_mode: defer_to_higher_policy

```
- id: approved_watermark_exception
  description: Low-contrast watermark use is allowed only when redundant to a primary high-contrast logo elsewhere in the same asset.
  when:
    content_type:
      - watermark
    redundant_primary_logo_present: true
  override:
    enforcement_mode: watermark_relaxed
    minimum_contrast_ratio: 1.5
    requirements:
      - primary_high_contrast_logo_present
      - watermark_not_primary_identifier

- id: historical_archive_exception
  description: Archived historical logos may retain legacy form when shown as historical reference material and not used as active branding.
  when:
    usage_context:
      - historical_archive
  override:
    enforcement_mode: archive_reference_only
    skip_rules:
      - D002
      - D008
      - D013

- id: partner_contract_exception
  description: Partner lockup rules may be overridden only where a signed partner agreement requires a specific logo relationship.
  when:
    approval_status:
      - legally_approved
    usage_context:
      - partner_owned
  override:
    enforcement_mode: contract_required_lockup
    requirements:
      - legal_approval_ref_required
      - partner_agreement_ref_required
```
#  -----------------------------------------------------------------------------
#  EXEMPLARS
#  -----------------------------------------------------------------------------

exemplars:
minimum_review_count: 2
markdown_examples:
role: human_readable_copy
authoritative: false
excluded_from_validation: true
storage:
mode: referenced
source_key: "{brand_id}.standards.visual-identity.logo"
section: exemplars
load_at_validation: true
retrieval:
protocol: brando_policy_repo
base_path: /policies/exemplars/
key_format: "<exemplar_key>.md"
auth: service_account
timeout_seconds: 5
cache_ttl_seconds: 300
fallback_behaviour:
if_exemplars_unavailable: skip_rule_with_warning
affected_rules:
- H004
active_exemplar_keys:
- "{brand_id}.standards.visual-identity.logo.exemplar.{example_key_1}"
- "{brand_id}.standards.visual-identity.logo.exemplar.{example_key_2}"
source_contexts:
channels:
- website
- linkedin
- pitch_deck
- print
- product_ui
content_types:
- primary_logo
- wordmark
- symbol
- partner_lockup
- app_icon
- favicon
#  -----------------------------------------------------------------------------
#  ANTI-EXEMPLARS
#  -----------------------------------------------------------------------------

anti_exemplars:
enforcement_role: negative_reference_only
used_by_rules: []
excluded_from_deterministic_validation: true
excluded_from_heuristic_validation: true
sources:
- id: "{anti_exemplar_source_1}"
label: "{Human-readable label}"
for_human_review_only: true
#  -----------------------------------------------------------------------------
#  DOCUMENT SELF-VALIDATION
#  -----------------------------------------------------------------------------

document_self_validation:
validate_yaml_structure: true
validate_authoritative_positive_exemplars: true
validate_logo_asset_references: true
validate_responsive_variant_references: true
validate_colour_token_references: true
validate_trademark_policy_references: true
validate_lockup_reference_paths: true
exclude_markdown_guidance: true
exclude_change_log: true
exclude_comments: true
exclude_anti_exemplars: true
exclude_markdown_exemplar_copies: true
notes:
- Logo asset references include primary_logo, secondary_logo, wordmark, symbol, monogram, favicon, and app_icon refs.
- Responsive variant references must resolve to declared logo asset IDs.
- Colour references must resolve against the pinned Colour Standard version where one is declared.
- Trademark marking requirements must resolve from market.legal before D017 executes.
- Anti-exemplars are excluded per anti_exemplars.excluded_from_deterministic_validation.
#  -----------------------------------------------------------------------------
#  CLASSIFIERS
#  -----------------------------------------------------------------------------

classifiers:
logo_recognition_classifier:
description: |
Scores whether the logo remains recognisable in the rendered context,
including small-size, low-resolution, responsive, favicon, social-avatar,
and app-icon contexts.
output:
type: object
properties:
recognition_score:
type: number
scale: 0.0_to_1.0
recommended_variant_refs:
type: array
items:
type: string
reason:
type: string
used_by_rules:
- H001

logo_legibility_classifier:
description: |
Scores whether the logo is readable and visually clear after rendering,
compression, scaling, or placement over image, video, or gradient backgrounds.
output:
type: object
properties:
legibility_score:
type: number
scale: 0.0_to_1.0
failing_regions:
type: array
items:
type: object
reason:
type: string
used_by_rules:
- H002

brand_fit_classifier:
description: |
Scores whether the chosen logo variant, lockup, placement, and treatment
feel consistent with the brand's visual identity and intended usage context.
output:
type: object
properties:
brand_fit_score:
type: number
scale: 0.0_to_1.0
reason:
type: string
used_by_rules:
- H003

exemplar_alignment_classifier:
description: |
Scores whether the rendered logo usage aligns with approved logo exemplars.
Uses a normalized 0.0 to 1.0 scale.
output:
type: object
properties:
exemplar_alignment_score:
type: number
scale: 0.0_to_1.0
nearest_exemplar_refs:
type: array
items:
type: string
reason:
type: string
used_by_rules:
- H004

co_branding_balance_classifier:
description: |
Scores perceived visual balance in partner, co-brand, campaign, and product lockups.
Must evaluate optical centering and visual weight distribution, not only mathematical
bounding-box centering. Output should identify whether perceived imbalance is caused
by size, weight, spacing, alignment, separator choice, or colour contrast.
output:
type: object
properties:
balance_score:
type: number
scale: 0.0_to_1.0
centering_mode_detected:
type: string
visual_weight_delta:
type: number
suggested_adjustments:
type: array
items:
type: string
reason:
type: string
used_by_rules:
- H005

misuse_risk_classifier:
description: |
Scores whether the logo appears to have been decorated, stylised, redrawn,
recoloured, distorted, or placed in a way that creates brand misuse risk.
output:
type: object
properties:
misuse_risk_score:
type: number
scale: 0.0_to_1.0
detected_misuse_types:
type: array
items:
type: string
reason:
type: string
used_by_rules:
- H006
#  -----------------------------------------------------------------------------
#  EXECUTION
#  -----------------------------------------------------------------------------

execution:
enforcement_mode: blocking
max_retry_attempts: 3
escalate_to_human_after: 3
rule_id_policy:
deterministic_pattern: "^D[0-9]{3}$"
heuristic_pattern: "^H[0-9]{3}[A-Z]?$"
rule_execution_order:
phase_1_deterministic:
- D001
- D002
- D003
- D004
- D005
- D006
- D007
- D008
- D009
- D010
- D011
- D012
- D013
- D014
- D015
- D016
- D017
phase_2_heuristic:
- H001
- H002
- H003
- H004
- H005
- H006
notes: Run all deterministic rules first. Only proceed to heuristic rules if all deterministic rules pass or produce soft warnings only.
heuristic_decisioning:
low_confidence_ignore_below: 0.60
medium_confidence_warn_at_or_above: 0.60
high_confidence_enforce_at_or_above: 0.85
threshold_resolution:
policy: per_rule_takes_precedence
notes:
- All heuristic rules use a normalized 0.0 to 1.0 probability or score scale.
- Do not use 0-100 percentage scores for logo heuristic rules.
- Where a rule declares its own threshold, that value governs for that rule.
retry_strategy:
mode: targeted_repair_then_responsive_fallback_then_regenerate
repair_scope:
deterministic_failures: logo_placement_or_asset_level
heuristic_failures: rendered_asset_level
responsive_variant_failures: variant_substitution_level
after_two_failed_repairs: full_regeneration
breakpoint_failure_strategy:
default_action: adjust_size_spacing_or_variant_mapping_first
change_layout_pattern_only_after_token_repair_fails: true
notes:
- If a logo fails at a breakpoint, first adjust approved spacing, size, or responsive variant mapping.
- Changing the layout pattern is a regeneration event, not a first-pass repair.
repair_instruction_format:
include_violation_id: true
include_failing_asset_ref: true
include_failing_context: true
include_pre_tolerance_value: true
include_remediation_action: true
include_suggested_variant_refs: true
include_legal_marking_requirement: true
sequence:
- repair_deterministic_failures
- re-evaluate
- test_responsive_fallbacks
- re-evaluate
- repair_heuristic_weaknesses
- re-evaluate
- regenerate_if_still_failing
output_contract:
must_pass:
- no_hard_fail_rules
- approved_logo_asset_used
- geometry_within_tolerance
- required_trademark_marking_present
may_pass_with_warnings:
- cached_repository_pass
- watermark_contrast_relaxed_with_primary_logo_present
- soft_warn_only
must_block:
- unapproved_logo_asset
- no_approved_responsive_variant_passes
- geometry_fidelity_failed
- required_trademark_marking_missing
- colour_inversion_without_token
- logo_repository_unavailable_without_valid_cache
#  -----------------------------------------------------------------------------
#  RULES
#  -----------------------------------------------------------------------------

rules:
deterministic:
- id: D001
name: unapproved_logo_asset_used
severity: hard_fail
applies_to:
- primary_logo
- secondary_logo
- wordmark
- symbol
- monogram
- favicon
- app_icon
- partner_lockup
- co_brand_lockup
- campaign_lockup
- product_lockup
detect:
method: asset_reference_check
approved_sources:
- logo_assets.primary_logo.asset_ref
- logo_assets.secondary_logo.asset_ref
- logo_assets.wordmark.asset_ref
- logo_assets.symbol.asset_ref
- logo_assets.monogram.asset_ref
- logo_assets.favicon.asset_ref
- logo_assets.app_icon.asset_ref
repository_required: true
remediation:
action: replace_with_approved_logo_asset

```
- id: D002
  name: invalid_logo_variant_for_context
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - favicon
    - app_icon
    - watermark
    - partner_lockup
    - co_brand_lockup
  detect:
    method: variant_context_check
    allowed_when_from:
      - logo_assets.*.allowed_when
      - responsive_logo_policy.responsive_variants
      - field_applicability
  remediation:
    action: select_approved_variant_for_context

- id: D003
  name: minimum_size_violation
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - favicon
    - app_icon
    - partner_lockup
    - co_brand_lockup
  detect:
    method: rendered_size_check
    minimum_size_from:
      - logo_assets.*.minimum_size
      - responsive_logo_policy.responsive_variants
    unit_modes:
      - px
      - mm
      - pt
    tolerance_px: 0.01
    telemetry:
      log_pre_tolerance_value: true
  remediation:
    action: increase_size_or_use_approved_responsive_variant

- id: D004
  name: clearspace_violation
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - partner_lockup
    - co_brand_lockup
    - campaign_lockup
    - product_lockup
  detect:
    method: clearspace_measurement
    unit_basis_from: logo_assets.*.clearspace.unit_basis
    minimum_units_from: logo_assets.*.clearspace.minimum_units
    collision_targets:
      - text
      - image
      - edge
      - ui_control
      - partner_logo
      - legal_text
      - decorative_element
    tolerance_px: 0.01
    telemetry:
      log_pre_tolerance_value: true
  remediation:
    action: increase_clearspace_or_reposition_logo

- id: D005
  name: logo_distorted_or_reconstructed
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - partner_lockup
    - co_brand_lockup
  detect:
    method: transform_check
    forbidden_transformations_from: misuse_policy.forbidden_transformations
    check_aspect_ratio: true
    check_rotation: true
    check_skew: true
    check_non_uniform_scaling: true
    tolerance_px: 0.01
    telemetry:
      log_pre_tolerance_value: true
  remediation:
    action: restore_original_asset_and_proportional_scaling

- id: D006
  name: unsafe_logo_placement
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - partner_lockup
    - co_brand_lockup
    - hero_logo
    - footer_logo
    - header_logo
    - social_avatar
  detect:
    method: safe_area_check
    safe_area_sources:
      - content_zones.safe_area
      - channel_safe_area_profiles
      - application_policy.safe_area
    dynamic_safe_area_required_for:
      - social_media
      - app_store
      - product_ui
    social_overlay_profiles:
      - linkedin
      - instagram
      - tiktok
      - youtube
      - x
    collision_targets:
      - crop_edge
      - platform_ui_overlay
      - caption_overlay
      - control_overlay
      - notch_or_status_bar
  remediation:
    action: reposition_logo_within_dynamic_safe_area

- id: D007
  name: logo_contrast_violation
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - favicon
    - app_icon
    - partner_lockup
    - co_brand_lockup
    - campaign_lockup
    - product_lockup
    - watermark
  detect:
    method: contrast_check
    minimum_from_field_applicability: minimum_contrast_ratio
    contrast_algorithm: wcag_2_1_relative_luminance
    sample_area: logo_ink_only
    exclude_zones_from_sampling:
      - clearspace_area
      - metadata
    resolve_gradient_before_check: true
    gradient_logic:
      validate_against_lowest_contrast_point: true
      measurement_scope: text_or_logo_ink_bounding_box
      rule: worst_case_scenario
      notes:
        - For gradients, contrast must be validated against the lowest-contrast point of the gradient area covered by the logo ink bounding box.
        - Average contrast is insufficient and must not be used as a pass condition.
    image_background_logic:
      validate_against_lowest_contrast_point: true
      measurement_scope: logo_ink_bounding_box
      exclude_clearspace_area: true
    watermark_logic:
      allow_relaxed_contrast_only_when_redundant_primary_logo_present: true
    unless_exception:
      - approved_watermark_exception
  remediation:
    action: switch_to_approved_high_contrast_variant_or_add_logo_container

- id: D008
  name: logo_geometry_fidelity_failed
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - favicon
    - app_icon
    - partner_lockup
    - co_brand_lockup
  detect:
    method: visual_regression_raster_diff
    source_asset_ref: logo_assets.*.asset_ref
    rendered_asset_ref: <rendered_asset_ref>
    compare_mode: high_resolution_raster_diff
    rasterization:
      scale_factor: 4
      transparent_background: true
      antialiasing_normalized: true
    tolerance:
      max_visual_delta: 0.005
      max_edge_delta_px: 0.01
    avoid_raw_svg_string_comparison: true
    notes:
      - Validators must compare visual output, not raw SVG strings, because exporters may rewrite equivalent path data.
      - Raw path or SVG string comparison may be logged for diagnostics but must not be the sole fail condition.
  remediation:
    action: replace_with_original_approved_source_asset

- id: D009
  name: unauthorized_colour_variant_used
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - partner_lockup
    - co_brand_lockup
    - campaign_lockup
    - product_lockup
  detect:
    method: colour_token_check
    approved_colour_sources:
      - logo_policy.approved_colour_behaviour
      - logo_assets.*.colour_variants
      - logo_policy.colour_standard_ref
    forbidden_behaviours:
      - colour_inversion_without_token
      - change_logo_colour_without_token
      - gradient_logo_fill_without_approval
      - tint_or_opacity_change_without_approval
  remediation:
    action: replace_with_approved_logo_colour_variant

- id: D010
  name: clearspace_background_noise_violation
  severity: soft_warn
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - partner_lockup
    - co_brand_lockup
  detect:
    method: background_noise_check
    measurement_zones:
      - clearspace_area
      - background_area
    max_visual_noise_score: 0.35
    notes:
      - D007 contrast checks logo ink against background and excludes clearspace from contrast sampling.
      - D010 separately warns when the clearspace area is visually noisy enough to weaken logo prominence.
  remediation:
    action: add_clearspace_panel_or_move_logo_to_quieter_area

- id: D011
  name: lockup_parity_invalid
  severity: hard_fail
  applies_to:
    - partner_lockup
    - co_brand_lockup
    - campaign_lockup
    - product_lockup
    - endorsement_logo
    - certification_logo
  detect:
    method: lockup_parity_check
    parity_modes_from: lockup_policy.parity_modes
    alignment_from: lockup_policy.alignment
    check_visual_size_ratio: true
    check_spacing: true
    check_separator: true
    allow_programmatic_lockup_generation: true
  remediation:
    action: apply_approved_lockup_template_or_adjust_optical_parity

- id: D012
  name: logo_effect_or_decoration_used
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - partner_lockup
    - co_brand_lockup
  detect:
    method: visual_effect_check
    forbidden_transformations_from: misuse_policy.forbidden_transformations
    forbidden_backgrounds_from: misuse_policy.forbidden_backgrounds
  remediation:
    action: remove_unapproved_effect_or_use_approved_treatment

- id: D013
  name: responsive_variant_mapping_invalid
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - favicon
    - app_icon
    - social_avatar
  detect:
    method: responsive_variant_mapping_check
    source: responsive_logo_policy.responsive_variants
    evaluate_all_breakpoints: true
    block_only_if_no_approved_variant_passes: true
  remediation:
    action: select_approved_responsive_variant_for_breakpoint

- id: D014
  name: file_format_or_resolution_invalid
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - favicon
    - app_icon
    - print_logo
    - signage_logo
  detect:
    method: asset_format_check
    approved_formats_from: logo_assets.*.file_formats
    require_vector_for:
      - print
      - signage
      - packaging
    require_high_resolution_raster_for:
      - app_store
      - social_avatar
  remediation:
    action: export_approved_format_from_source_asset

- id: D015
  name: prompt_output_logo_fidelity_failed
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - partner_lockup
    - co_brand_lockup
    - campaign_lockup
  detect:
    method: structured_prompt_output_check
    prompt_fields:
      - requested_logo_ref
      - requested_variant
      - requested_colour_token
      - requested_lockup_type
      - requested_breakpoint
    rendered_fields:
      - detected_logo_ref
      - detected_variant
      - detected_colour_token
      - detected_lockup_type
      - detected_breakpoint
    fail_on_mismatch: true
  remediation:
    action: regenerate_or_repair_to_match_declared_logo_intent

- id: D016
  name: logo_repository_unavailable_without_valid_cache
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - favicon
    - app_icon
    - partner_lockup
    - co_brand_lockup
  detect:
    method: repository_availability_check
    repository: logo_assets.repository
    allow_cached_pass_with_warning: true
    cached_pass_max_age_seconds: 604800
    cache_integrity_check_required: true
    hard_fail_when:
      - repository_unavailable
      - cache_unavailable
      - cache_expired
      - cache_hash_mismatch
  remediation:
    action: restore_repository_or_use_valid_cached_approved_asset

- id: D017
  name: trademark_marking_missing
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - partner_lockup
    - co_brand_lockup
    - campaign_lockup
    - product_lockup
    - print_logo
    - packaging_logo
  detect:
    method: trademark_marking_check
    requirements_from:
      - trademark_policy
      - market.legal
      - application_policy
    required_when:
      - market_legal_requires
      - product_or_service_mark_context
      - application_policy_requires
    check_mark_presence: true
    check_mark_type: true
    check_mark_placement: true
    check_mark_size: true
  unless_exception:
    - legal_text_exception
  remediation:
    action: add_required_trademark_mark_or_attach_legal_exception
```

heuristic:
- id: H001
name: logo_recognition_weak
severity: hard_fail
applies_to:
- primary_logo
- secondary_logo
- wordmark
- symbol
- monogram
- favicon
- app_icon
- social_avatar
- partner_lockup
- co_brand_lockup
detect:
method: logo_recognition_classifier
threshold_from_field_applicability: recognition_threshold
evaluate_responsive_fallbacks: true
fallback_sources:
- responsive_logo_policy.responsive_variants
- logo_assets.symbol
- logo_assets.monogram
- logo_assets.favicon
- logo_assets.app_icon
remediation:
action: select_most_recognisable_approved_responsive_variant
suggest_top_alternatives: 3
block_only_if_no_approved_variant_passes: true
suggested_replacement_format:
logo_ref: <suggested_logo_ref>
reason: <reason>

```
- id: H002
  name: logo_legibility_weak
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - partner_lockup
    - co_brand_lockup
  detect:
    method: logo_legibility_classifier
    threshold: 0.85
  remediation:
    action: improve_scale_background_or_variant_for_legibility

- id: H003
  name: weak_brand_fit
  severity: soft_warn
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - partner_lockup
    - co_brand_lockup
    - campaign_lockup
  detect:
    method: brand_fit_classifier
    threshold: 0.75
  remediation:
    action: select_more_context_appropriate_logo_variant

- id: H004
  name: low_exemplar_alignment_score
  severity: soft_warn
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - partner_lockup
    - co_brand_lockup
  detect:
    method: exemplar_alignment_classifier
    exemplar_set: exemplars.active_exemplar_keys
    threshold: 0.70
  remediation:
    action: revise_toward_approved_logo_usage_patterns

- id: H005
  name: co_branding_balance_weak
  severity: soft_warn
  applies_to:
    - partner_lockup
    - co_brand_lockup
    - campaign_lockup
    - product_lockup
    - endorsement_logo
    - certification_logo
  detect:
    method: co_branding_balance_classifier
    threshold: 0.80
    evaluate_optical_centering: true
    evaluate_mathematical_centering: true
    prefer_optical_balance_when_conflict: true
  remediation:
    action: adjust_lockup_for_optical_balance
    suggested_adjustments_required: true

- id: H006
  name: logo_misuse_risk
  severity: hard_fail
  applies_to:
    - primary_logo
    - secondary_logo
    - wordmark
    - symbol
    - monogram
    - partner_lockup
    - co_brand_lockup
    - campaign_lockup
  detect:
    method: misuse_risk_classifier
    threshold: 0.85
  remediation:
    action: remove_misuse_or_replace_with_approved_logo_asset
```
#  -----------------------------------------------------------------------------
#  DECISION POLICY
#  -----------------------------------------------------------------------------

decision_policy:
pass_conditions:
- zero_hard_failures
warn_conditions:
- one_or_more_soft_warnings
fail_conditions:
- one_or_more_hard_failures
publish_conditions:
- status in [pass, warn]
- hard_fail_count == 0
warn_behaviour:
auto_publish_allowed: true
conflict_resolution:
mode: most_restrictive_wins
notes:
- If any matched channel, content_type, market, or lockup type requires human sign-off, human sign-off is required.
- Auto-publish is allowed only when no matched rule requires human sign-off.
requires_human_sign_off_on_warn:
channels:
- print
- packaging
- signage
- pitch_deck
content_types:
- primary_logo
- partner_lockup
- co_brand_lockup
- campaign_lockup
warning_types:
- cached_repository_pass
- watermark_contrast_relaxed
- co_branding_balance_weak
allows_auto_publish_on_warn:
channels:
- website
- linkedin
- newsletter
content_types:
- footer_logo
- header_logo
- social_avatar
human_review_conditions:
- retry_count >= 3
- unresolved_heuristic_conflict == true
- legal_marking_uncertain == true
- partner_contract_exception_used == true
#  -----------------------------------------------------------------------------
#  TELEMETRY
#  -----------------------------------------------------------------------------

telemetry:
log_policy_key: true
log_policy_version: true
log_rule_failures: true
log_retry_history: true
log_exception_usage: true
log_logo_asset_refs: true
log_logo_variant: true
log_colour_tokens: true
log_responsive_fallback_path: true
log_trademark_marking_status: true
log_pre_tolerance_values: true
log_cache_status: true
retain_validation_report: true
output_format: json
schema:
type: object
properties:
policy_key:
type: string
policy_version:
type: string
content_id:
type: string
content_type:
type: string
channel:
type: string
usage_context:
type: string
timestamp:
type: string
format: iso8601
logo_asset_ref:
type: string
logo_variant:
type: string
colour_token_refs:
type: array
items:
type: string
responsive_fallback_path:
type: array
items:
type: string
trademark_marking_status:
type: string
cache_status:
type: object
pre_tolerance_values:
type: object
rule_results:
type: array
items:
type: object
properties:
rule_id:
type: string
severity:
type: string
status:
type: string
reason:
type: string
score:
type: number
suggested_replacements:
type: array
items:
type: object
retry_count:
type: integer
exception_activations:
type: array
items:
type: object
properties:
exception_id:
type: string
reason:
type: string
matched_context:
type: object
final_decision:
type: string
validation_report_id:
type: string
effective_policy_ref:
type: string
#  -----------------------------------------------------------------------------
#  RELATED POLICY LINKS
#  -----------------------------------------------------------------------------

related_standards:

* "{brand_id}.brand.core"
* "{brand_id}.standards.visual-identity.colour"
* "{brand_id}.standards.visual-identity.layout"
* "{brand_id}.standards.visual-identity.imagery"
* "{brand_id}.standards.verbal-identity.messaging-framework"
* "{brand_id}.standards.verbal-identity.tone-of-voice"

related_applications:

* "{brand_id}.applications.website"
* "{brand_id}.applications.linkedin"
* "{brand_id}.applications.pitch-deck"
* "{brand_id}.applications.proposal"
* "{brand_id}.applications.packaging"
* "{brand_id}.applications.signage"

---
#  {Brand Name} logo
# # How to complete this template

This is a Brando® Logo standard template. Complete the following steps in order before publishing.

1. Replace every `{placeholder}` value with brand-specific content.
2. Do not replace `<runtime_variable>` values. These are resolved at validation time by the Brando engine.
3. Set `status: draft` and `lifecycle_state: proposed` on first authoring. Update only after governance sign-off.
4. Set `schema.validation_status: ready_for_validation` on first authoring. Update only after a formal parse or review cycle.
5. Remove optional sections that do not apply, or retain them with placeholder values for future use.
6. Remove the `template` metadata block before policy validation.
7. Run the publishing checklist before changing `status` to `active`.

Placeholder reference:

| Token                        | Meaning                                              | Example                        |
| ---------------------------- | ---------------------------------------------------- | ------------------------------ |
| `{brand_id}`                 | Stable machine-readable brand identifier             | `acme-corp`                    |
| `{Brand Name}`               | Human-readable brand name                            | `Acme Corp`                    |
| `{primary_logo_asset_ref}`   | Approved primary logo source asset                   | `logo/primary/full-colour.svg` |
| `{clearspace_unit_basis}`    | Clearspace measurement basis                         | `symbol_width`                 |
| `{minimum_clearspace_units}` | Minimum clearspace units                             | `1.0`                          |
| `{trademark_mark}`           | Required legal mark where applicable                 | `®`                            |
| `<rendered_asset_ref>`       | Runtime reference to rendered output. Do not replace |                                |

---
# # Purpose

This standard governs how {Brand Name} logos are selected, placed, scaled, coloured, rendered, protected, and validated across communications.

The logo system must preserve:

* geometric integrity
* recognition
* clearspace
* legibility
* approved colour usage
* responsive behaviour
* legal and trademark requirements

This is the high-control layer of the visual identity system. Logo misuse is treated as a brand-critical failure unless an explicit exception applies.

---
# # How to interpret this policy

This policy has six layers:

1. Logo assets define the approved source files.
2. Logo policy defines allowed behaviour, colour usage, and misuse.
3. Responsive policy defines which variant should be used at each breakpoint or small-format context.
4. Lockup policy governs co-branding, campaign, product, partner, and endorsement relationships.
5. Trademark policy resolves legal marking requirements by market and context.
6. Execution rules determine whether output passes, warns, or fails.

The YAML front matter is the machine-executable layer. This Markdown body is the human-readable explanation layer. Where they conflict, the YAML governs.

---
# # Logo principles
# ## {Logo Principle 1}

{Explain logo principle 1 in plain language.}

Signals:

* {Signal 1}
* {Signal 2}
* {Signal 3}

Avoid:

* {Avoidance 1}
* {Avoidance 2}

---
# ## {Logo Principle 2}

{Explain logo principle 2 in plain language.}

Signals:

* {Signal 1}
* {Signal 2}
* {Signal 3}

Avoid:

* {Avoidance 1}
* {Avoidance 2}

---
# ## {Logo Principle 3}

{Explain logo principle 3 in plain language.}

Signals:

* {Signal 1}
* {Signal 2}
* {Signal 3}

Avoid:

* {Avoidance 1}
* {Avoidance 2}

---
# # Default execution expectations

Unless an explicit exception is declared in the YAML:

* Use only approved logo assets.
* Use only approved colour variants and colour tokens.
* Do not redraw, stretch, skew, rotate, crop, outline, shadow, texture, or otherwise decorate the logo.
* Do not invert logo colours unless an approved reversed or tokenized variant exists.
* Preserve required clearspace.
* Keep the logo above minimum size.
* Validate contrast against the worst-case point under the logo ink, including gradients and image backgrounds.
* Exclude clearspace from contrast sampling, but check clearspace separately for visual noise.
* Test responsive variants before blocking small-size recognition failures.
* Use visual regression or raster diff for geometry fidelity rather than raw SVG string comparison.
* Apply required trademark markings where market legal policy requires them.

---
# # Responsive fallback behaviour

If a logo fails recognition at a small size, the engine should not immediately stop the build. It should first test the approved fallback path declared in `responsive_logo_policy`.

Typical fallback order:

1. primary logo
2. wordmark
3. symbol
4. monogram
5. favicon

The build blocks only when no approved fallback passes recognition, contrast, clearspace, and legal marking checks.

---
# # Watermark behaviour

Watermarks may use relaxed contrast only when they are redundant to a primary, high-contrast logo elsewhere in the same asset.

A watermark must never be the only visible brand identifier.

---
# # Lockup behaviour

Partner and co-brand lockups must be evaluated for optical balance, not only mathematical alignment. Programmatic lockup generation is allowed, but H005 must check perceived visual weight, optical centering, spacing, separator use, and contrast.

Where a partner contract requires a different lockup, the `partner_contract_exception` must be activated and logged.

---
# # Trademark marking

Trademark marking is governed by `trademark_policy` and any higher-priority `market.legal` policy.

If a market requires ™, ®, or another legal mark, D017 hard-fails when the mark is missing, incorrect, misplaced, or illegible, unless an explicit legal exception applies.

---
# # Exemplars

Each exemplar below is referenced in the YAML by its `active_exemplar_key`. Validators use authoritative repository exemplars retrieved via `exemplars.storage.retrieval`, not the Markdown copies shown here.
# ## {exemplar-name}

Key: `{brand_id}.standards.visual-identity.logo.exemplar.{example_key}`

"{Approved exemplar description or rendered use case.}"

Why it works:

* {Reason 1}
* {Reason 2}
* {Reason 3}

---
# # Anti-exemplars

Anti-exemplars are negative reference material for human review only. They are excluded from deterministic and heuristic validation. They must not be scored, repaired, or published.
# ## {anti-exemplar-name}

"{Anti-exemplar description or rendered use case.}"

Why it fails:

* {Reason 1}
* {Reason 2}
* {Reason 3}

---
# # Validator interpretation notes
# ## Deterministic checks

Implement with approved asset references, structural checks, geometry/raster comparison, colour token checks, safe-area checks, contrast math, responsive mapping, and legal marking checks.

Covered by: D001, D002, D003, D004, D005, D006, D007, D008, D009, D010, D011, D012, D013, D014, D015, D016, D017
# ## Heuristic checks

Implement using computer vision classifiers or model-based evaluators. Every heuristic check must return both a score and a reason. Never return a score alone.

Covered by: H001, H002, H003, H004, H005, H006

All heuristic rules use a normalized 0.0 to 1.0 scale.
# ## Geometry fidelity

D008 must use visual regression or raster diff at high resolution. Raw SVG string comparison is not sufficient because export engines can rewrite equivalent geometry.
# ## Contrast sampling

D007 must validate against the lowest-contrast point under the logo ink. For gradients and image backgrounds, average contrast is not enough. Clearspace is excluded from contrast sampling but checked separately for background noise under D010.
# ## Floating-point tolerance

Rules with `tolerance_px: 0.01` must log the pre-tolerance value. Repeated near-threshold offsets may indicate a design-tool exporter issue rather than a brand violation.
# ## Recognition fallback

H001 should suggest the top approved fallback variants before blocking. The validator should block only when no approved variant passes.

---
# # Change log

| Version | Date       | Changes                    |
| ------- | ---------- | -------------------------- |
| 1.0.0   | YYYY-MM-DD | Initial published version. |

---
# # Validation modes

This file can be validated in two modes.

Template validation: validates the structure of this reusable template. In this mode, the validator recognises `template.is_template: true` and does not require placeholder substitution.

Policy validation: validates an instantiated brand policy. In this mode, all `{placeholder}` values and `YYYY-MM-DD` date placeholders must be replaced, and the `template` metadata block must be removed.

---
# # Publishing checklist

Before publication, confirm:

* All `{placeholder}` values have been replaced with brand-specific content.
* All `YYYY-MM-DD` date placeholders have been replaced with real ISO dates.
* No `<runtime_variable>` values have been replaced.
* The `template` metadata block has been removed.
* The YAML parses successfully with no errors.
* `schema.validation_status` reflects the actual validation state.
* `status` and `lifecycle_state` reflect the actual governance state.
* All logo asset references resolve to approved repository assets.
* All responsive variant references resolve to declared logo asset IDs.
* All colour token references resolve against the pinned Colour Standard version.
* All trademark marking requirements resolve against market legal policy.
* All rule IDs referenced in `execution.rule_execution_order` exist in `rules`.
* All exception IDs referenced in `unless_exception` blocks exist in `exceptions.declared`.
* Logo geometry is validated through raster/visual regression, not raw SVG string comparison alone.
* Contrast is checked against the worst-case point under logo ink.
* Clearspace is excluded from contrast sampling but checked for background noise.
* Watermark use is redundant to a primary high-contrast logo.
* Partner and co-brand lockups pass optical balance checks.
* Trademark marks are present where required.
* Positive exemplars do not violate any deterministic rule.
* Anti-exemplars are explicitly excluded from validation.
* The telemetry schema is valid and the policy key and version are attached to every validation report.
