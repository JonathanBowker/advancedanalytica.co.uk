---
# =============================================================================
# BRANDO® LAYOUT STANDARD TEMPLATE
# brando-schema-1.0 | document_type: policy_standard
# =============================================================================
#
# PLACEHOLDER CONVENTION — READ BEFORE EDITING
# -----------------------------------------------------------------------------
# {curly_brace} placeholders must be replaced with brand-specific content
# before this template is promoted to a brand policy and policy-validated.
#
# <angle_bracket> values are runtime variables resolved at validation time.
# Do NOT replace these. They are consumed by the validation engine.
#
# Quote every YAML value that contains a {curly_brace} placeholder.
# Unquoted curly braces are interpreted as flow mapping syntax and will
# cause a parse error. Quote all placeholder-containing values, including
# list items, map keys, and scalar string values.
#
# Use block scalar style, either | or >, for longer prose fields such as
# description, rationale, notes, and remediation guidance. This reduces the
# risk of YAML parsing errors when prose contains punctuation or braces.
# =============================================================================
#  -----------------------------------------------------------------------------
# DOCUMENT IDENTITY
# -----------------------------------------------------------------------------
# Required. Stable, globally unique identifier for this policy.
# Recommended pattern: {brand_id}.standards.visual-identity.layout

id: "{brand_id}.standards.visual-identity.layout"
#  Required. Usually mirrors id. Use as the stable lookup key in policy
# repositories, MCP servers, APIs, and audit logs.

key: "{brand_id}.standards.visual-identity.layout"
#  Required. Human-readable title.

title: "{Brand Name} Layout"
#  Required. Short description used in repositories, UIs, search, and audit logs.

description: |
Core layout standard governing grid systems, spacing, hierarchy, composition,
responsive behaviour, safe areas, accessibility, and layout-token usage across
{Brand Name} communications.
#  Required. Defines what kind of policy artefact this is.
#  Allowed values:
#  - standard | application | campaign | exception
#  - exemplar_set | lexicon | telemetry_schema

policy_kind: standard
#  Required. Top-level governance pillar.
#  Allowed values controlled by Brando schema:
#  - standards | applications | campaigns | legal | market | safety

pillar: standards
#  Required. Category within the pillar. Use snake_case for controlled terms.

category: visual_identity
#  Required. Subcategory within the category. Use snake_case for controlled terms.

subcategory: layout
#  Required. Used by Brando to distinguish policy standards from related artefacts.
#  Allowed values:
#  - policy_standard | application_policy | campaign_policy | exemplar
#  - exemplar_set | lexicon | classifier_spec | telemetry_schema | validation_report

document_type: policy_standard
#  -----------------------------------------------------------------------------
#  TEMPLATE METADATA
#  -----------------------------------------------------------------------------
#  Identifies this file as a reusable template rather than an instantiated policy.
#  Remove this block when promoting to a brand-specific policy.

template:
is_template: true
placeholder_status: contains_placeholders
instantiate_before_validation: true
#  -----------------------------------------------------------------------------
#  VERSIONING AND LIFECYCLE
#  -----------------------------------------------------------------------------
#  Required. Semantic version. Use MAJOR.MINOR.PATCH.
#  MAJOR: breaking schema or rule changes
#  MINOR: new rules, sections, scope, or behaviours
#  PATCH: typo, copy, clarification, non-breaking fixes

version: "1.0.0"
#  Required. Publication status.
#  Allowed values: draft | active | deprecated | archived

status: draft
#  Required. Governance lifecycle state.
#  Allowed values: proposed | in_review | approved | published | superseded | retired

lifecycle_state: proposed
#  Required once active/published. ISO date. Quote to prevent YAML date parsing.

effective_date: "YYYY-MM-DD"
#  Required. ISO date.

created: "YYYY-MM-DD"
#  Required. ISO date.

last_modified: "YYYY-MM-DD"
#  Recommended. ISO date for next scheduled governance review.

next_review: "YYYY-MM-DD"
#  -----------------------------------------------------------------------------
#  OWNERSHIP AND APPROVAL
#  -----------------------------------------------------------------------------

owner:
#  Required. Owning team or function.

team: "{Brand Team Name}"
#  Recommended. Steward responsible for governance upkeep.

steward: "{Steward Role or Name}"

approved_by:
#  Required once lifecycle_state is approved or published.

* "{Approving Team or Role}"
#  -----------------------------------------------------------------------------
#  SCHEMA METADATA
#  -----------------------------------------------------------------------------

schema:
#  Required. Schema class used by Brando.

type: BrandLayoutStandard
#  Required. Schema version this document conforms to.

version: brando-schema-1.0
#  Required. Validation state of this file.
#  Allowed values:
#  - ready_for_validation: authored but not yet parsed or reviewed
#  - human_reviewed: reviewed by a human but not formally schema-validated
#  - schema_validated: parsed and validated against the declared schema

validation_status: ready_for_validation
#  -----------------------------------------------------------------------------
#  CLIENT NAMING MAP
#  -----------------------------------------------------------------------------
#  Optional but recommended. Maps client-facing terminology to Brando terms.
#  This field supports terminology mapping only. It does not affect enforcement logic.

naming:
client_term: Layout
canonical_term: Visual Identity
policy_label: Layout
rationale: |
{Explain how the client names this artefact and how Brando should map it
into the canonical governance model. canonical_term maps to category;
policy_label maps to subcategory. This field does not affect enforcement logic.}
#  -----------------------------------------------------------------------------
#  SCOPE
#  -----------------------------------------------------------------------------
#  Required. Defines when this policy applies.

scope:
applies_to:
# Required. Distribution or publishing environments.
# Do not mix channels with content types in this list.
channels:
- website
- linkedin
- email
- newsletter
- event_platform
- sales_enablement
- pitch_deck
- proposal
- digital_ad
- print
- social
- mobile

```
# Required. Types of layouts, regions, components, or outputs governed by this policy.
# Composite outputs such as pitch decks, proposals, landing pages, and campaign
# pages should be decomposed into governed layout regions before rule execution.
content_types:
  - page_layout
  - landing_page_layout
  - hero_layout
  - article_layout
  - case_study_layout
  - thought_leadership_layout
  - email_layout
  - newsletter_layout
  - social_layout
  - pitch_deck_layout
  - proposal_layout
  - event_page_layout
  - ad_layout
  - print_layout
  - section_layout
  - card_layout
  - form_layout
  - navigation_layout
  - footer_layout
  - data_visualisation_layout
  - image_text_layout
  - cta_block
  - headline_zone
  - body_copy_zone
  - media_zone
  - proof_zone
  - legal_disclaimer_zone
#  Recommended. Audience or persona types for layout adaptation.
audiences:
  - marketing_manager
  - content_creator
  - social_media
  - executive_communications
  - sales
  - partner_marketing
  - new_hire
  - ai_agent
  - "{audience_1_id}"
  - "{audience_2_id}"
#  Recommended. Zones within layouts.
# Useful for safe areas, overlay regions, citations, metadata, or legal text.
content_zones:
  - rendered_layout
  - safe_area
  - bleed_area
  - trim_area
  - fold_area
  - overlay_area
  - interaction_rail
  - caption_area
  - metadata
  - source_note
  - legal_disclaimer
#  Recommended. Target viewport or output sizes to validate.
breakpoints:
  - mobile
  - tablet
  - desktop
  - wide_desktop
  - print_a4
  - print_letter
  - social_square
  - social_portrait
  - social_landscape
  - story_vertical
#  Recommended. Target aspect ratios to validate for responsive and social use.
target_aspect_ratios:
  - "1:1"
  - "4:5"
  - "9:16"
  - "16:9"
  - "3:2"
  - "2:3"
```

excludes:
content_types:
- legal_contract_layout
- invoice_layout
- procurement_template
- third_party_embedded_widget

notes:
- Applies to generated, edited, and programmatically composed layouts.
- Applies to layout structure and spatial behaviour, not only final rendered appearance.
- Does not apply to third-party embedded widgets unless the embedding application policy explicitly says so.
- Legal or regulated content may impose additional layout requirements through higher-priority policies.
#  -----------------------------------------------------------------------------
#  POLICY PRECEDENCE
#  -----------------------------------------------------------------------------
#  Recommended. Defines how this policy behaves when other policies also apply.

policy_precedence:
priority_order_highest_first:
- global.safety
- global.regulatory
- market.legal
- enterprise.brand-core
- "{brand_id}.applications.*"
- "{brand_id}.standards.visual-identity.layout"
- "{brand_id}.standards.visual-identity.colour"
- "{brand_id}.standards.visual-identity.typography"
- "{brand_id}.standards.visual-identity.imagery"
- "{brand_id}.standards.visual-identity.illustration"
- "{brand_id}.standards.visual-identity.iconography"
- "{brand_id}.standards.verbal-identity.messaging-framework"
- "{brand_id}.standards.verbal-identity.tone-of-voice"
- campaign.local

conflict_resolution:
# Allowed values:
# - higher_priority_wins | most_restrictive_wins | explicit_exception_required
mode: higher_priority_wins
notes:
- Application-specific policy may narrow this standard only within its declared scope.
- Application-specific policy may not weaken higher-priority legal, regulatory, accessibility, or safety constraints.
- Layout governs structure, hierarchy, spacing, safe areas, and responsive behaviour.
- Colour governs approved colour tokens and colour accessibility.
- Typography governs type tokens, sizing, measure, and text rendering.
- Messaging governs what must be said; layout governs whether the message remains comprehensible and accessible in context.
- In cases of collision between messaging length and layout density, H006 cognitive load determines whether comprehension is acceptable. If comprehension fails, adapt the layout, reduce displayed text, or route to messaging repair.
- Exceptions must be explicit and machine-readable to override defaults.
#  -----------------------------------------------------------------------------
#  INHERITANCE
#  -----------------------------------------------------------------------------
#  Optional but recommended for enterprise or multi-brand systems.

inheritance:
inherits_from:
- "{brand_id}.brand.core"
may_be_overridden_by:
- "{brand_id}.applications.website"
- "{brand_id}.applications.linkedin"
- "{brand_id}.applications.newsletter"
- "{brand_id}.applications.pitch-deck"
- "{brand_id}.applications.proposal"
- "{brand_id}.applications.social"
- "{brand_id}.campaigns.*"
- "{brand_id}.legal.*"
- "{brand_id}.market.*"
#  -----------------------------------------------------------------------------
#  RESOLUTION BEHAVIOUR
#  -----------------------------------------------------------------------------
#  Recommended for executable policy systems.

resolution:
resolve_inheritance_before_validation: true
resolve_exceptions_before_rule_execution: true
resolve_layout_tokens_before_rule_execution: true
resolve_channel_safe_areas_before_validation: true
materialize_effective_policy: true
effective_policy_output:
include_resolved_rules: true
include_applied_exceptions: true
include_precedence_path: true
include_resolved_layout_tokens: true
include_resolved_breakpoint_rules: true
include_resolved_safe_areas: true
#  -----------------------------------------------------------------------------
#  LAYOUT PRINCIPLES
#  -----------------------------------------------------------------------------
#  Required. Three to five principles is usually enough.
#  Keep descriptions to one clear sentence each.

principles:
required:
- "{layout_principle_1}"
- "{layout_principle_2}"
- "{layout_principle_3}"
definitions:
# Map keys containing placeholders must be quoted to remain valid YAML.
"{layout_principle_1}":
description: "{Describe layout principle 1 in one clear sentence.}"
"{layout_principle_2}":
description: "{Describe layout principle 2 in one clear sentence.}"
"{layout_principle_3}":
description: "{Describe layout principle 3 in one clear sentence.}"
#  -----------------------------------------------------------------------------
#  LAYOUT POLICY
#  -----------------------------------------------------------------------------
#  Required. Defines what layout must do.

layout_policy:
objectives:
required:
- preserve_message_hierarchy
- maintain_accessibility
- use_approved_layout_tokens
- support_responsive_composition
- protect_required_content_visibility
- keep_cognitive_load_manageable

layout_characteristics:
required:
- clear_hierarchy
- consistent_spacing
- balanced_composition
- accessible_reading_order
- responsive_safe_area_compliance
- brand_consistent_rhythm
discouraged:
- overcrowded_composition
- unbalanced_visual_weight
- inconsistent_spacing
- inaccessible_overlay_text
- hidden_required_content
- unapproved_grid_structure
- decorative_density_without_function

hierarchy:
required_order:
- primary_message
- supporting_message
- proof_or_media
- call_to_action
- secondary_content
- legal_or_metadata
notes:
- The hierarchy defines preferred visual priority, not necessarily DOM order.
- DOM order must remain accessible and should align with logical reading order.
- Layout may compress or stack content at smaller breakpoints only when required content remains visible and accessible.

accessibility:
required:
- minimum_contrast_for_text_and_required_ui
- keyboard_and_screen_reader_order_preserved
- safe_area_not_obscured
- text_not_rasterised_unless_exception_applies
- motion_safe_by_default
notes:
- Contrast must be checked after layout resolution, including overlays, gradients, images, and responsive crops.
- If text sits on an image or gradient, contrast must be validated against the lowest-contrast point in the text bounding box.
#  -----------------------------------------------------------------------------
#  STANDARD DEPENDENCIES
#  -----------------------------------------------------------------------------
#  Recommended. Pin compatible versions when downstream standards may introduce breaking changes.

standard_dependencies:
brand_core_ref: "{brand_id}.brand.core:^1.0.0"
colour_standard_ref: "{brand_id}.standards.visual-identity.colour:^1.0.0"
typography_standard_ref: "{brand_id}.standards.visual-identity.typography:^1.0.0"
imagery_standard_ref: "{brand_id}.standards.visual-identity.imagery:^1.0.0"
illustration_standard_ref: "{brand_id}.standards.visual-identity.illustration:^1.0.0"
iconography_standard_ref: "{brand_id}.standards.visual-identity.iconography:^1.0.0"
messaging_framework_ref: "{brand_id}.standards.verbal-identity.messaging-framework:^1.0.0"
tone_of_voice_ref: "{brand_id}.standards.verbal-identity.tone-of-voice:^1.0.0"
#  -----------------------------------------------------------------------------
#  LAYOUT TOKENS
#  -----------------------------------------------------------------------------
#  Required. Defines approved structural tokens used by layout validation.

layout_tokens:
grid_systems:
- id: "{grid_system_1_id}"
label: "{Grid system 1 label}"
columns: 12
gutter_token: "{spacing_token_gutter}"
margin_token: "{spacing_token_margin}"
allowed_content_types:
- page_layout
- landing_page_layout
- hero_layout
- article_layout
breakpoints:
mobile:
columns: 4
gutter_token: "{spacing_token_gutter_mobile}"
margin_token: "{spacing_token_margin_mobile}"
tablet:
columns: 8
gutter_token: "{spacing_token_gutter_tablet}"
margin_token: "{spacing_token_margin_tablet}"
desktop:
columns: 12
gutter_token: "{spacing_token_gutter_desktop}"
margin_token: "{spacing_token_margin_desktop}"

spacing_tokens:
- id: "{spacing_token_xs}"
value_px: 4
allowed_usage:
- micro_gap
- icon_label_gap
- id: "{spacing_token_s}"
value_px: 8
allowed_usage:
- component_gap
- tight_stack
- id: "{spacing_token_m}"
value_px: 16
allowed_usage:
- default_stack
- card_padding
- id: "{spacing_token_l}"
value_px: 24
allowed_usage:
- section_gap
- content_group_gap
- id: "{spacing_token_xl}"
value_px: 48
allowed_usage:
- major_section_gap
- hero_padding

layout_patterns:
- id: "{layout_pattern_1_id}"
label: "{Layout pattern 1 label}"
pattern_type: hero_layout
semantic_role: primary_storytelling
grid_ref: "{grid_system_1_id}"
allowed_content_types:
- hero_layout
- landing_page_layout
required_zones:
- primary_message
- media_zone
- call_to_action
forbidden_semantic_roles:
- dense_detail
- legal_disclaimer_primary
maximum_visual_density_score: 0.62

```
- id: "{layout_pattern_2_id}"
  label: "{Layout pattern 2 label}"
  pattern_type: card_layout
  semantic_role: grouped_information
  grid_ref: "{grid_system_1_id}"
  allowed_content_types:
    - card_layout
    - case_study_layout
    - thought_leadership_layout
  required_zones:
    - headline_zone
    - body_copy_zone
  forbidden_semantic_roles:
    - primary_storytelling
  maximum_visual_density_score: 0.72
```

approved_region_roles:
- primary_message
- supporting_message
- proof_or_media
- call_to_action
- navigation
- secondary_content
- legal_or_metadata
- decorative_media
#  -----------------------------------------------------------------------------
#  SAFE AREA POLICY
#  -----------------------------------------------------------------------------
#  Required for responsive, social, video, and mobile contexts.

safe_area_policy:
default:
safe_area_required: true
minimum_inner_margin_token: "{spacing_token_m}"
required_content_must_not_overlap:
- trim_area
- bleed_area
- interaction_rail
- caption_area
- legal_disclaimer

channel_specific_safe_areas:
linkedin:
source: channel_spec
avoid_zones:
- platform_ui_overlay
instagram_reels:
source: channel_spec
avoid_zones:
- top_profile_area
- bottom_caption_area
- right_side_interaction_rail
tiktok:
source: channel_spec
avoid_zones:
- right_side_interaction_rail
- bottom_caption_area
youtube_shorts:
source: channel_spec
avoid_zones:
- bottom_caption_area
- right_side_interaction_rail
email:
source: application_policy
avoid_zones:
- preview_pane_truncation_risk

dynamic_safe_area_required_for_social_layout: true
validate_safe_area_across_target_aspect_ratios: true
#  -----------------------------------------------------------------------------
#  RESPONSIVE BEHAVIOUR POLICY
#  -----------------------------------------------------------------------------

responsive_policy:
target_breakpoints:
- mobile
- tablet
- desktop
- wide_desktop
target_aspect_ratios:
- "1:1"
- "4:5"
- "9:16"
- "16:9"
required_behaviours:
- preserve_primary_message_visibility
- preserve_call_to_action_visibility_when_required
- preserve_reading_order
- preserve_minimum_tap_target_size
- preserve_safe_area_across_target_aspect_ratios
allowed_reflow_actions:
- stack_columns
- reduce_non_essential_media
- collapse_secondary_content
- move_cta_after_primary_message
- switch_to_approved_mobile_pattern
forbidden_reflow_actions:
- hide_required_cta
- crop_primary_message
- obscure_subject_or_product
- reverse_accessible_reading_order
- rasterise_live_text_without_exception
#  -----------------------------------------------------------------------------
#  COLOUR AND PRINT MATERIALIZATION POLICY
#  -----------------------------------------------------------------------------
#  Required when layout uses colour tokens, overlay text, gradients, or print output.

colour_resolution_policy:
colour_token_source: "{brand_id}.standards.visual-identity.colour"
resolve_colour_tokens_before_contrast_check: true
resolve_gradient_before_contrast_check: true
contrast_check_strategy:
text_over_solid_colour: foreground_against_background
text_over_image: sampled_worst_case_within_text_bounding_box
text_over_gradient: sampled_worst_case_within_text_bounding_box
gradient_requirement: |
When checking gradients, contrast must be validated against the lowest-contrast
point, or worst-case scenario, of the gradient area covered by the text bounding box.
print_colour_strategy:
cmyk_required_for_print_context: true
if_cmyk_missing_for_print_context:
action: materialize_before_fail
profile: ISO_Coated_v2_ECI
log_as_warning: true
human_review_recommended: true
fail_if_materialization_unavailable: true
#  -----------------------------------------------------------------------------
#  ASSET REPOSITORY POLICY
#  -----------------------------------------------------------------------------
#  Recommended. Prevents infrastructure blips from stopping all validation.

layout_repository:
source_key: "{brand_id}.standards.visual-identity.layout"
mode: referenced
retrieval:
protocol: brando_policy_repo
base_path: /policies/layouts/
key_format: "<layout_key>.json"
auth: service_account
timeout_seconds: 5
cache_ttl_seconds: 604800
fallback_behaviour:
if_repository_unavailable: cached_pass_with_warning
cached_pass_requires_last_known_good: true
cached_pass_max_age_seconds: 604800
if_no_cached_version_available: hard_fail
log_repository_outage: true
#  -----------------------------------------------------------------------------
#  REQUIRED ELEMENTS
#  -----------------------------------------------------------------------------
#  Recommended. Defines layout components generated output should include.

required_elements:
default:
- approved_layout_pattern
- approved_grid_reference
- approved_spacing_tokens
- responsive_breakpoint_rules
- safe_area_definition
- primary_message_zone
- accessible_reading_order
conditional:
- id: cta_visibility_for_cta_required_context
required_when:
cta_required: true
- id: worst_case_contrast_for_overlay_text
required_when:
overlay_text_present: true
- id: print_colour_materialization
required_when:
channel: print
resolution_strategy: |
If CMYK values are missing for a print context, the engine shall attempt
to materialize them using the ISO Coated v2 (ECI) colour profile before
failing. Materialized values must be logged as a warning and should be
routed to human review when colour fidelity is material to the asset.
- id: channel_safe_area_for_social_layout
required_when:
content_type: social_layout
#  -----------------------------------------------------------------------------
#  FIELD APPLICABILITY
#  -----------------------------------------------------------------------------
#  Required if different layout fields need different thresholds.
#  Every content_type in scope.applies_to.content_types that requires field-level
#  threshold checking must have an entry here. Missing entries should produce a
#  schema warning or validation error.

field_applicability:
page_layout:
maximum_visual_density_score: 0.72
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
landing_page_layout:
maximum_visual_density_score: 0.70
minimum_contrast_ratio: 4.5
cta_required: true
responsive_validation_required: true
hero_layout:
maximum_visual_density_score: 0.62
minimum_contrast_ratio: 4.5
cta_required: true
responsive_validation_required: true
article_layout:
maximum_visual_density_score: 0.68
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
case_study_layout:
maximum_visual_density_score: 0.72
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
thought_leadership_layout:
maximum_visual_density_score: 0.70
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
email_layout:
maximum_visual_density_score: 0.74
minimum_contrast_ratio: 4.5
cta_required: true
responsive_validation_required: true
newsletter_layout:
maximum_visual_density_score: 0.76
minimum_contrast_ratio: 4.5
cta_required: true
responsive_validation_required: true
social_layout:
maximum_visual_density_score: 0.66
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
dynamic_safe_area_required: true
pitch_deck_layout:
maximum_visual_density_score: 0.70
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: false
proposal_layout:
maximum_visual_density_score: 0.78
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: false
event_page_layout:
maximum_visual_density_score: 0.70
minimum_contrast_ratio: 4.5
cta_required: true
responsive_validation_required: true
ad_layout:
maximum_visual_density_score: 0.64
minimum_contrast_ratio: 4.5
cta_required: true
responsive_validation_required: true
print_layout:
maximum_visual_density_score: 0.76
minimum_contrast_ratio: 4.5
cta_required: false
cmyk_required: true
responsive_validation_required: false
section_layout:
maximum_visual_density_score: 0.72
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
card_layout:
maximum_visual_density_score: 0.72
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
form_layout:
maximum_visual_density_score: 0.70
minimum_contrast_ratio: 4.5
cta_required: true
responsive_validation_required: true
navigation_layout:
maximum_visual_density_score: 0.62
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
footer_layout:
maximum_visual_density_score: 0.78
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
data_visualisation_layout:
maximum_visual_density_score: 0.78
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
image_text_layout:
maximum_visual_density_score: 0.68
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
cta_block:
maximum_visual_density_score: 0.60
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
headline_zone:
maximum_visual_density_score: 0.60
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
body_copy_zone:
maximum_visual_density_score: 0.70
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
media_zone:
maximum_visual_density_score: 0.76
minimum_contrast_ratio: 3.0
cta_required: false
responsive_validation_required: true
proof_zone:
maximum_visual_density_score: 0.74
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: true
legal_disclaimer_zone:
maximum_visual_density_score: 0.82
minimum_contrast_ratio: 4.5
cta_required: false
responsive_validation_required: false
#  -----------------------------------------------------------------------------
#  PERSONA PROFILES
#  -----------------------------------------------------------------------------
#  Optional. Use when the same layout standard needs slightly different behaviour
#  for designers, editors, social teams, sales teams, new hires, or AI agents.

persona_profiles:
marketing_manager:
layout_adjustment: standard
content_creator:
layout_adjustment: standard
social_media:
layout_adjustment: channel_native_safe_area_strict
executive_communications:
layout_adjustment: refined_hierarchy_and_low_density
sales:
layout_adjustment: proof_and_cta_visibility_led
partner_marketing:
layout_adjustment: co_branding_safe_area_and_lockup_led
new_hire:
layout_adjustment: explanatory
ai_agent:
layout_adjustment: strict_constraint_enforcement
#  -----------------------------------------------------------------------------
#  EXCEPTIONS
#  -----------------------------------------------------------------------------
#  Required for executable governance. All exceptions must be declared here.
#  Undeclared exceptions hard fail.

exceptions:
undeclared_exception_behaviour: hard_fail
validation:
exception_must_be_declared_in_policy: true
exception_must_match_content_context: true
log_all_exception_activations: true

declared:
- id: legal_text_exception
description: Legal or regulated layout requirements may override visual layout preferences where required by law or compliance.
when:
policy_context:
higher_priority_policy_matches:
- "{brand_id}.legal.*"
- global.regulatory
override:
enforcement_mode: defer_to_higher_policy

```
- id: platform_ui_exception
  description: Platform-rendered UI components may use platform-imposed spacing or layout behaviour where the brand cannot control the final interface.
  when:
    content_zone:
      - platform_ui_overlay
  override:
    enforcement_mode: platform_constraint_relaxed
    skip_rules:
      - D002
      - D005
      - D007

- id: campaign_adaptation_exception
  description: Campaign policies may adapt approved layouts for campaign context if the adapted layout remains traceable to an approved layout pattern and preserves accessibility.
  when:
    application:
      - "{brand_id}.campaigns.*"
  override:
    enforcement_mode: campaign_adaptation_allowed
    requirements:
      - approved_layout_pattern_required
      - accessibility_required
      - safe_area_required
      - no_required_content_hidden

- id: print_production_exception
  description: Print production may override digital spacing or safe-area defaults where bleed, trim, stock, or finishing requirements demand it.
  when:
    channel:
      - print
  override:
    enforcement_mode: print_production_adjustment_allowed
    requirements:
      - bleed_and_trim_required
      - cmyk_required_or_materialized
      - production_review_required
```
#  -----------------------------------------------------------------------------
#  EXEMPLARS
#  -----------------------------------------------------------------------------
#  Recommended. Positive examples for human guidance and semantic scoring.

exemplars:
minimum_review_count: 2

markdown_examples:
role: human_readable_copy
authoritative: false
excluded_from_validation: true

storage:
mode: referenced
source_key: "{brand_id}.standards.visual-identity.layout"
section: exemplars
load_at_validation: true
retrieval:
protocol: brando_policy_repo
base_path: /policies/exemplars/
key_format: "<exemplar_key>.md"
auth: service_account
timeout_seconds: 5
cache_ttl_seconds: 604800

fallback_behaviour:
if_exemplars_unavailable: skip_rule_with_warning
affected_rules:
- H005

active_exemplar_keys:
- "{brand_id}.standards.visual-identity.layout.exemplar.{example_key_1}"
- "{brand_id}.standards.visual-identity.layout.exemplar.{example_key_2}"

source_contexts:
channels:
- website
- linkedin
- newsletter
- pitch_deck
- print
content_types:
- hero_layout
- landing_page_layout
- email_layout
- social_layout
- pitch_deck_layout
- print_layout
#  -----------------------------------------------------------------------------
#  COMPETITIVE DIFFERENTIATION
#  -----------------------------------------------------------------------------
#  Optional. Helps human reviewers understand contrastive layout positioning.

competitive_differentiation:
competitors:
- "{competitor_1}"
- "{competitor_2}"
layout_norms_to_avoid:
- "{Generic layout pattern or category convention to avoid}"
differentiators:
- "{Differentiator 1}"
- "{Differentiator 2}"
#  -----------------------------------------------------------------------------
#  ANTI-EXEMPLARS
#  -----------------------------------------------------------------------------
#  Optional. Negative examples for human review only.
#  Anti-exemplars are excluded from all deterministic and heuristic validation.

anti_exemplars:
enforcement_role: negative_reference_only
used_by_rules: []
excluded_from_deterministic_validation: true
excluded_from_heuristic_validation: true
sources:
- id: "{anti_exemplar_source_1}"
label: "{Human-readable label}"
for_human_review_only: true
#  -----------------------------------------------------------------------------
#  DOCUMENT SELF-VALIDATION
#  -----------------------------------------------------------------------------
#  Recommended. Defines which parts of this file are subject to rule validation.

document_self_validation:
validate_yaml_structure: true
validate_authoritative_positive_exemplars: true
validate_layout_token_references: true
validate_breakpoint_rules: true
validate_safe_area_references: true
validate_standard_dependency_versions: true
validate_no_circular_layout_references: true
exclude_markdown_guidance: true
exclude_change_log: true
exclude_comments: true
exclude_anti_exemplars: true
exclude_markdown_exemplar_copies: true
notes:
- validate_authoritative_positive_exemplars applies only to repository exemplars retrieved via exemplars.storage.retrieval.
- Layout token references include grid ids, spacing token ids, pattern ids, safe-area ids, and breakpoint ids.
- Circular reference checks apply to layout pattern inheritance, responsive variants, and token aliasing.
- Markdown exemplar copies are excluded per exemplars.markdown_examples.excluded_from_validation.
- Anti-exemplars are excluded per anti_exemplars.excluded_from_deterministic_validation.
- YAML comments are excluded as they are stripped before rule execution.
#  -----------------------------------------------------------------------------
#  CLASSIFIERS
#  -----------------------------------------------------------------------------
#  Optional. Declare any judgement-based classifiers required by heuristic rules.
#  Any classifier referenced in a rule's detect.requires_classifier field
#  must have a full specification entry here.

classifiers:
layout_semantic_fit_classifier:
description: |
Scores whether a layout pattern, spatial hierarchy, and zone structure fit
the declared content type, semantic role, channel, and audience need.
output:
type: object
properties:
semantic_fit_score:
type: number
scale: "0.0_to_1.0"
reason:
type: string
nearest_approved_patterns:
type: array
max_items: 3
items:
type: string
used_by_rules:
- H001

hierarchy_classifier:
description: |
Scores whether the layout makes the primary message, supporting message,
proof or media, CTA, and secondary content visually understandable in the
intended order.
output:
type: object
properties:
hierarchy_score:
type: number
scale: "0.0_to_1.0"
reason:
type: string
hierarchy_conflicts:
type: array
items:
type: string
used_by_rules:
- H002

responsive_fit_classifier:
description: |
Scores whether a layout preserves required content, hierarchy, safe areas,
and accessibility across declared breakpoints and target aspect ratios.
output:
type: object
properties:
responsive_fit_score:
type: number
scale: "0.0_to_1.0"
failing_breakpoints:
type: array
items:
type: string
recommended_repairs:
type: array
items:
type: string
used_by_rules:
- H003

accessibility_risk_classifier:
description: |
Scores accessibility risk not fully captured by deterministic checks,
including visual ambiguity, reading-order mismatch, target-size weakness,
and motion or overlay risk.
output:
type: object
properties:
accessibility_risk_score:
type: number
scale: "0.0_to_1.0"
reason:
type: string
risk_drivers:
type: array
items:
type: string
used_by_rules:
- H004

layout_exemplar_alignment_classifier:
description: |
Scores whether a layout aligns with approved layout exemplars in rhythm,
hierarchy, density, and spatial character.
output:
type: object
properties:
exemplar_alignment_score:
type: number
scale: "0.0_to_1.0"
reason:
type: string
nearest_exemplar_keys:
type: array
max_items: 3
items:
type: string
used_by_rules:
- H005

cognitive_load_classifier:
description: |
Scores whether the layout is easy to understand at the intended speed and
context of use. Inputs may include visual density, region count, competing
focal points, reading path ambiguity, whitespace ratio, and task complexity.
output:
type: object
properties:
cognitive_load_score:
type: number
scale: "0.0_to_1.0"
comprehension_risk:
type: string
reason:
type: string
recommended_repairs:
type: array
items:
type: string
used_by_rules:
- H006

layout_density_classifier:
description: |
Scores layout density using element count, occupied area, whitespace ratio,
path or component density, saliency congestion, and overlap pressure. The
classifier must return the crowded regions so targeted repair can adjust
the specific areas causing the failure.
output:
type: object
properties:
density_score:
type: number
scale: "0.0_to_1.0"
crowded_regions:
type: array
items:
type: object
properties:
zone_id:
type: string
bounding_box:
type: object
properties:
x:
type: number
y:
type: number
width:
type: number
height:
type: number
density_drivers:
type: array
items:
type: string
heatmap_ref:
type: string
recommended_repairs:
type: array
items:
type: string
used_by_rules:
- H007

prompt_output_fidelity_classifier:
description: |
Compares the structured prompt or generation instruction against the
rendered layout. It detects whether requested grid, spacing, hierarchy,
safe-area, density, breakpoint, or component constraints were ignored.
output:
type: object
properties:
fidelity_score:
type: number
scale: "0.0_to_1.0"
mismatched_constraints:
type: array
items:
type: string
reason:
type: string
used_by_rules:
- H008
#  -----------------------------------------------------------------------------
#  EXECUTION
#  -----------------------------------------------------------------------------
#  Required for executable validation.

execution:
#  Allowed values: blocking | advisory | audit_only

enforcement_mode: blocking

max_retry_attempts: 3
escalate_to_human_after: 3
#  Declares the valid ID pattern for each rule phase.

rule_id_policy:
deterministic_pattern: "^D[0-9]{3}$"
heuristic_pattern: "^H[0-9]{3}[A-Z]?$"

rule_execution_order:
phase_1_deterministic:
- D001
- D002
- D003
- D004
- D005
- D006
- D007
- D008
- D009
- D010
- D011
- D012
- D013
- D014
- D015
- D016
- D017
phase_2_heuristic:
- H001
- H002
- H003
- H004
- H005
- H006
- H007
- H008
notes: Run all deterministic rules first. Only proceed to heuristic rules if all deterministic rules pass or produce soft warnings only.

heuristic_decisioning:
low_confidence_ignore_below: 0.60
medium_confidence_warn_at_or_above: 0.60
high_confidence_enforce_at_or_above: 0.85
threshold_resolution:
policy: per_rule_takes_precedence
notes:
- Where a rule declares its own threshold, that value governs for that rule.
- Global heuristic_decisioning thresholds apply only where a rule does not declare its own threshold.
- All heuristic scores use a 0.0-1.0 scale. Do not use 0-100 percentage scores.

retry_strategy:
mode: targeted_repair_then_regenerate
repair_scope:
deterministic_failures: layout_or_token_level
heuristic_failures: layout_or_template_level
breakpoint_failures:
first_attempt: adjust_spacing_tokens_container_rules_and_safe_area_offsets
second_attempt: adjust_breakpoint_specific_reflow_rules
after_two_failed_repairs: reselect_approved_layout_pattern_or_full_regeneration
after_two_failed_repairs: full_regeneration_or_template_reselection
repair_instruction_format:
include_violation_id: true
include_failing_layout_ref: true
include_failing_zone_or_component: true
include_failing_breakpoint: true
include_failing_viewport: true
include_pre_tolerance_measurement: true
include_remediation_action: true
include_nearest_approved_templates: true
include_grid_spacing_or_breakpoint_reference: true
include_density_heatmap_or_crowded_regions: true
sequence:
- repair_deterministic_failures
- repair_breakpoint_failures_with_token_and_container_adjustments
- re-evaluate
- repair_breakpoint_failures_with_reflow_adjustments
- re-evaluate
- repair_heuristic_weaknesses
- re-evaluate
- reselect_template_or_regenerate_if_still_failing

output_contract:
must_pass:
- no_hard_fail_rules
may_pass_with_warnings:
- soft_warn_only
- cached_repository_pass_with_warning
- materialized_cmyk_values_with_warning
must_block:
- any_hard_fail_after_max_retries
- required_content_hidden
- inaccessible_contrast
- unsafe_social_overlay
- unresolved_layout_token
#  -----------------------------------------------------------------------------
#  RULES
#  -----------------------------------------------------------------------------
#  Required. Rules are executable validation checks.

rules:
deterministic:
- id: D001
name: approved_layout_pattern_missing
severity: hard_fail
applies_to:
- page_layout
- landing_page_layout
- hero_layout
- email_layout
- social_layout
- pitch_deck_layout
- proposal_layout
- ad_layout
detect:
method: structural_reference
required_reference_types:
- layout_pattern
allowed_reference_sources:
- layout_tokens.layout_patterns.id
remediation:
action: attach_to_approved_layout_pattern_or_rewrite

```
- id: D002
  name: grid_alignment_invalid
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - section_layout
    - card_layout
    - email_layout
    - social_layout
    - pitch_deck_layout
    - proposal_layout
  detect:
    method: grid_alignment_check
    allowed_grids_from: layout_tokens.grid_systems.id
    tolerance_px: 0.01
    log_pre_tolerance_value: true
  remediation:
    action: snap_to_approved_grid

- id: D003
  name: contrast_below_minimum
  severity: hard_fail
  applies_to:
    - hero_layout
    - page_layout
    - landing_page_layout
    - article_layout
    - email_layout
    - social_layout
    - ad_layout
    - cta_block
    - headline_zone
    - body_copy_zone
  detect:
    method: contrast_check
    minimum_from_field_applicability: minimum_contrast_ratio
    resolve_colour_tokens_before_check: true
    resolve_gradient_before_check: true
    resolve_image_underlay_before_check: true
    sample_strategy: worst_case_within_text_bounding_box
    gradient_requirement: |
      When checking gradients, contrast must be validated against the lowest-contrast
      point, or worst-case scenario, of the gradient area covered by the text bounding box.
    image_requirement: |
      When checking text over imagery, contrast must be validated against the lowest-contrast
      sampled point within the rendered text bounding box, not by average contrast.
  remediation:
    action: adjust_overlay_colour_scrim_or_text_placement

- id: D004
  name: breakpoint_failure
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - article_layout
    - email_layout
    - newsletter_layout
    - social_layout
    - ad_layout
    - form_layout
    - navigation_layout
  detect:
    method: responsive_breakpoint_check
    target_breakpoints_from: scope.applies_to.breakpoints
    target_aspect_ratios_from: scope.applies_to.target_aspect_ratios
    required_behaviours_from: responsive_policy.required_behaviours
    check_required_content_visibility: true
    check_reading_order: true
    check_safe_area: true
  remediation:
    action: repair_breakpoint_rules_reflow_or_layout_pattern
    escalation:
      level_1: adjust_spacing_tokens_container_widths_wrapping_and_safe_area_offsets
      level_2: adjust_breakpoint_specific_reflow_rules
      level_3: reselect_approved_layout_pattern_or_regenerate
    notes:
      - Pattern reselection is a regeneration event, not a first-line repair.
      - Token and reflow repairs should be attempted before changing the approved layout pattern.
      - If a pattern cannot preserve hierarchy, accessibility, and required content across target breakpoints, escalate to approved pattern reselection.

- id: D005
  name: spacing_token_invalid
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - section_layout
    - card_layout
    - email_layout
    - social_layout
    - pitch_deck_layout
    - proposal_layout
  detect:
    method: token_reference_check
    allowed_tokens_from: layout_tokens.spacing_tokens.id
    tolerance_px: 0.01
    log_pre_tolerance_value: true
  remediation:
    action: replace_with_nearest_approved_spacing_token

- id: D006
  name: required_content_missing_or_hidden
  severity: hard_fail
  applies_to:
    - landing_page_layout
    - hero_layout
    - email_layout
    - newsletter_layout
    - social_layout
    - ad_layout
    - form_layout
    - cta_block
  detect:
    method: required_region_visibility_check
    required_regions_from: layout_policy.hierarchy.required_order
    required_elements_from: required_elements.default
    check_visibility_across_breakpoints: true
  remediation:
    action: restore_required_content_visibility

- id: D007
  name: safe_area_violation
  severity: hard_fail
  applies_to:
    - social_layout
    - ad_layout
    - video_layout
    - mobile
    - print_layout
    - hero_layout
    - landing_page_layout
  detect:
    method: safe_area_overlap_check
    resolve_channel_safe_areas_before_validation: true
    dynamic_safe_area_required_for_social_layout: true
    validate_across_target_aspect_ratios: true
    target_aspect_ratios_from: scope.applies_to.target_aspect_ratios
    required_content_must_not_overlap_from: safe_area_policy.default.required_content_must_not_overlap
  remediation:
    action: move_required_content_inside_channel_safe_area

- id: D008
  name: reading_order_invalid
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - article_layout
    - email_layout
    - newsletter_layout
    - form_layout
    - pitch_deck_layout
    - proposal_layout
  detect:
    method: reading_order_check
    compare_visual_order_to_accessible_order: true
    required_order_from: layout_policy.hierarchy.required_order
  remediation:
    action: reorder_accessible_structure_or_visual_hierarchy

- id: D009
  name: pixel_snap_invalid
  severity: soft_warn
  applies_to:
    - icon_layout
    - card_layout
    - navigation_layout
    - form_layout
    - data_visualisation_layout
    - social_layout
    - ad_layout
  detect:
    method: pixel_snap_check
    pixel_snap_required: true
    tolerance_px: 0.01
    log_pre_tolerance_value: true
  remediation:
    action: snap_to_pixel_grid_with_tolerance

- id: D010
  name: print_colour_materialization_failed
  severity: hard_fail
  applies_to:
    - print_layout
    - proposal_layout
    - pitch_deck_layout
  detect:
    method: cmyk_materialization_check
    when:
      channel: print
    cmyk_required_from: colour_resolution_policy.print_colour_strategy.cmyk_required_for_print_context
    materialization_profile: ISO_Coated_v2_ECI
    materialize_before_fail: true
    log_materialized_values_as_warning: true
  remediation:
    action: materialize_cmyk_values_or_route_to_colour_review

- id: D011
  name: circular_reference_detected
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - section_layout
    - card_layout
    - pitch_deck_layout
    - proposal_layout
  detect:
    method: graph_cycle_check
    scope:
      - layout_tokens
      - responsive_policy
      - inheritance
  remediation:
    action: remove_circular_reference_or_flatten_layout_dependencies

- id: D012
  name: repository_asset_unavailable
  severity: soft_warn
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - social_layout
    - pitch_deck_layout
    - proposal_layout
  detect:
    method: repository_availability_check
    source: layout_repository.retrieval
    fallback_behaviour: layout_repository.fallback_behaviour
  remediation:
    action: use_cached_known_good_layout_or_retry_repository

- id: D013
  name: semantic_type_pairing_invalid
  severity: hard_fail
  applies_to:
    - hero_layout
    - card_layout
    - data_visualisation_layout
    - social_layout
    - ad_layout
    - legal_disclaimer_zone
  detect:
    method: semantic_type_pairing_check
    source: layout_tokens.layout_patterns
    invalid_pairings:
      - content_type: hero_layout
        semantic_role: dense_detail
      - content_type: legal_disclaimer_zone
        semantic_role: primary_storytelling
      - content_type: data_visualisation_layout
        semantic_role: decorative_media
      - content_type: cta_block
        semantic_role: legal_or_metadata
  remediation:
    action: select_semantically_appropriate_layout_pattern

- id: D014
  name: orphaned_layout_token
  severity: soft_warn
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - section_layout
    - card_layout
  detect:
    method: orphaned_token_check
    token_sources:
      - layout_tokens.grid_systems.id
      - layout_tokens.spacing_tokens.id
      - layout_tokens.layout_patterns.id
    active_reference_sources:
      - layout_tokens.layout_patterns.grid_ref
      - layout_tokens.grid_systems.gutter_token
      - layout_tokens.grid_systems.margin_token
      - exemplars.active_exemplar_keys
  remediation:
    action: remove_unused_token_or_map_to_active_layout_pattern

- id: D015
  name: prompt_output_structure_mismatch
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - email_layout
    - social_layout
    - pitch_deck_layout
    - proposal_layout
    - ad_layout
  detect:
    method: structured_prompt_output_constraint_check
    compare_prompt_constraints_to_rendered_layout: true
    required_prompt_fields:
      - layout_pattern
      - grid_ref
      - spacing_tokens
      - hierarchy
      - breakpoint_behaviour
      - safe_area
  remediation:
    action: regenerate_or_repair_to_match_prompt_constraints

- id: D016
  name: layout_repository_cached_pass_used
  severity: soft_warn
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - email_layout
    - social_layout
    - pitch_deck_layout
    - proposal_layout
  detect:
    method: repository_cached_pass_check
    cached_pass_max_age_seconds: 604800
    log_repository_outage: true
  remediation:
    action: refresh_repository_validation_when_available

- id: D017
  name: required_cta_inside_cta_block_loop
  severity: hard_fail
  applies_to:
    - cta_block
  detect:
    method: recursive_required_element_check
    target: call_to_action
    cta_required_must_be_false_for_cta_block: true
  remediation:
    action: set_cta_block_cta_required_false_or_remove_recursive_cta_requirement
```

heuristic:
- id: H001
name: weak_layout_semantic_fit
severity: hard_fail
applies_to:
- page_layout
- landing_page_layout
- hero_layout
- email_layout
- social_layout
- pitch_deck_layout
- proposal_layout
- ad_layout
detect:
method: layout_semantic_fit_classifier
threshold: 0.80
remediation:
action: select_more_semantically_appropriate_layout_pattern
guidance: suggest_top_three_nearest_approved_patterns

```
- id: H002
  name: weak_visual_hierarchy
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - article_layout
    - email_layout
    - social_layout
    - pitch_deck_layout
    - proposal_layout
  detect:
    method: hierarchy_classifier
    threshold: 0.80
  remediation:
    action: strengthen_primary_message_hierarchy

- id: H003
  name: weak_responsive_fit
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - article_layout
    - email_layout
    - social_layout
    - ad_layout
  detect:
    method: responsive_fit_classifier
    threshold: 0.80
  remediation:
    action: repair_responsive_layout_or_reselect_pattern

- id: H004
  name: accessibility_risk_high
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - email_layout
    - social_layout
    - ad_layout
    - form_layout
  detect:
    method: accessibility_risk_classifier
    threshold: 0.85
  remediation:
    action: reduce_accessibility_risk_and_revalidate

- id: H005
  name: low_exemplar_alignment_score
  severity: soft_warn
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - email_layout
    - social_layout
    - pitch_deck_layout
    - proposal_layout
  detect:
    method: layout_exemplar_alignment_classifier
    threshold: 0.70
    scale: "0.0_to_1.0"
  remediation:
    action: revise_toward_approved_layout_patterns

- id: H006
  name: cognitive_load_too_high
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - article_layout
    - email_layout
    - newsletter_layout
    - social_layout
    - pitch_deck_layout
    - proposal_layout
  detect:
    method: cognitive_load_classifier
    threshold: 0.85
    collision_resolution_role: messaging_length_vs_layout_density_tiebreaker
  remediation:
    action: reduce_cognitive_load_or_route_to_messaging_repair

- id: H007
  name: visual_density_too_high
  severity: soft_warn
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - article_layout
    - email_layout
    - newsletter_layout
    - social_layout
    - pitch_deck_layout
    - proposal_layout
    - data_visualisation_layout
  detect:
    method: layout_density_classifier
    maximum_from_field_applicability: maximum_visual_density_score
    require_crowded_regions_output: true
    require_heatmap_or_coordinate_output: true
  remediation:
    action: reduce_density_in_flagged_regions
    guidance: use_crowded_regions_and_density_drivers_for_targeted_repair

- id: H008
  name: prompt_output_fidelity_low
  severity: hard_fail
  applies_to:
    - page_layout
    - landing_page_layout
    - hero_layout
    - email_layout
    - social_layout
    - pitch_deck_layout
    - proposal_layout
    - ad_layout
  detect:
    method: prompt_output_fidelity_classifier
    threshold: 0.80
  remediation:
    action: repair_or_regenerate_to_match_structured_prompt
```
#  -----------------------------------------------------------------------------
#  DECISION POLICY
#  -----------------------------------------------------------------------------
#  Required. Defines pass/warn/fail and publishing behaviour.

decision_policy:
pass_conditions:
- zero_hard_failures
warn_conditions:
- one_or_more_soft_warnings
fail_conditions:
- one_or_more_hard_failures
publish_conditions:
- status in [pass, warn]
- hard_fail_count == 0

warn_behaviour:
auto_publish_allowed: true
conflict_resolution:
mode: most_restrictive_wins
notes:
- If any matched channel, content_type, accessibility rule, or legal requirement requires human sign-off, human sign-off is required.
- Auto-publish is allowed only when no matched rule requires human sign-off.
- Cached repository passes and CMYK materialization warnings may publish only where the matched application policy permits warnings.
requires_human_sign_off_on_warn:
channels:
- website
- pitch_deck
- sales_enablement
- print
content_types:
- hero_layout
- landing_page_layout
- proposal_layout
- print_layout
warning_types:
- cached_repository_pass_with_warning
- materialized_cmyk_values_with_warning
- visual_density_too_high
allows_auto_publish_on_warn:
channels:
- linkedin
- newsletter
content_types:
- social_layout
- email_layout
- newsletter_layout

human_review_conditions:
- retry_count >= 3
- unresolved_heuristic_conflict == true
- cached_repository_pass_with_warning == true
- materialized_cmyk_values_with_warning == true
- accessibility_risk_high == true
#  -----------------------------------------------------------------------------
#  TELEMETRY
#  -----------------------------------------------------------------------------
#  Recommended for auditability. Required for automated governance pipelines.

telemetry:
log_policy_key: true
log_policy_version: true
log_rule_failures: true
log_retry_history: true
log_exception_usage: true
log_layout_pattern_refs: true
log_grid_refs: true
log_spacing_token_refs: true
log_breakpoint_results: true
log_safe_area_results: true
log_pre_tolerance_measurements: true
log_density_heatmaps: true
log_cmyk_materialization: true
log_repository_cache_usage: true
retain_validation_report: true
output_format: json
schema:
type: object
properties:
policy_key:
type: string
policy_version:
type: string
content_id:
type: string
content_type:
type: string
channel:
type: string
audience:
type: string
persona:
type: string
timestamp:
type: string
format: iso8601
layout_pattern_refs:
type: array
items:
type: string
grid_refs:
type: array
items:
type: string
spacing_token_refs:
type: array
items:
type: string
breakpoint_results:
type: array
items:
type: object
properties:
breakpoint:
type: string
status:
type: string
reason:
type: string
safe_area_results:
type: array
items:
type: object
properties:
channel:
type: string
aspect_ratio:
type: string
status:
type: string
obscured_regions:
type: array
items:
type: string
pre_tolerance_measurements:
type: array
items:
type: object
properties:
rule_id:
type: string
measured_value:
type: number
tolerance:
type: number
unit:
type: string
density_results:
type: object
properties:
density_score:
type: number
heatmap_ref:
type: string
crowded_regions:
type: array
items:
type: object
cmyk_materialization:
type: object
properties:
materialized:
type: boolean
profile:
type: string
warning_logged:
type: boolean
repository_cache_usage:
type: object
properties:
cached_pass_used:
type: boolean
cache_age_seconds:
type: integer
source_key:
type: string
rule_results:
type: array
items:
type: object
properties:
rule_id:
type: string
severity:
type: string
status:
type: string
reason:
type: string
score:
type: number
retry_count:
type: integer
exception_activations:
type: array
items:
type: object
properties:
exception_id:
type: string
reason:
type: string
matched_context:
type: object
final_decision:
type: string
validation_report_id:
type: string
effective_policy_ref:
type: string
#  -----------------------------------------------------------------------------
#  RELATED POLICY LINKS
#  -----------------------------------------------------------------------------

related_standards:

* "{brand_id}.brand.core"
* "{brand_id}.standards.visual-identity.colour"
* "{brand_id}.standards.visual-identity.typography"
* "{brand_id}.standards.visual-identity.imagery"
* "{brand_id}.standards.visual-identity.illustration"
* "{brand_id}.standards.visual-identity.iconography"
* "{brand_id}.standards.verbal-identity.messaging-framework"
* "{brand_id}.standards.verbal-identity.tone-of-voice"

related_applications:

* "{brand_id}.applications.website"
* "{brand_id}.applications.linkedin"
* "{brand_id}.applications.newsletter"
* "{brand_id}.applications.pitch-deck"
* "{brand_id}.applications.proposal"
* "{brand_id}.applications.social"
* "{brand_id}.applications.print"

---
#  {Brand Name} layout
# # How to complete this template

This is a Brando® Layout standard template. Complete the following steps in order before publishing.

1. Replace every `{placeholder}` value with brand-specific content.
2. Do not replace `<runtime_variable>` values. These are resolved at validation time by the Brando engine.
3. Set `status: draft` and `lifecycle_state: proposed` on first authoring. Update only after governance sign-off.
4. Set `schema.validation_status: ready_for_validation` on first authoring. Update only after a formal parse or review cycle.
5. Remove optional sections that do not apply, or retain them with placeholder values for future use.
6. Remove the `template` metadata block before policy validation.
7. Run the publishing checklist before changing `status` to `active`.

Placeholder reference:

| Token                   | Meaning                                  | Example             |
| ----------------------- | ---------------------------------------- | ------------------- |
| `{brand_id}`            | Stable machine-readable brand identifier | `acme-corp`         |
| `{Brand Name}`          | Human-readable brand name                | `Acme Corp`         |
| `{layout_principle_1}`  | First core layout principle label        | `clear_hierarchy`   |
| `{grid_system_1_id}`    | Approved grid system identifier          | `responsive-12-col` |
| `{layout_pattern_1_id}` | Approved layout pattern identifier       | `hero-split-media`  |
| `{spacing_token_m}`     | Approved spacing token identifier        | `space-m`           |
| `{example_key_1}`       | Exemplar short key                       | `website-hero`      |
| `<layout_key>`          | Runtime variable. Do not replace         |                     |
| `<exemplar_key>`        | Runtime variable. Do not replace         |                     |

---
# # Purpose

This standard governs the approved layout system for {Brand Name}. It is designed for human creators, AI systems, validators, editors, designers, campaign teams, and publishing workflows.

The layout standard defines how messages, images, components, calls to action, and legal content are arranged so every output remains clear, accessible, responsive, and recognisably on brand.

It governs:

* Grid systems
* Spacing tokens
* Layout patterns
* Visual hierarchy
* Responsive behaviour
* Breakpoints and aspect ratios
* Safe areas
* Overlay contrast
* Cognitive load
* Layout repair and regeneration behaviour

---
# # How to interpret this policy

This policy has six layers:

1. Layout tokens define the approved grid, spacing, and pattern system.
2. Layout policy defines required hierarchy, accessibility, safe-area, and responsive behaviour.
3. Field applicability defines thresholds for each layout type or region.
4. Exemplars show what good layout looks like.
5. Execution rules determine whether output passes, warns, or fails.
6. Telemetry records every layout decision, repair, warning, and exception.

The YAML front matter is the machine-executable layer. This Markdown body is the human-readable guidance layer. Where they conflict, the YAML governs.

If a rule conflicts with a higher-priority legal, regulatory, accessibility, or safety policy, the higher-priority policy wins.

If a rule conflicts with an application-specific exception declared in the YAML, the declared exception applies.

---
# # Layout principles
# ## {Layout Principle 1}

{Explain layout principle 1 in plain language.}

Signals:

* {Signal 1}
* {Signal 2}
* {Signal 3}

Good examples:

* "{Good example 1}"
* "{Good example 2}"

Avoid:

* {Avoidance 1}
* {Avoidance 2}

---
# ## {Layout Principle 2}

{Explain layout principle 2 in plain language.}

Signals:

* {Signal 1}
* {Signal 2}
* {Signal 3}

Good examples:

* "{Good example 1}"
* "{Good example 2}"

Avoid:

* {Avoidance 1}
* {Avoidance 2}

---
# ## {Layout Principle 3}

{Explain layout principle 3 in plain language.}

Signals:

* {Signal 1}
* {Signal 2}
* {Signal 3}

Good examples:

* "{Good example 1}"
* "{Good example 2}"

Avoid:

* {Avoidance 1}
* {Avoidance 2}

---
# # Layout tokens and patterns

The layout tokens are the source of truth for approved structure.

Use them in this order:

1. Select an approved layout pattern.
2. Resolve the grid system for the content type and breakpoint.
3. Apply approved spacing tokens.
4. Place required regions in the approved hierarchy.
5. Resolve safe areas for the channel and aspect ratio.
6. Validate contrast, density, and accessibility after rendering.

A generated layout should never invent a new grid, spacing rhythm, or pattern unless an exception or application policy explicitly allows it.

---
# # Responsive behaviour

Responsive layout validation must test more than one viewport. A layout that works at desktop but hides the CTA on mobile fails. A layout that passes 16:9 but obscures the primary message in 9:16 fails.

For social and mobile contexts, safe areas are dynamic. The validator must account for channel-specific overlays such as captions, profile areas, and interaction rails.

Breakpoint repair should proceed in this order:

1. Adjust spacing tokens, container widths, wrapping, and safe-area offsets.
2. Adjust breakpoint-specific reflow rules.
3. Reselect an approved layout pattern or regenerate only if the first two repair attempts fail.

Pattern reselection is a regeneration event, not a first-line repair.

---
# # Contrast and overlay behaviour

Text placed over colour, image, or gradient backgrounds must meet the minimum contrast ratio after final rendering.

For gradients and images, do not use average contrast. The validator must check the lowest-contrast point inside the text bounding box. If one part of the text fails, the layout fails.

Acceptable repairs include:

* Moving the text to a more stable background area.
* Adding an approved scrim or overlay.
* Changing the approved colour token.
* Reflowing the composition so the text no longer sits over unstable image detail.

---
# # Cognitive load and messaging collision

Layout and messaging can conflict. For example, a messaging standard may require a long positioning statement while a hero layout needs low density.

When text length and layout density conflict, H006 cognitive load determines whether comprehension remains acceptable. If comprehension fails, adapt the layout, reduce displayed text, or route to messaging repair.

Do not solve cognitive overload by hiding required content unless an approved application policy allows progressive disclosure.

---
# # Exception model

Exceptions are allowed only when declared in the YAML `exceptions.declared` block. Undeclared exceptions hard fail.

Four exceptions are pre-declared in this template:

Legal text exception: legal or regulated layout requirements may override visual layout preferences where required.

Platform UI exception: platform-rendered UI may impose spacing or overlay constraints outside the brand's control.

Campaign adaptation exception: campaign policies may adapt layout patterns if the output remains traceable to approved patterns and preserves accessibility.

Print production exception: print production may override digital spacing or safe-area defaults where bleed, trim, stock, or finishing requirements demand it.

---
# # Exemplars

Each exemplar below is referenced in the YAML by its `active_exemplar_key`. Validators use authoritative repository exemplars retrieved via `exemplars.storage.retrieval`, not the Markdown copies shown here.
# ## {exemplar-name}

Key: `{brand_id}.standards.visual-identity.layout.exemplar.{example_key}`

"{Approved exemplar description or rendered layout reference.}"

Why it works:

* {Reason 1}
* {Reason 2}
* {Reason 3}

---
# # Anti-exemplars

Anti-exemplars are negative reference material for human review only. They are excluded from all deterministic and heuristic validation. They must not be scored, repaired, or published.
# ## {anti-exemplar-name}

"{Anti-exemplar description or rendered layout reference.}"

Why it fails:

* {Reason 1}
* {Reason 2}
* {Reason 3}

---
# # Validator interpretation notes
# ## Deterministic checks

Implement with direct token checks, structural checks, geometry checks, contrast calculations, safe-area validation, graph checks, and measurable thresholds. Run in the order declared in `execution.rule_execution_order.phase_1_deterministic`.

Covered by: D001, D002, D003, D004, D005, D006, D007, D008, D009, D010, D011, D012, D013, D014, D015, D016, D017
# ## Heuristic checks

Implement using a classifier, scorer, or model-based evaluator. Run only after all deterministic checks pass or produce soft warnings only. Every heuristic check must return both a score and a reason. Never return a score alone.

Covered by: H001, H002, H003, H004, H005, H006, H007, H008

All heuristic rules use a 0.0 to 1.0 scale. Do not use 0-100 percentage scores.
# ## Breakpoint repair

If D004 fails, repair in escalation order:

1. Token and container adjustment.
2. Breakpoint-specific reflow adjustment.
3. Approved layout pattern reselection or full regeneration.

Changing the layout pattern is a regeneration event, while adjusting tokens or reflow rules is a repair event.
# ## Floating-point tolerance

Rules with `tolerance_px: 0.01` should log the pre-tolerance measurement. A repeated near-tolerance value may indicate an exporter issue rather than a brand violation.
# ## Density repair

H007 must return crowded regions, density drivers, and either a heatmap reference or coordinates. Repair instructions should target the flagged regions, not the whole layout.
# ## Exemplar retrieval

Exemplars required by H005 are fetched via the protocol declared in `exemplars.storage.retrieval`. If retrieval fails, H005 is skipped with a soft warning per `fallback_behaviour`.
# ## Repository cache behaviour

A repository outage may use `cached_pass_with_warning` only when a last-known-good version exists and the cache is within `cached_pass_max_age_seconds`. If no cached version is available, validation hard fails.

---
# # Change log

| Version | Date       | Changes                    |
| ------- | ---------- | -------------------------- |
| 1.0.0   | YYYY-MM-DD | Initial published version. |

---
# # Validation modes

This file can be validated in two modes.

Template validation: validates the structure of this reusable template. In this mode, the validator recognises `template.is_template: true` and does not require placeholder substitution.

Policy validation: validates an instantiated brand policy. In this mode, all `{placeholder}` values and `YYYY-MM-DD` date placeholders must be replaced, and the `template` metadata block must be removed.

---
# # Publishing checklist

Before publication, confirm:

* All `{placeholder}` values have been replaced with brand-specific content.
* All `YYYY-MM-DD` date placeholders have been replaced with real ISO dates.
* No `<runtime_variable>` values have been replaced.
* The `template` metadata block has been removed.
* The YAML parses successfully with no errors.
* `schema.validation_status` reflects the actual validation state.
* `status` and `lifecycle_state` reflect the actual governance state.
* All rule IDs referenced in `execution.rule_execution_order` exist in `rules`.
* All exception IDs referenced in `unless_exception` blocks exist in `exceptions.declared`.
* All grid, spacing, layout pattern, and safe-area references resolve to declared entries.
* All standard dependency references are version-compatible.
* All layout pattern references are acyclic.
* All target breakpoints and aspect ratios are validated where required.
* Worst-case contrast checks pass for text over colour, image, and gradient backgrounds.
* Dynamic safe areas pass for social layouts and channel-specific overlays.
* CTA requirements do not create recursive CTA-in-CTA loops.
* CMYK values exist or have been materialized and logged for print contexts.
* Cached repository passes are logged and within the allowed cache age.
* Positive exemplars do not violate any deterministic rule.
* Anti-exemplars are explicitly excluded from validation.
* All channel and content-type values in rules and `decision_policy` match `scope.applies_to`.
* The telemetry schema is valid and the policy key and version are attached to every validation report.
