# Astro Implementation Notes

This pack is built for Astro Content Collections.

Astro recommends Content Collections for structured groups of Markdown or MDX content. Collections give you schema validation, editor support, and type-safe querying.

## Where to place files

Copy `src/content.config.ts` to your Astro project root as `src/content.config.ts`.

Copy the `src/content` folders into your project.

Copy `src/data` into your project.

Copy `public/llms.txt` and `public/robots.txt` into your public folder.

## Suggested routes

- `/` uses `src/content/pages/home.md`
- `/services/` uses `src/content/pages/services.md`
- `/resources/` uses `src/content/pages/resources.md`
- `/pillars/[slug]/` uses `src/content/pillars`
- `/blog/[slug]/` uses `src/content/blog`
- `/downloads/[slug]/` uses `src/content/downloads`

## Content model

Each content item includes:

- title
- seoTitle
- description
- slug
- contentType
- status
- priority
- primaryKeyword
- keywords
- pillar
- audience
- stage
- CTA
- related content
- source notes where needed

## Tone checks

The content avoids the hard-fail terms from the supplied voice policy.

It uses direct address, short sentences, and clear CTAs.

It avoids exclamation points and spaced em dashes.
