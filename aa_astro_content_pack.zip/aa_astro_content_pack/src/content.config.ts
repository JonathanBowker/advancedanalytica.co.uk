import { defineCollection } from 'astro:content';
import { glob } from 'astro/loaders';
import { z } from 'astro/zod';

const commonSchema = z.object({
  title: z.string(),
  seoTitle: z.string().optional(),
  description: z.string(),
  slug: z.string(),
  contentType: z.string(),
  status: z.enum(['draft', 'ready', 'published']),
  priority: z.number().optional(),
  publishedDate: z.coerce.date().optional(),
  primaryKeyword: z.string().optional(),
  keywords: z.array(z.string()).optional(),
  pillar: z.string().optional(),
  audience: z.array(z.string()).optional(),
  stage: z.string().optional(),
  cta: z.string().optional(),
  related: z.array(z.string()).optional(),
  readingTimeMinutes: z.number().optional(),
  sourceNotes: z.array(z.object({
    label: z.string(),
    url: z.string()
  })).optional()
});

export const collections = {
  pages: defineCollection({
    loader: glob({ base: './src/content/pages', pattern: '**/*.{md,mdx}' }),
    schema: commonSchema
  }),
  pillars: defineCollection({
    loader: glob({ base: './src/content/pillars', pattern: '**/*.{md,mdx}' }),
    schema: commonSchema
  }),
  blog: defineCollection({
    loader: glob({ base: './src/content/blog', pattern: '**/*.{md,mdx}' }),
    schema: commonSchema
  }),
  downloads: defineCollection({
    loader: glob({ base: './src/content/downloads', pattern: '**/*.{md,mdx}' }),
    schema: commonSchema
  }),
  social: defineCollection({
    loader: glob({ base: './src/content/social', pattern: '**/*.{md,mdx}' }),
    schema: commonSchema
  }),
  newsletter: defineCollection({
    loader: glob({ base: './src/content/newsletter', pattern: '**/*.{md,mdx}' }),
    schema: commonSchema
  })
};
