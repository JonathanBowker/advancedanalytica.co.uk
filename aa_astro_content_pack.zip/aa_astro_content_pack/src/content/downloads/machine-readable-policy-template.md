---
title: Machine-Readable Brand Policy Template
seoTitle: Machine-Readable Brand Policy Template
description: A working outline for policy files that people and AI can use.
slug: machine-readable-policy-template
contentType: download
status: ready
priority: 2
cta: Use the template
related:
- ai-readiness-for-brands
---

# Machine-Readable Brand Policy Template

A working outline for policy files that people and AI can use.

## File structure

Use YAML front matter for metadata.

Use Markdown for the human policy.

Use a JSON sidecar for system retrieval.

## Required metadata

Policy ID.

Owner.

Scope.

Authority.

Priority.

Rule type.

Dependencies.

Version.

Review date.

## Rule body

Start with the intent.

State the rule.

State what is prohibited.

Declare exceptions.

Add examples.

Define validation checks.

## Validation

Test the policy with realistic prompts.

Record where models disagree.

Repair the rule until interpretation is consistent.

## Ready to move?

Use the template.
