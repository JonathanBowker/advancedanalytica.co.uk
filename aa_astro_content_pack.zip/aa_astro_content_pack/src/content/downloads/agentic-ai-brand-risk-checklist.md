---
title: Agentic AI Brand Risk Checklist
seoTitle: Agentic AI Brand Risk Checklist
description: Define agent boundaries before they act for your brand.
slug: agentic-ai-brand-risk-checklist
contentType: download
status: ready
priority: 3
cta: Map your agent boundaries
related:
- machine-readable-brand-policy
---

# Agentic AI Brand Risk Checklist

Define agent boundaries before they act for your brand.

## Agent inventory

Name the agent.

List the workflow.

List the tools it can access.

List the outputs it can create.

## Boundary checks

Can it draft?

Can it send?

Can it approve?

Can it make claims?

Can it choose an audience?

Can it override policy?

## Escalation

Define high-risk categories.

Define required approvals.

Define blocked actions.

Define exception logging.

## Testing

Test edge cases.

Test outdated guidance.

Test conflicting rules.

Test sensitive topics.

Review the logs.

## Ready to move?

Map your agent boundaries.
